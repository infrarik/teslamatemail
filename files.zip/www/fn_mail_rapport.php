<?php
// --- fn_mail_rapport.php ---
// Génère et envoie un email HTML + PDF en pièce jointe (PDF pur PHP, sans librairie).

function fn_generer_pdf(
    string $rap_debut, string $rap_fin, array $t, string $monnaie,
    string $car_name_display, array $resultats, array $historique_fusionne,
    int $v2l_mode, array $cols, string $lang
): string {

    $display_start = ($lang === 'fr') ? date('d/m/Y', strtotime($rap_debut)) : $rap_debut;
    $display_end   = ($lang === 'fr') ? date('d/m/Y', strtotime($rap_fin))   : $rap_fin;

    // Colonnes
    $cols_pdf = $v2l_mode ? ['date','kwh_used','duree','ville','gps'] : $cols;
    $nb_cols  = count($cols_pdf);

    // KPIs
    $kpis = [];
    if (!$v2l_mode) $kpis[] = $resultats['total_km'] . ' km';
    $kpis[] = $resultats['nb'] . ' charges';
    if (!$v2l_mode) $kpis[] = $resultats['total_kwh_added'] . ' kWh ajoutes';
    $kpis[] = $resultats['total_kwh_used'] . ' kWh conso';
    if (!$v2l_mode) $kpis[] = $resultats['total_cost'] . ' ' . $monnaie;
    if (!$v2l_mode && ($resultats['conso_100'] ?? 0) > 0) $kpis[] = $resultats['conso_100'] . ' kWh/100km';

    // Lignes de données
    $rows = [];
    foreach ($historique_fusionne as $l) {
        if ($v2l_mode && $l['kwh_used'] <= 0) continue;
        if (!$v2l_mode && $l['kwh'] == 0 && $l['kwh_used'] == 0) continue;
        $row = [];
        foreach ($cols_pdf as $c) {
            switch ($c) {
                case 'date':     $row[] = date('d/m/Y', strtotime($l['date'])); break;
                case 'kwh':      $row[] = $l['kwh'] > 0 ? round($l['kwh'], 2) : '-'; break;
                case 'kwh_used': $row[] = $l['kwh_used'] > 0 ? round($l['kwh_used'], 2) : '-'; break;
                case 'cost':     $row[] = $l['cost'] > 0 ? round($l['cost'], 2) : '-'; break;
                case 'duree':    $row[] = round($l['duree']) . 'min'; break;
                case 'km':       $row[] = $l['km'] > 0 ? round($l['km'], 1) : '-'; break;
                case 'ville':    $row[] = mb_convert_encoding($l['ville'] ?? '', 'ISO-8859-1', 'UTF-8'); break;
                case 'gps':      $row[] = ($l['gps'] && $l['gps'] !== '0,0') ? $l['gps'] : '-'; break;
                default:         $row[] = '';
            }
        }
        $rows[] = $row;
    }

    // --- Construction PDF brut ---
    $objects = [];
    $offsets = [];
    $out     = '';

    $add = function(string $content) use (&$objects) {
        $objects[] = $content;
        return count($objects); // numéro d'objet (1-based)
    };

    // Encodage texte PDF (parenthèses échappées)
    $esc = fn($s) => '(' . str_replace(['\\','(',')',"\r"], ['\\\\','\\(','\\)','\r'], $s) . ')';

    // Police Helvetica intégrée
    $add("<<\n/Type /Font\n/Subtype /Type1\n/BaseFont /Helvetica-Bold\n/Encoding /WinAnsiEncoding\n>>");      // obj 1 = font bold
    $add("<<\n/Type /Font\n/Subtype /Type1\n/BaseFont /Helvetica\n/Encoding /WinAnsiEncoding\n>>");           // obj 2 = font normal

    // Page width=595 height=842 (A4)
    $W = 595; $H = 842;
    $margin = 30;
    $usable = $W - 2 * $margin;
    $col_w  = $usable / $nb_cols;

    // Contenu de la page
    $stream = '';
    $y = $H - $margin; // PDF : y=0 en bas

    // Fond rouge entête
    $stream .= "0.863 0.149 0.149 rg\n"; // #DC2626
    $stream .= "$margin " . ($y - 50) . " $usable 50 re f\n";

    // Titre
    $stream .= "1 1 1 rg\n";
    $stream .= "BT /F1 14 Tf\n";
    $title = mb_convert_encoding($t['report_title'] . ' - ' . $car_name_display, 'ISO-8859-1', 'UTF-8');
    $stream .= ($margin + 5) . " " . ($y - 20) . " Td\n";
    $stream .= $esc($title) . " Tj\n";
    $stream .= "ET\n";

    // Sous-titre période
    $stream .= "BT /F2 10 Tf\n";
    $period = mb_convert_encoding($t['period'] . ' : ' . $display_start . ' - ' . $display_end, 'ISO-8859-1', 'UTF-8');
    $stream .= ($margin + 5) . " " . ($y - 38) . " Td\n";
    $stream .= $esc($period) . " Tj\n";
    $stream .= "ET\n";

    $y -= 60;

    // KPIs
    $stream .= "0.96 0.96 0.96 rg\n";
    $kpi_w = $usable / count($kpis);
    foreach ($kpis as $i => $kpi) {
        $kx = $margin + $i * $kpi_w;
        $stream .= "$kx " . ($y - 25) . " $kpi_w 25 re f\n";
        $stream .= "0 0 0 rg\n";
        $stream .= "0.8 0.8 0.8 RG 0.5 w\n";
        $stream .= "$kx " . ($y - 25) . " $kpi_w 25 re S\n";
        $stream .= "BT /F1 9 Tf\n";
        $stream .= ($kx + 4) . " " . ($y - 16) . " Td\n";
        $stream .= $esc(mb_convert_encoding($kpi, 'ISO-8859-1', 'UTF-8')) . " Tj\nET\n";
        $stream .= "0.863 0.149 0.149 rg\n"; // reset pour prochaine itération
    }

    $y -= 35;

    // --- Graphique de consommation par jour ---
    if (!$v2l_mode && count($historique_fusionne) > 0) {

        // Agréger kWh consommés par date
        $kwh_par_jour = [];
        foreach ($historique_fusionne as $l) {
            if (($l['kwh_used'] ?? 0) <= 0) continue;
            $d = $l['date'];
            $kwh_par_jour[$d] = ($kwh_par_jour[$d] ?? 0) + $l['kwh_used'];
        }
        ksort($kwh_par_jour);

        if (count($kwh_par_jour) > 0) {
            $graph_h    = 70;  // hauteur max des barres
            $graph_area = $y - $graph_h - 30; // y bas du graphique
            $nb_bars    = count($kwh_par_jour);
            $bar_w      = min(20, ($usable - 10) / $nb_bars - 2);
            $gap        = ($usable - $nb_bars * $bar_w) / ($nb_bars + 1);
            $max_kwh    = max(array_values($kwh_par_jour));
            if ($max_kwh <= 0) $max_kwh = 1;

            // Titre graphique
            $stream .= "0 0 0 rg\n";
            $graph_title = mb_convert_encoding(
                ($lang === 'fr' ? 'Consommation par jour (kWh)' : 'Daily consumption (kWh)'),
                'ISO-8859-1', 'UTF-8'
            );
            $stream .= "BT /F1 8 Tf " . $margin . " " . ($y - 10) . " Td " . $esc($graph_title) . " Tj ET\n";

            // Ligne de base
            $stream .= "0.7 0.7 0.7 RG 0.5 w\n";
            $stream .= "$margin " . ($graph_area) . " m " . ($margin + $usable) . " " . ($graph_area) . " l S\n";

            // Barres
            $xi = 0;
            foreach ($kwh_par_jour as $date => $kwh) {
                $bx     = $margin + $gap + $xi * ($bar_w + $gap);
                $bh     = max(2, ($kwh / $max_kwh) * $graph_h);
                $by     = $graph_area;

                // Barre rouge
                $stream .= "0.863 0.149 0.149 rg\n";
                $stream .= "$bx $by $bar_w $bh re f\n";

                // Valeur au dessus
                $val = round($kwh, 1);
                $stream .= "0 0 0 rg\n";
                $stream .= "BT /F2 6 Tf " . ($bx + 1) . " " . ($by + $bh + 2) . " Td " . $esc((string)$val) . " Tj ET\n";

                // Date en dessous (JJ/MM)
                $label = date('d/m', strtotime($date));
                $stream .= "0.4 0.4 0.4 rg\n";
                $stream .= "BT /F2 5 Tf " . ($bx) . " " . ($by - 9) . " Td " . $esc($label) . " Tj ET\n";

                $xi++;
            }

            $y = $graph_area - 18; // descendre sous le graphique
        }
    }

    $y -= 5;
    $stream .= "0.863 0.149 0.149 rg\n";
    $stream .= "$margin " . ($y - 18) . " $usable 18 re f\n";
    $stream .= "1 1 1 rg\n";
    foreach ($cols_pdf as $i => $c) {
        $hdr = mb_convert_encoding($t['cols'][$c], 'ISO-8859-1', 'UTF-8');
        $cx  = $margin + $i * $col_w;
        $stream .= "BT /F1 7 Tf " . ($cx + 2) . " " . ($y - 13) . " Td " . $esc($hdr) . " Tj ET\n";
    }
    $y -= 20;

    // Lignes données
    foreach ($rows as $ri => $row) {
        if ($y < $margin + 20) { // saut de page simple
            $y = $H - $margin - 20;
        }
        $fill = ($ri % 2 === 0) ? "0.98 0.98 0.98" : "1 1 1";
        $stream .= "$fill rg\n";
        $stream .= "$margin " . ($y - 14) . " $usable 14 re f\n";
        $stream .= "0.85 0.85 0.85 RG 0.3 w\n";
        $stream .= "$margin " . ($y - 14) . " $usable 14 re S\n";
        $stream .= "0 0 0 rg\n";
        foreach ($row as $i => $cell) {
            $cx = $margin + $i * $col_w;
            $stream .= "BT /F2 7 Tf " . ($cx + 2) . " " . ($y - 10) . " Td " . $esc((string)$cell) . " Tj ET\n";
        }
        $y -= 15;
    }

    // Footer
    $stream .= "0.6 0.6 0.6 rg\n";
    $footer = mb_convert_encoding('TeslaMate - genere le ' . date('d/m/Y H:i'), 'ISO-8859-1', 'UTF-8');
    $stream .= "BT /F2 8 Tf $margin 20 Td " . $esc($footer) . " Tj ET\n";

    $stream_len = strlen($stream);
    $add("<<\n/Length $stream_len\n>>\nstream\n$stream\nendstream"); // obj 3 = content stream

    // Resources + page
    $add("<<\n/Type /Page\n/Parent 5 0 R\n/MediaBox [0 0 $W $H]\n/Contents 3 0 R\n/Resources <<\n  /Font << /F1 1 0 R /F2 2 0 R >>\n>>\n>>"); // obj 4 = page
    $add("<<\n/Type /Pages\n/Kids [4 0 R]\n/Count 1\n>>"); // obj 5 = pages
    $add("<<\n/Type /Catalog\n/Pages 5 0 R\n>>"); // obj 6 = catalog

    // Assemblage
    $pdf  = "%PDF-1.4\n";
    foreach ($objects as $i => $obj) {
        $offsets[$i + 1] = strlen($pdf);
        $pdf .= ($i + 1) . " 0 obj\n$obj\nendobj\n";
    }

    $xref_offset = strlen($pdf);
    $nb = count($objects) + 1;
    $pdf .= "xref\n0 $nb\n";
    $pdf .= "0000000000 65535 f \n";
    foreach ($offsets as $offset) {
        $pdf .= str_pad($offset, 10, '0', STR_PAD_LEFT) . " 00000 n \n";
    }
    $pdf .= "trailer\n<<\n/Size $nb\n/Root 6 0 R\n>>\n";
    $pdf .= "startxref\n$xref_offset\n%%EOF\n";

    return $pdf;
}

function fn_envoyer_rapport(
    string $to, string $subject, string $script_dir,
    string $rap_debut, string $rap_fin, array $t, string $monnaie,
    string $car_name_display, array $resultats, array $historique_fusionne,
    int $v2l_mode, array $cols, string $lang
): bool {

    // HTML du rapport
    ob_start();
    include $script_dir . '/tesla_rapport_hebdo_body.php';
    $html_body = ob_get_clean();

    // PDF pur PHP
    $pdf_data     = fn_generer_pdf($rap_debut, $rap_fin, $t, $monnaie, $car_name_display,
                                   $resultats, $historique_fusionne, $v2l_mode, $cols, $lang);
    $pdf_filename = 'rapport_' . $rap_debut . '_' . $rap_fin . '.pdf';

    $boundary     = '----=_Part_' . md5(uniqid());
    $boundary_alt = '----=_Alt_'  . md5(uniqid());
    $plain        = strip_tags(str_replace(['<br>','<br/>','<br />'], "\n", $html_body));

    $headers  = "From: noreply@teslamate.local\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

    $message  = "--$boundary\r\n";
    $message .= "Content-Type: multipart/alternative; boundary=\"$boundary_alt\"\r\n\r\n";
    $message .= "--$boundary_alt\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n$plain\r\n";
    $message .= "--$boundary_alt\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n$html_body\r\n";
    $message .= "--$boundary_alt--\r\n";

    $pdf_b64  = chunk_split(base64_encode($pdf_data));
    $message .= "--$boundary\r\n";
    $message .= "Content-Type: application/pdf; name=\"$pdf_filename\"\r\n";
    $message .= "Content-Transfer-Encoding: base64\r\n";
    $message .= "Content-Disposition: attachment; filename=\"$pdf_filename\"\r\n\r\n";
    $message .= $pdf_b64 . "\r\n";
    $message .= "--$boundary--";

    return mail($to, $subject, $message, $headers);
}
