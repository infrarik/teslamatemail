<?php
// --- fn_mail_rapport.php ---

function fn_generer_pdf(
    string $rap_debut, string $rap_fin, array $t, string $monnaie,
    string $car_name_display, array $resultats, array $historique_fusionne,
    int $v2l_mode, array $cols, string $lang
): string {

    $display_start = ($lang === 'fr') ? date('d/m/Y', strtotime($rap_debut)) : $rap_debut;
    $display_end   = ($lang === 'fr') ? date('d/m/Y', strtotime($rap_fin))   : $rap_fin;

    $cols_pdf = $v2l_mode ? ['date','kwh_used','duree','ville','gps'] : $cols;

    // KPIs globaux (page 1 seulement) : ['label', 'valeur']
    $kpis = [];
    if (!$v2l_mode) $kpis[] = [$t['dist_label'],         $resultats['total_km'] . ' km'];
    $kpis[] =                  [$t['charges_label'],      $resultats['nb'] . ''];
    if (!$v2l_mode) $kpis[] = [$t['energy_added_label'],  $resultats['total_kwh_added'] . ' kWh'];
    $kpis[] =                  [$t['energy_used_label'],   $resultats['total_kwh_used'] . ' kWh'];
    if (!$v2l_mode) $kpis[] = [$t['cost_label'],          $resultats['total_cost'] . ' ' . $monnaie];
    if (!$v2l_mode && $resultats['total_km'] > 0)
        $kpis[] =              ['kWh/100km',               round($resultats['total_kwh_added'] / $resultats['total_km'] * 100, 1) . ''];

    // Lignes de données + données sources (date, kwh_used, kwh_added)
    $rows      = [];   // cellules formatées
    $rows_meta = [];   // ['date'=>..., 'kwh_used'=>..., 'kwh_added'=>...]

    foreach ($historique_fusionne as $l) {
        if ($v2l_mode && $l['kwh_used'] <= 0) continue;
        if (!$v2l_mode && $l['kwh'] == 0 && $l['kwh_used'] == 0) continue;
        $row = [];
        foreach ($cols_pdf as $c) {
            switch ($c) {
                case 'date':     $row[] = date('d/m/Y', strtotime($l['date'])); break;
                case 'kwh':      $row[] = $l['kwh'] > 0 ? round($l['kwh'], 2) : '-'; break;
                case 'kwh_used': $row[] = $l['kwh_used'] > 0 ? round($l['kwh_used'], 2) : '-'; break;
                case 'cost':     $row[] = $l['cost'] > 0 ? round($l['cost'], 2) : '-'; break;
                case 'duree':    $row[] = round($l['duree']) . 'min'; break;
                case 'km':       $row[] = $l['km'] > 0 ? round($l['km'], 1) : '-'; break;
                case 'ville':    $row[] = mb_convert_encoding($l['ville'] ?? '', 'ISO-8859-1', 'UTF-8'); break;
                case 'gps':      $row[] = ($l['gps'] && $l['gps'] !== '0,0') ? $l['gps'] : '-'; break;
                default:         $row[] = '';
            }
        }
        $rows[]      = $row;
        $rows_meta[] = [
            'date'      => $l['date'],
            'kwh_used'  => (float)($l['kwh_used'] ?? 0),
            'kwh_added' => (float)($l['kwh'] ?? 0),
        ];
    }

    // Dimensions A4
    $W      = 595;
    $H      = 842;
    $margin = 28;
    $usable = $W - 2 * $margin;

    $col_def = [
        'date'     => ['w' => 52,  'align' => 'L', 'hdr' => ['Date']],
        'kwh'      => ['w' => 38,  'align' => 'R', 'hdr' => ['kWh', 'ajout.']],
        'kwh_used' => ['w' => 38,  'align' => 'R', 'hdr' => ['kWh', 'conso.']],
        'cost'     => ['w' => 32,  'align' => 'R', 'hdr' => ['Cout']],
        'duree'    => ['w' => 38,  'align' => 'R', 'hdr' => ['Duree', 'charge']],
        'km'       => ['w' => 32,  'align' => 'R', 'hdr' => ['km']],
        'ville'    => ['w' => 0,   'align' => 'L', 'hdr' => ['Ville']],
        'gps'      => ['w' => 50,  'align' => 'L', 'hdr' => ['GPS']],
    ];

    $fixed_total = 0;
    foreach ($cols_pdf as $c) {
        $w = $col_def[$c]['w'] ?? 40;
        if ($w > 0) $fixed_total += $w;
    }
    $flex_w = max(40, $usable - $fixed_total);

    $col_widths = [];
    $col_x      = [];
    $cx = $margin;
    foreach ($cols_pdf as $c) {
        $w = ($col_def[$c]['w'] ?? 40) === 0 ? $flex_w : ($col_def[$c]['w'] ?? 40);
        $col_widths[] = $w;
        $col_x[]      = $cx;
        $cx          += $w;
    }

    $idx_ville      = array_search('ville', $cols_pdf);
    $idx_gps        = array_search('gps',   $cols_pdf);
    $has_gps        = ($idx_gps !== false);
    $ville_w        = ($idx_ville !== false) ? $col_widths[$idx_ville] : 60;
    $ville_max_char = max(6, (int)($ville_w / 5.2));
    $row_height     = $has_gps ? 22 : 15;
    $bottom_lim     = $margin + 28;

    // Hauteurs réservées selon la page
    $graph_h      = 60;   // hauteur barres du graphique
    $graph_total  = $graph_h + 30; // + titre + labels + marge
    $hdr_block_p1 = 46 + 4 + 22 + 4 + $graph_total + 4 + 28; // entête+kpis+graphique+tableau_hdr
    $hdr_block_pN = 46 + 4 + $graph_total + 4 + 28;           // entête+graphique+tableau_hdr (pages suivantes, sans KPIs)

    // ---------------------------------------------------------------
    // PASSE 1 : simulation de la pagination pour grouper les lignes
    // ---------------------------------------------------------------
    $pages_rows = [];   // [ [row_idx, ...], [...], ... ]
    $current    = [];
    $y_sim      = $H - $margin - $hdr_block_p1;
    $first_page = true;

    foreach ($rows as $ri => $row) {
        if ($y_sim - $row_height < $bottom_lim) {
            $pages_rows[] = $current;
            $current      = [];
            $y_sim        = $H - $margin - $hdr_block_pN;
            $first_page   = false;
        }
        $current[] = $ri;
        $y_sim    -= $row_height;
    }
    $pages_rows[] = $current; // dernière page

    // ---------------------------------------------------------------
    // Encodage PDF
    // ---------------------------------------------------------------
    $esc = function($s) {
        return '(' . str_replace(['\\','(',')',"\r"], ['\\\\','\\(','\\)','\r'], $s) . ')';
    };
    $trunc = function($s, $max) {
        if (mb_strlen($s) <= $max) return $s;
        return mb_substr($s, 0, $max - 1) . '~';
    };

    // ---------------------------------------------------------------
    // Générateurs de blocs
    // ---------------------------------------------------------------

    // Approximation largeur texte : ratio caractère selon police/taille
    $tw = function($s, $pt, $bold = false) {
        return strlen($s) * ($bold ? $pt * 0.57 : $pt * 0.55);
    };

    // Logo : 1072x960 -> ratio 1.116, affiché 40x36 dans la bande rouge
    $logo_w  = 40;
    $logo_h  = 36;
    $logo_path = '/var/www/html/tmmlogo.jpg';
    $has_logo  = file_exists($logo_path) && is_readable($logo_path);
    $logo_data = $has_logo ? file_get_contents($logo_path) : '';

    $make_header = function() use ($margin, $usable, $W, $H, $t, $car_name_display,
                                   $display_start, $display_end, $esc, $tw,
                                   $logo_w, $logo_h, $has_logo) {
        $y      = $H - $margin;
        $hdr_h  = 46;
        $out    = "0.863 0.149 0.149 rg\n$margin " . ($y - $hdr_h) . " $usable $hdr_h re f\n";

        // Logos gauche et droite (dessinés via Do si le logo est dispo)
        if ($has_logo) {
            $logo_y  = $y - $hdr_h + ($hdr_h - $logo_h) / 2; // centré verticalement
            $logo_lx = $margin + 4;                             // gauche
            $logo_rx = $margin + $usable - $logo_w - 4;        // droite
            // Sauvegarder l'état graphique, appliquer matrice, dessiner, restaurer
            $out .= "q $logo_w 0 0 $logo_h $logo_lx $logo_y cm /Img Do Q\n";
            $out .= "q $logo_w 0 0 $logo_h $logo_rx $logo_y cm /Img Do Q\n";
        }

        // Texte centré — zone entre les deux logos
        $out .= "1 1 1 rg\n";
        $title   = mb_convert_encoding($t['report_title'] . ' - ' . $car_name_display, 'ISO-8859-1', 'UTF-8');
        $title_w = $tw($title, 13, true);
        $title_x = $margin + ($usable - $title_w) / 2;
        $out .= "BT /F1 13 Tf $title_x " . ($y - 18) . " Td " . $esc($title) . " Tj ET\n";

        $period   = mb_convert_encoding($t['period'] . ' : ' . $display_start . ' - ' . $display_end, 'ISO-8859-1', 'UTF-8');
        $period_w = $tw($period, 9);
        $period_x = $margin + ($usable - $period_w) / 2;
        $out .= "BT /F2 9 Tf $period_x " . ($y - 34) . " Td " . $esc($period) . " Tj ET\n";

        return $out;
    };

    $make_kpis = function($y) use ($margin, $usable, $kpis, $esc, $tw) {
        $out   = '';
        $kh    = 34; // hauteur case KPI : libellé (7pt) + valeur (9pt)
        $kpi_w = $usable / max(1, count($kpis));
        foreach ($kpis as $i => $kpi) {
            list($label, $valeur) = $kpi;
            $kx     = $margin + $i * $kpi_w;
            $label  = mb_convert_encoding($label,  'ISO-8859-1', 'UTF-8');
            $valeur = mb_convert_encoding($valeur, 'ISO-8859-1', 'UTF-8');
            // Fond gris clair + bordure
            $out .= "0.96 0.96 0.96 rg\n$kx " . ($y - $kh) . " $kpi_w $kh re f\n";
            $out .= "0 0 0 rg\n0.75 0.75 0.75 RG 0.4 w\n$kx " . ($y - $kh) . " $kpi_w $kh re S\n";
            // Libellé centré en haut, 7pt normal, gris foncé
            $lx = $kx + max(1, ($kpi_w - $tw($label, 7)) / 2);
            $out .= "0.4 0.4 0.4 rg\nBT /F2 7 Tf $lx " . ($y - 12) . " Td " . $esc($label) . " Tj ET\n";
            // Valeur centrée en bas, 9pt gras, noir
            $vx = $kx + max(1, ($kpi_w - $tw($valeur, 9, true)) / 2);
            $out .= "0 0 0 rg\nBT /F1 9 Tf $vx " . ($y - 26) . " Td " . $esc($valeur) . " Tj ET\n";
        }
        return $out;
    };

    // Graphique pour un sous-ensemble de lignes (rows_meta indices)
    $make_graph = function($y, array $row_indices) use (
        $margin, $usable, $rows_meta, $graph_h, $lang, $esc
    ) {
        if (empty($row_indices)) return ['stream' => '', 'height' => 0];

        // Agréger kwh_used par date pour les lignes de cette page
        $kwh_par_jour = [];
        foreach ($row_indices as $ri) {
            $meta = $rows_meta[$ri];
            if ($meta['kwh_used'] <= 0) continue;
            $d = $meta['date'];
            $kwh_par_jour[$d] = ($kwh_par_jour[$d] ?? 0) + $meta['kwh_used'];
        }
        ksort($kwh_par_jour);
        if (empty($kwh_par_jour)) return ['stream' => '', 'height' => 0];

        $nb_bars    = count($kwh_par_jour);
        $bar_w      = min(18, ($usable - 10) / $nb_bars - 2);
        $gap        = ($usable - $nb_bars * $bar_w) / ($nb_bars + 1);
        $max_kwh    = max(array_values($kwh_par_jour));
        if ($max_kwh <= 0) $max_kwh = 1;
        $graph_base = $y - $graph_h - 18;

        $graph_title = mb_convert_encoding(
            ($lang === 'fr' ? 'Consommation par jour (kWh)' : 'Daily consumption (kWh)'),
            'ISO-8859-1', 'UTF-8'
        );
        $out  = "0 0 0 rg\nBT /F1 7 Tf $margin " . ($y - 9) . " Td " . $esc($graph_title) . " Tj ET\n";
        $out .= "0.7 0.7 0.7 RG 0.4 w\n$margin $graph_base m " . ($margin + $usable) . " $graph_base l S\n";

        $xi = 0;
        foreach ($kwh_par_jour as $date => $kwh) {
            $bx = $margin + $gap + $xi * ($bar_w + $gap);
            $bh = max(2, ($kwh / $max_kwh) * $graph_h);
            $out .= "0.863 0.149 0.149 rg\n$bx $graph_base $bar_w $bh re f\n";
            $out .= "0 0 0 rg\nBT /F2 5 Tf " . ($bx + 1) . " " . ($graph_base + $bh + 2) . " Td "
                 . $esc((string)round($kwh, 1)) . " Tj ET\n";
            $out .= "0.4 0.4 0.4 rg\nBT /F2 5 Tf $bx " . ($graph_base - 8) . " Td "
                 . $esc(date('d/m', strtotime($date))) . " Tj ET\n";
            $xi++;
        }

        $total_height = $graph_h + 30; // titre(12) + barres($graph_h) + labels(8) + marges
        return ['stream' => $out, 'height' => $total_height];
    };


    $make_table_header = function($y) use ($margin, $usable, $col_x, $col_widths, $cols_pdf, $col_def, $esc, $tw) {
        $hdr_h = 26;
        $out   = "0.863 0.149 0.149 rg\n$margin " . ($y - $hdr_h) . " $usable $hdr_h re f\n1 1 1 rg\n";
        foreach ($cols_pdf as $i => $c) {
            $lines = $col_def[$c]['hdr'] ?? [$c];
            $cw    = $col_widths[$i];
            $cx0   = $col_x[$i];
            if (count($lines) === 1) {
                $txt = mb_convert_encoding($lines[0], 'ISO-8859-1', 'UTF-8');
                $cx  = $cx0 + max(1, ($cw - $tw($txt, 6, true)) / 2);
                $out .= "BT /F1 6 Tf $cx " . ($y - 17) . " Td " . $esc($txt) . " Tj ET\n";
            } else {
                $txt0 = mb_convert_encoding($lines[0], 'ISO-8859-1', 'UTF-8');
                $txt1 = mb_convert_encoding($lines[1], 'ISO-8859-1', 'UTF-8');
                $cx0c = $cx0 + max(1, ($cw - $tw($txt0, 6, true)) / 2);
                $cx1c = $cx0 + max(1, ($cw - $tw($txt1, 6, true)) / 2);
                $out .= "BT /F1 6 Tf $cx0c " . ($y - 10) . " Td " . $esc($txt0) . " Tj ET\n";
                $out .= "BT /F1 6 Tf $cx1c " . ($y - 20) . " Td " . $esc($txt1) . " Tj ET\n";
            }
        }
        return ['stream' => $out, 'height' => $hdr_h + 2];
    };

    $make_footer = function($page_num, $total_pages) use ($margin, $W, $esc) {
        $out  = "0.6 0.6 0.6 rg\n";
        $out .= "BT /F2 7 Tf $margin 18 Td "
              . $esc(mb_convert_encoding('TeslaMateMail - généré le ' . date('d/m/Y H:i'), 'ISO-8859-1', 'UTF-8'))
              . " Tj ET\n";
        $out .= "BT /F2 7 Tf " . ($W - $margin - 40) . " 18 Td "
              . $esc('Page ' . $page_num . '/' . $total_pages) . " Tj ET\n";
        return $out;
    };

    // ---------------------------------------------------------------
    // PASSE 2 : génération des streams page par page
    // ---------------------------------------------------------------
    $total_pages  = count($pages_rows);
    $page_streams = [];

    foreach ($pages_rows as $page_idx => $row_indices) {
        $page_num = $page_idx + 1;
        $stream   = $make_header();
        $y        = $H - $margin - 50;

        // KPIs uniquement page 1
        if ($page_idx === 0) {
            $stream .= $make_kpis($y);
            $y -= 38;
        }

        // Graphique propre à cette page
        if (!$v2l_mode && !empty($row_indices)) {
            $g = $make_graph($y, $row_indices);
            if ($g['height'] > 0) {
                $stream .= $g['stream'];
                $y      -= $g['height'];
            }
        }

        // En-tête tableau
        $y   -= 4;
        $th   = $make_table_header($y);
        $stream .= $th['stream'];
        $y   -= $th['height'];

        // Lignes
        foreach ($row_indices as $ri) {
            $row  = $rows[$ri];
            $fill = ($ri % 2 === 0) ? "0.97 0.97 0.97" : "1 1 1";
            $stream .= "$fill rg\n$margin " . ($y - $row_height) . " $usable $row_height re f\n";
            $stream .= "0.88 0.88 0.88 RG 0.3 w\n$margin " . ($y - $row_height) . " $usable $row_height re S\n0 0 0 rg\n";


            foreach ($row as $i => $cell) {
                $col    = $cols_pdf[$i];
                $cw     = $col_widths[$i];
                $cx0    = $col_x[$i];
                $text_y = $has_gps ? ($y - 9) : ($y - 10);

                if ($col === 'gps' && (string)$cell !== '-') {
                    // GPS : lat et lon centrés horizontalement sur 2 lignes
                    $parts = explode(',', (string)$cell, 2);
                    $lat   = trim($parts[0] ?? '');
                    $lon   = trim($parts[1] ?? '');
                    $lat_x = $cx0 + max(1, ($cw - $tw($lat, 6)) / 2);
                    $lon_x = $cx0 + max(1, ($cw - $tw($lon, 6)) / 2);
                    $stream .= "BT /F2 6 Tf $lat_x " . ($y - 8)  . " Td " . $esc($lat) . " Tj ET\n";
                    $stream .= "BT /F2 6 Tf $lon_x " . ($y - 17) . " Td " . $esc($lon) . " Tj ET\n";

                } elseif ($col === 'ville') {
                    // Ville : tronquée et centrée
                    $txt = $trunc((string)$cell, $ville_max_char);
                    $tcx = $cx0 + max(1, ($cw - $tw($txt, 7)) / 2);
                    $stream .= "BT /F2 7 Tf $tcx $text_y Td " . $esc($txt) . " Tj ET\n";

                } else {
                    // Toutes les autres colonnes : centré
                    $txt = (string)$cell;
                    $tcx = $cx0 + max(1, ($cw - $tw($txt, 7)) / 2);
                    $stream .= "BT /F2 7 Tf $tcx $text_y Td " . $esc($txt) . " Tj ET\n";
                }
            }
            $y -= $row_height;
        }

        $stream .= $make_footer($page_num, $total_pages);
        $page_streams[] = $stream;
    }

    // ---------------------------------------------------------------
    // Assemblage PDF
    // ---------------------------------------------------------------
    $nb_pages = count($page_streams);

    // Structure des objets :
    //   1          = Helvetica-Bold
    //   2          = Helvetica
    //   3          = objet image JPEG (si logo dispo), sinon absent
    //   3 ou 4 ... = content streams
    //   ...        = objets /Page
    //   ...        = /Pages
    //   ...        = /Catalog

    $objects      = [];
    $id_font_bold   = 1;
    $id_font_normal = 2;

    $objects[] = "<<\n/Type /Font\n/Subtype /Type1\n/BaseFont /Helvetica-Bold\n/Encoding /WinAnsiEncoding\n>>";
    $objects[] = "<<\n/Type /Font\n/Subtype /Type1\n/BaseFont /Helvetica\n/Encoding /WinAnsiEncoding\n>>";

    // Objet image JPEG (obj 3 si logo dispo)
    $id_image = null;
    if ($has_logo && $logo_data !== '') {
        $img_len   = strlen($logo_data);
        $objects[] = "<<\n/Type /XObject\n/Subtype /Image\n/Width 1072\n/Height 960\n"
                   . "/ColorSpace /DeviceRGB\n/BitsPerComponent 8\n/Filter /DCTDecode\n"
                   . "/Length $img_len\n>>\nstream\n" . $logo_data . "\nendstream";
        $id_image  = count($objects); // = 3
    }

    $stream_start = count($objects) + 1; // premier id disponible après polices + image éventuelle
    $id_streams   = [];
    for ($i = 0; $i < $nb_pages; $i++) $id_streams[]    = $stream_start + $i;
    $id_pages_objs = [];
    for ($i = 0; $i < $nb_pages; $i++) $id_pages_objs[] = $stream_start + $nb_pages + $i;
    $id_pages   = $stream_start + 2 * $nb_pages;
    $id_catalog = $stream_start + 2 * $nb_pages + 1;

    foreach ($page_streams as $ps) {
        $ps_len    = strlen($ps);
        $objects[] = "<<\n/Length $ps_len\n>>\nstream\n" . $ps . "\nendstream";
    }

    // Ressources communes : polices + image si dispo
    $font_res  = "/Font << /F1 $id_font_bold 0 R /F2 $id_font_normal 0 R >>";
    $xobj_res  = $id_image ? "\n  /XObject << /Img $id_image 0 R >>" : '';
    $resources = "/Resources <<\n  $font_res$xobj_res\n>>";

    foreach ($id_streams as $stream_id) {
        $objects[] = "<<\n/Type /Page\n/Parent $id_pages 0 R\n"
                   . "/MediaBox [0 0 $W $H]\n/Contents $stream_id 0 R\n"
                   . "$resources\n>>";
    }
    $kids      = implode(' ', array_map(fn($id) => "$id 0 R", $id_pages_objs));
    $objects[] = "<<\n/Type /Pages\n/Kids [$kids]\n/Count $nb_pages\n>>";
    $objects[] = "<<\n/Type /Catalog\n/Pages $id_pages 0 R\n>>";

    $pdf     = "%PDF-1.4\n";
    $offsets = [];
    foreach ($objects as $i => $obj_content) {
        $obj_id           = $i + 1;
        $offsets[$obj_id] = strlen($pdf);
        $pdf .= "$obj_id 0 obj\n$obj_content\nendobj\n";
    }

    $xref_offset = strlen($pdf);
    $total_objs  = count($objects) + 1;
    $pdf .= "xref\n0 $total_objs\n0000000000 65535 f \n";
    for ($i = 1; $i < $total_objs; $i++)
        $pdf .= str_pad($offsets[$i], 10, '0', STR_PAD_LEFT) . " 00000 n \n";

    $pdf .= "trailer\n<<\n/Size $total_objs\n/Root $id_catalog 0 R\n>>\n";
    $pdf .= "startxref\n$xref_offset\n%%EOF\n";

    return $pdf;
}

function fn_envoyer_rapport(
    string $to, string $subject, string $script_dir,
    string $rap_debut, string $rap_fin, array $t, string $monnaie,
    string $car_name_display, array $resultats, array $historique_fusionne,
    int $v2l_mode, array $cols, string $lang
): bool {

    ob_start();
    include $script_dir . '/tesla_rapport_hebdo_body.php';
    $html_body = ob_get_clean();

    $pdf_data     = fn_generer_pdf($rap_debut, $rap_fin, $t, $monnaie, $car_name_display,
                                   $resultats, $historique_fusionne, $v2l_mode, $cols, $lang);
    $pdf_filename = 'rapport_' . $rap_debut . '_' . $rap_fin . '.pdf';

    $boundary     = '----=_Part_' . md5(uniqid());
    $boundary_alt = '----=_Alt_'  . md5(uniqid());
    $plain        = strip_tags(str_replace(['<br>','<br/>','<br />'], "\n", $html_body));

    $headers  = "From: noreply@teslamate.local\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

    $message  = "--$boundary\r\n";
    $message .= "Content-Type: multipart/alternative; boundary=\"$boundary_alt\"\r\n\r\n";
    $message .= "--$boundary_alt\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n$plain\r\n";
    $message .= "--$boundary_alt\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n$html_body\r\n";
    $message .= "--$boundary_alt--\r\n";

    $pdf_b64  = chunk_split(base64_encode($pdf_data));
    $message .= "--$boundary\r\n";
    $message .= "Content-Type: application/pdf; name=\"$pdf_filename\"\r\n";
    $message .= "Content-Transfer-Encoding: base64\r\n";
    $message .= "Content-Disposition: attachment; filename=\"$pdf_filename\"\r\n\r\n";
    $message .= $pdf_b64 . "\r\n";
    $message .= "--$boundary--";

    return mail($to, $subject, $message, $headers);
}
