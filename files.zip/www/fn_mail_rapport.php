<?php
// --- fn_mail_rapport.php ---
// Génère et envoie un email HTML + PDF en pièce jointe (PDF pur PHP, sans librairie).

function fn_generer_pdf(
    string $rap_debut, string $rap_fin, array $t, string $monnaie,
    string $car_name_display, array $resultats, array $historique_fusionne,
    int $v2l_mode, array $cols, string $lang
): string {

    $display_start = ($lang === 'fr') ? date('d/m/Y', strtotime($rap_debut)) : $rap_debut;
    $display_end   = ($lang === 'fr') ? date('d/m/Y', strtotime($rap_fin))   : $rap_fin;

    // Colonnes
    $cols_pdf = $v2l_mode ? ['date','kwh_used','duree','ville','gps'] : $cols;
    $nb_cols  = count($cols_pdf);

    // KPIs
    $kpis = [];
    if (!$v2l_mode) $kpis[] = $resultats['total_km'] . ' km';
    $kpis[] = $resultats['nb'] . ' charges';
    if (!$v2l_mode) $kpis[] = $resultats['total_kwh_added'] . ' kWh ajoutes';
    $kpis[] = $resultats['total_kwh_used'] . ' kWh conso';
    if (!$v2l_mode) $kpis[] = $resultats['total_cost'] . ' ' . $monnaie;
    if (!$v2l_mode && ($resultats['conso_100'] ?? 0) > 0) $kpis[] = $resultats['conso_100'] . ' kWh/100km';

    // Lignes de données
    $rows = [];
    foreach ($historique_fusionne as $l) {
        if ($v2l_mode && $l['kwh_used'] <= 0) continue;
        if (!$v2l_mode && $l['kwh'] == 0 && $l['kwh_used'] == 0) continue;
        $row = [];
        foreach ($cols_pdf as $c) {
            switch ($c) {
                case 'date':     $row[] = date('d/m/Y', strtotime($l['date'])); break;
                case 'kwh':      $row[] = $l['kwh'] > 0 ? round($l['kwh'], 2) : '-'; break;
                case 'kwh_used': $row[] = $l['kwh_used'] > 0 ? round($l['kwh_used'], 2) : '-'; break;
                case 'cost':     $row[] = $l['cost'] > 0 ? round($l['cost'], 2) : '-'; break;
                case 'duree':    $row[] = round($l['duree']) . 'min'; break;
                case 'km':       $row[] = $l['km'] > 0 ? round($l['km'], 1) : '-'; break;
                case 'ville':    $row[] = mb_convert_encoding($l['ville'] ?? '', 'ISO-8859-1', 'UTF-8'); break;
                case 'gps':      $row[] = ($l['gps'] && $l['gps'] !== '0,0') ? $l['gps'] : '-'; break;
                default:         $row[] = '';
            }
        }
        $rows[] = $row;
    }

    // Dimensions A4
    $W      = 595;
    $H      = 842;
    $margin = 30;
    $usable = $W - 2 * $margin;
    $col_w  = $usable / max(1, $nb_cols);

    // Encodage texte PDF
    $esc = function($s) {
        return '(' . str_replace(['\\','(',')',"\r"], ['\\\\','\\(','\\)','\r'], $s) . ')';
    };

    // ---------------------------------------------------------------
    // Générateurs de blocs de stream
    // ---------------------------------------------------------------

    $make_header = function() use ($margin, $usable, $H, $t, $car_name_display,
                                   $display_start, $display_end, $lang, $esc) {
        $y   = $H - $margin;
        $out = '';
        $out .= "0.863 0.149 0.149 rg\n";
        $out .= "$margin " . ($y - 50) . " $usable 50 re f\n";
        $out .= "1 1 1 rg\n";
        $title = mb_convert_encoding($t['report_title'] . ' - ' . $car_name_display, 'ISO-8859-1', 'UTF-8');
        $out .= "BT /F1 14 Tf " . ($margin + 5) . " " . ($y - 20) . " Td " . $esc($title) . " Tj ET\n";
        $period = mb_convert_encoding($t['period'] . ' : ' . $display_start . ' - ' . $display_end, 'ISO-8859-1', 'UTF-8');
        $out .= "BT /F2 10 Tf " . ($margin + 5) . " " . ($y - 38) . " Td " . $esc($period) . " Tj ET\n";
        return $out;
    };

    $make_kpis = function($y) use ($margin, $usable, $kpis, $esc) {
        $out   = '';
        $kpi_w = $usable / max(1, count($kpis));
        foreach ($kpis as $i => $kpi) {
            $kx = $margin + $i * $kpi_w;
            $out .= "0.96 0.96 0.96 rg\n$kx " . ($y - 25) . " $kpi_w 25 re f\n";
            $out .= "0 0 0 rg\n0.8 0.8 0.8 RG 0.5 w\n$kx " . ($y - 25) . " $kpi_w 25 re S\n";
            $out .= "BT /F1 9 Tf " . ($kx + 4) . " " . ($y - 16) . " Td "
                  . $esc(mb_convert_encoding($kpi, 'ISO-8859-1', 'UTF-8')) . " Tj ET\n";
        }
        return $out;
    };

    $make_table_header = function($y) use ($margin, $usable, $col_w, $cols_pdf, $t, $esc) {
        $out  = "0.863 0.149 0.149 rg\n$margin " . ($y - 18) . " $usable 18 re f\n1 1 1 rg\n";
        foreach ($cols_pdf as $i => $c) {
            $hdr = mb_convert_encoding($t['cols'][$c], 'ISO-8859-1', 'UTF-8');
            $cx  = $margin + $i * $col_w;
            $out .= "BT /F1 7 Tf " . ($cx + 2) . " " . ($y - 13) . " Td " . $esc($hdr) . " Tj ET\n";
        }
        return $out;
    };

    $make_footer = function($page_num) use ($margin, $W, $esc) {
        $out  = "0.6 0.6 0.6 rg\n";
        $out .= "BT /F2 8 Tf $margin 20 Td "
              . $esc(mb_convert_encoding('TeslaMate - genere le ' . date('d/m/Y H:i'), 'ISO-8859-1', 'UTF-8'))
              . " Tj ET\n";
        $out .= "BT /F2 8 Tf " . ($W - $margin - 30) . " 20 Td "
              . $esc('Page ' . $page_num) . " Tj ET\n";
        return $out;
    };

    // ---------------------------------------------------------------
    // Construction des streams page par page
    // ---------------------------------------------------------------
    $page_streams = [];
    $page_num     = 1;

    // PAGE 1 : entête + KPIs + graphique + début tableau
    $stream = $make_header();
    $y      = $H - $margin - 60;

    $stream .= $make_kpis($y);
    $y -= 35;

    // Graphique (page 1 uniquement)
    if (!$v2l_mode && count($historique_fusionne) > 0) {
        $kwh_par_jour = [];
        foreach ($historique_fusionne as $l) {
            if (($l['kwh_used'] ?? 0) <= 0) continue;
            $kwh_par_jour[$l['date']] = ($kwh_par_jour[$l['date']] ?? 0) + $l['kwh_used'];
        }
        ksort($kwh_par_jour);

        if (count($kwh_par_jour) > 0) {
            $graph_h    = 70;
            $nb_bars    = count($kwh_par_jour);
            $bar_w      = min(20, ($usable - 10) / $nb_bars - 2);
            $gap        = ($usable - $nb_bars * $bar_w) / ($nb_bars + 1);
            $max_kwh    = max(array_values($kwh_par_jour));
            if ($max_kwh <= 0) $max_kwh = 1;
            $graph_base = $y - $graph_h - 20;

            $graph_title = mb_convert_encoding(
                ($lang === 'fr' ? 'Consommation par jour (kWh)' : 'Daily consumption (kWh)'),
                'ISO-8859-1', 'UTF-8'
            );
            $stream .= "0 0 0 rg\nBT /F1 8 Tf $margin " . ($y - 10) . " Td " . $esc($graph_title) . " Tj ET\n";
            $stream .= "0.7 0.7 0.7 RG 0.5 w\n$margin $graph_base m " . ($margin + $usable) . " $graph_base l S\n";

            $xi = 0;
            foreach ($kwh_par_jour as $date => $kwh) {
                $bx = $margin + $gap + $xi * ($bar_w + $gap);
                $bh = max(2, ($kwh / $max_kwh) * $graph_h);
                $stream .= "0.863 0.149 0.149 rg\n$bx $graph_base $bar_w $bh re f\n";
                $stream .= "0 0 0 rg\nBT /F2 6 Tf " . ($bx + 1) . " " . ($graph_base + $bh + 2) . " Td "
                         . $esc((string)round($kwh, 1)) . " Tj ET\n";
                $stream .= "0.4 0.4 0.4 rg\nBT /F2 5 Tf $bx " . ($graph_base - 9) . " Td "
                         . $esc(date('d/m', strtotime($date))) . " Tj ET\n";
                $xi++;
            }

            $y = $graph_base - 18;
        }
    }

    $y -= 5;
    $stream .= $make_table_header($y);
    $y -= 20;

    // Lignes de données
    $row_height = 15;
    $bottom_lim = $margin + 30;

    foreach ($rows as $ri => $row) {
        if ($y - $row_height < $bottom_lim) {
            $stream .= $make_footer($page_num);
            $page_streams[] = $stream;
            $page_num++;

            $stream  = $make_header();
            $y       = $H - $margin - 60;
            $stream .= $make_table_header($y);
            $y -= 20;
        }

        $fill = ($ri % 2 === 0) ? "0.98 0.98 0.98" : "1 1 1";
        $stream .= "$fill rg\n$margin " . ($y - 14) . " $usable 14 re f\n";
        $stream .= "0.85 0.85 0.85 RG 0.3 w\n$margin " . ($y - 14) . " $usable 14 re S\n0 0 0 rg\n";
        foreach ($row as $i => $cell) {
            $cx = $margin + $i * $col_w;
            $stream .= "BT /F2 7 Tf " . ($cx + 2) . " " . ($y - 10) . " Td " . $esc((string)$cell) . " Tj ET\n";
        }
        $y -= $row_height;
    }

    $stream .= $make_footer($page_num);
    $page_streams[] = $stream;

    $nb_pages = count($page_streams);

    // ---------------------------------------------------------------
    // Calcul ANTICIPÉ des IDs d'objets — structure fixe :
    //   1          = Helvetica-Bold
    //   2          = Helvetica
    //   3..N+2     = content streams  (N = nb_pages)
    //   N+3..2N+2  = objets /Page
    //   2N+3       = objet /Pages
    //   2N+4       = objet /Catalog
    // ---------------------------------------------------------------
    $id_font_bold   = 1;
    $id_font_normal = 2;
    $id_streams     = [];
    for ($i = 0; $i < $nb_pages; $i++) $id_streams[]    = 3 + $i;
    $id_pages_objs  = [];
    for ($i = 0; $i < $nb_pages; $i++) $id_pages_objs[] = 3 + $nb_pages + $i;
    $id_pages   = 3 + 2 * $nb_pages;
    $id_catalog = 4 + 2 * $nb_pages;

    // ---------------------------------------------------------------
    // Assemblage des objets dans l'ordre défini
    // ---------------------------------------------------------------
    $objects = [];  // indexed 0-based; obj ID = index+1

    // 1 & 2 : polices
    $objects[] = "<<\n/Type /Font\n/Subtype /Type1\n/BaseFont /Helvetica-Bold\n/Encoding /WinAnsiEncoding\n>>";
    $objects[] = "<<\n/Type /Font\n/Subtype /Type1\n/BaseFont /Helvetica\n/Encoding /WinAnsiEncoding\n>>";

    // 3..N+2 : content streams
    foreach ($page_streams as $ps) {
        $ps_len    = strlen($ps);
        $objects[] = "<<\n/Length $ps_len\n>>\nstream\n" . $ps . "\nendstream";
    }

    // N+3..2N+2 : objets /Page
    foreach ($id_streams as $k => $stream_id) {
        $objects[] = "<<\n/Type /Page\n/Parent $id_pages 0 R\n"
                   . "/MediaBox [0 0 $W $H]\n/Contents $stream_id 0 R\n"
                   . "/Resources <<\n  /Font << /F1 $id_font_bold 0 R /F2 $id_font_normal 0 R >>\n>>\n>>";
    }

    // 2N+3 : /Pages
    $kids      = implode(' ', array_map(fn($id) => "$id 0 R", $id_pages_objs));
    $objects[] = "<<\n/Type /Pages\n/Kids [$kids]\n/Count $nb_pages\n>>";

    // 2N+4 : /Catalog
    $objects[] = "<<\n/Type /Catalog\n/Pages $id_pages 0 R\n>>";

    // ---------------------------------------------------------------
    // Écriture du fichier avec xref correcte
    // ---------------------------------------------------------------
    $pdf     = "%PDF-1.4\n";
    $offsets = [];

    foreach ($objects as $i => $obj_content) {
        $obj_id           = $i + 1;
        $offsets[$obj_id] = strlen($pdf);
        $pdf .= "$obj_id 0 obj\n$obj_content\nendobj\n";
    }

    $xref_offset = strlen($pdf);
    $total_objs  = count($objects) + 1; // inclut l'entrée nulle obj 0

    $pdf .= "xref\n0 $total_objs\n";
    $pdf .= "0000000000 65535 f \n";
    for ($i = 1; $i < $total_objs; $i++) {
        $pdf .= str_pad($offsets[$i], 10, '0', STR_PAD_LEFT) . " 00000 n \n";
    }

    $pdf .= "trailer\n<<\n/Size $total_objs\n/Root $id_catalog 0 R\n>>\n";
    $pdf .= "startxref\n$xref_offset\n%%EOF\n";

    return $pdf;
}

function fn_envoyer_rapport(
    string $to, string $subject, string $script_dir,
    string $rap_debut, string $rap_fin, array $t, string $monnaie,
    string $car_name_display, array $resultats, array $historique_fusionne,
    int $v2l_mode, array $cols, string $lang
): bool {

    ob_start();
    include $script_dir . '/tesla_rapport_hebdo_body.php';
    $html_body = ob_get_clean();

    $pdf_data     = fn_generer_pdf($rap_debut, $rap_fin, $t, $monnaie, $car_name_display,
                                   $resultats, $historique_fusionne, $v2l_mode, $cols, $lang);
    $pdf_filename = 'rapport_' . $rap_debut . '_' . $rap_fin . '.pdf';

    $boundary     = '----=_Part_' . md5(uniqid());
    $boundary_alt = '----=_Alt_'  . md5(uniqid());
    $plain        = strip_tags(str_replace(['<br>','<br/>','<br />'], "\n", $html_body));

    $headers  = "From: noreply@teslamate.local\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

    $message  = "--$boundary\r\n";
    $message .= "Content-Type: multipart/alternative; boundary=\"$boundary_alt\"\r\n\r\n";
    $message .= "--$boundary_alt\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n$plain\r\n";
    $message .= "--$boundary_alt\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n$html_body\r\n";
    $message .= "--$boundary_alt--\r\n";

    $pdf_b64  = chunk_split(base64_encode($pdf_data));
    $message .= "--$boundary\r\n";
    $message .= "Content-Type: application/pdf; name=\"$pdf_filename\"\r\n";
    $message .= "Content-Transfer-Encoding: base64\r\n";
    $message .= "Content-Disposition: attachment; filename=\"$pdf_filename\"\r\n\r\n";
    $message .= $pdf_b64 . "\r\n";
    $message .= "--$boundary--";

    return mail($to, $subject, $message, $headers);
}
