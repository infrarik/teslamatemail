<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- 1. CONFIGURATION & SETUP ---
$file = 'cgi-bin/setup';
$config = ['DOCKER_PATH' => '', 'LANGUAGE' => 'FR'];
if (file_exists($file)) {
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (empty(trim($line)) || $line[0] === '#' || strpos($line, '=') === false) continue;
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) { 
            $key = strtoupper(trim($parts[0]));
            $config[$key] = trim($parts[1]); 
        }
    }
}

$lang = (isset($config['LANGUAGE']) && strtolower($config['LANGUAGE']) === 'en') ? 'en' : 'fr';
$txt = [
    'fr' => [
        'title' => 'Historique', 'vehicle' => 'Véhicule', 'date' => 'Date', 'back' => 'Retour', 'to' => 'Vers',
        'unknown' => 'Inconnu', 'start' => 'D', 'end' => 'A', 'btn_kml' => 'EXPORT GOOGLE EARTH (KML)',
        'btn_3d' => 'CARTE DES ALTITUDES (3D)', 'btn_2d' => 'RETOURNER À LA CARTE (2D)', 'btn_full_day' => 'JOURNÉE ENTIÈRE',
        'btn_full_period' => 'PÉRIODE ENTIÈRE', 'date_from' => 'Du', 'date_to' => 'Au',
        'period_km' => 'Distance Période', 'day_summary' => 'Résumé jour',
        'total_km' => 'Distance Totale', 'search_placeholder' => 'Rechercher une ville...', 'btn_snap' => '📸 CAPTURE',
        'legend_speed' => 'Vitesses (km/h)', 'vmax' => 'V.Max', 'elev_gain' => 'D+', 'duration' => 'Durée', 
        'elev_title' => 'Dénivelé cumulé positif', 'layer_plan' => 'Plan seul', 'layer_sat' => 'Satellite seul', 'layer_hybrid' => 'Mixte (Satellite + Noms)',
        'battery' => 'Batterie',
        'btn_analyse' => '🏁 ANALYSE',
        'an_title' => 'Analyse conduite', 'an_score' => 'Score éco', 'an_vmax' => 'Vitesse max',
        'an_hi' => '% temps > 110 km/h', 'an_acc' => 'Accél. brusques', 'an_brk' => 'Freinages brusques',
        'an_conso' => 'Conso estimée', 'an_eco' => 'Conduite économe', 'an_bal' => 'Conduite équilibrée',
        'an_spo' => 'Conduite sportive', 'an_vsp' => 'Conduite très sportive',
        'an_eco_s' => 'Accélérations douces — excellent pour l\'autonomie.',
        'an_bal_s' => 'Quelques pics de vitesse — bonne moyenne générale.',
        'an_spo_s' => 'Accélérations fréquentes — consommation en hausse.',
        'an_vsp_s' => 'Conduite agressive — impact significatif sur l\'autonomie.',
    ],
    'en' => [
        'title' => 'History', 'vehicle' => 'Vehicle', 'date' => 'Date', 'back' => 'Back', 'to' => 'To',
        'unknown' => 'Unknown', 'start' => 'S', 'end' => 'E', 'btn_kml' => 'EXPORT GOOGLE EARTH (KML)',
        'btn_3d' => 'ALTITUDE MAP (3D)', 'btn_2d' => 'BACK TO MAP (2D)', 'btn_full_day' => 'FULL DAY VIEW',
        'btn_full_period' => 'FULL PERIOD', 'date_from' => 'From', 'date_to' => 'To',
        'period_km' => 'Period Distance', 'day_summary' => 'Day summary',
        'total_km' => 'Total Distance', 'search_placeholder' => 'Search city...', 'btn_snap' => '📸 SNAP',
        'legend_speed' => 'Speed (km/h)', 'vmax' => 'Max Spd', 'elev_gain' => 'Gain', 'duration' => 'Duration', 
        'elev_title' => 'Total elevation gain', 'layer_plan' => 'Map only', 'layer_sat' => 'Satellite only', 'layer_hybrid' => 'Hybrid (Sat + Names)',
        'battery' => 'Battery',
        'btn_analyse' => '🏁 ANALYSIS',
        'an_title' => 'Driving analysis', 'an_score' => 'Eco score', 'an_vmax' => 'Max speed',
        'an_hi' => '% time > 110 km/h', 'an_acc' => 'Hard accelerations', 'an_brk' => 'Hard brakings',
        'an_conso' => 'Est. consumption', 'an_eco' => 'Eco driving', 'an_bal' => 'Balanced driving',
        'an_spo' => 'Sporty driving', 'an_vsp' => 'Aggressive driving',
        'an_eco_s' => 'Smooth accelerations — great for range.',
        'an_bal_s' => 'Some speed peaks — good overall average.',
        'an_spo_s' => 'Frequent accelerations — increased consumption.',
        'an_vsp_s' => 'Aggressive driving — significant impact on range.',
    ]
][$lang];

// --- 2. BASE DE DONNÉES ---
$server_ip = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';

if (!empty($config['DOCKER_PATH']) && file_exists($config['DOCKER_PATH'])) {
    $docker_content = file_get_contents($config['DOCKER_PATH']);
    if (preg_match('/POSTGRES_USER[:=]\s*(\S+)/', $docker_content, $m)) $db_user = str_replace(['"', "'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_PASSWORD[:=]\s*(\S+)/', $docker_content, $m)) $db_pass = str_replace(['"', "'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_DB[:=]\s*(\S+)/', $docker_content, $m)) $db_name = str_replace(['"', "'"], '', trim($m[1]));
}

// --- 3. EXPORT KML ---
if (isset($_GET['export_kml'])) {
    try {
        $pdo_k = new PDO("pgsql:host=$server_ip;port=5432;dbname=$db_name", $db_user, $db_pass);
        if (isset($_GET['drive_id'])) {
            $stmt_k = $pdo_k->prepare("SELECT date, latitude, longitude, elevation FROM positions WHERE drive_id = ? AND latitude IS NOT NULL ORDER BY date ASC");
            $stmt_k->execute([$_GET['drive_id']]);
            $filename = "trip_".$_GET['drive_id'].".kml";
        } else {
            $stmt_k = $pdo_k->prepare("SELECT p.date, p.latitude, p.longitude, p.elevation FROM positions p JOIN drives d ON p.drive_id = d.id WHERE d.car_id = ? AND DATE(d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') = ? AND p.latitude IS NOT NULL ORDER BY p.date ASC");
            $stmt_k->execute([$_GET['car_id'], $_GET['date']]);
            $filename = "full_day_".$_GET['date'].".kml";
        }
        $rows = $stmt_k->fetchAll(PDO::FETCH_ASSOC);
        if (count($rows) >= 2) {
            header('Content-Type: application/vnd.google-earth.kml+xml');
            header('Content-Disposition: attachment; filename="'.$filename.'"');
            echo '<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2"><Document><Placemark><gx:Track><altitudeMode>relativeToGround</altitudeMode>';
            foreach ($rows as $r) echo '<when>'.date('Y-m-d\TH:i:s\Z', strtotime($r['date'])).'</when>';
            foreach ($rows as $r) echo '<gx:coord>'.$r['longitude'].' '.$r['latitude'].' '.round($r['elevation'] ?? 0, 1).'</gx:coord>';
            echo '</gx:Track></Placemark></Document></kml>';
            exit;
        }
    } catch (Exception $e) {}
}

// --- 4. RÉCUPÉRATION DONNÉES ---
$trajets = []; $positions = []; $cars = []; $pauses = [];
$selected_date  = $_GET['date']      ?? date('Y-m-d');
$date_from      = $_GET['date_from'] ?? null;
$date_to        = $_GET['date_to']   ?? null;
$is_range_mode  = ($date_from && $date_to);
// En mode plage, selected_date = date_from pour compatibilité
if ($is_range_mode) $selected_date = $date_from;
$selected_drive_id = $_GET['drive_id'] ?? null;
$search_query = $_GET['search'] ?? null;
$search_lat = $_GET['lat'] ?? null;
$search_lng = $_GET['lng'] ?? null;
$is_full_day = isset($_GET['full_day']) || (!$selected_drive_id && isset($_GET['date']) && !$search_query);
$is_full_period = isset($_GET['full_period']) && $is_range_mode;
$total_day_km = 0; $v_max_trip = 0; $elev_gain_trip = 0; $trip_duration_str = "--";
// Calcul flèches jour précédent / suivant
$prev_date = date('Y-m-d', strtotime($selected_date . ' -1 day'));
$next_date = date('Y-m-d', strtotime($selected_date . ' +1 day'));
$next_date = ($next_date > date('Y-m-d')) ? null : $next_date; // pas dans le futur
// Résumés par jour en mode plage
$range_days = [];

try {
    $pdo = new PDO("pgsql:host=$server_ip;port=5432;dbname=$db_name", $db_user, $db_pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $pdo->exec("SET TIME ZONE 'Europe/Paris'");
    $cars = $pdo->query("SELECT id, COALESCE(name, model) as display_name FROM cars ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
    $selected_car_id = $_GET['car_id'] ?? ($cars[0]['id'] ?? null);

    if ($selected_car_id) {
        // --- Mode plage de dates : résumé par jour ---
        if ($is_range_mode && !$is_full_period) {
            $stmt_range = $pdo->prepare("
                SELECT DATE(d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') as day,
                       COUNT(d.id) as nb_trajets,
                       ROUND(SUM(d.distance)::numeric, 1) as total_km,
                       MIN(d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') as first_start
                FROM drives d
                WHERE d.car_id = :car_id
                  AND DATE(d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') BETWEEN :d1 AND :d2
                GROUP BY day ORDER BY day ASC
            ");
            $stmt_range->execute(['car_id' => $selected_car_id, 'd1' => $date_from, 'd2' => $date_to]);
            $range_days = $stmt_range->fetchAll(PDO::FETCH_ASSOC);
            // total période
            foreach ($range_days as $rd) $total_day_km += $rd['total_km'];
        }

        // --- Mode période entière : tous les trajets fusionnés ---
        if ($is_range_mode && $is_full_period) {
            $sql = "SELECT d.id, (d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') as start_date_local, (d.end_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') as end_date_local, ROUND(d.distance::numeric, 1) as km, a_e.display_name as end_point FROM drives d LEFT JOIN addresses a_e ON d.end_address_id = a_e.id WHERE d.car_id = :car_id AND DATE(d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') BETWEEN :d1 AND :d2 ORDER BY d.start_date ASC";
            $stmt = $pdo->prepare($sql); $stmt->execute(['car_id' => $selected_car_id, 'd1' => $date_from, 'd2' => $date_to]);
            $trajets = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($trajets as $t) $total_day_km += $t['km'];
            $is_full_day = true;
        }

        if (!$is_range_mode && $search_query && $search_lat && $search_lng) {
            $sql = "SELECT d.id, (d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') as start_date_local, ROUND(d.distance::numeric, 1) as km, a_e.display_name as end_point, DATE(d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') as trip_date FROM drives d LEFT JOIN addresses a_e ON d.end_address_id = a_e.id JOIN positions p ON p.drive_id = d.id WHERE d.car_id = :car_id AND (6371 * acos(cos(radians(:lat)) * cos(radians(p.latitude)) * cos(radians(p.longitude) - radians(:lng)) + sin(radians(:lat)) * sin(radians(p.latitude)))) < 5 GROUP BY d.id, a_e.display_name, trip_date ORDER BY d.start_date DESC LIMIT 50";
            $stmt = $pdo->prepare($sql); $stmt->execute(['car_id' => $selected_car_id, 'lat' => $search_lat, 'lng' => $search_lng]);
            $trajets = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } elseif (!$is_range_mode || $is_full_period) {
            if (!$is_full_period) {
                $sql = "SELECT d.id, (d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') as start_date_local, (d.end_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') as end_date_local, ROUND(d.distance::numeric, 1) as km, a_e.display_name as end_point FROM drives d LEFT JOIN addresses a_e ON d.end_address_id = a_e.id WHERE d.car_id = :car_id AND DATE(d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') = :date ORDER BY d.start_date ASC";
                $stmt = $pdo->prepare($sql); $stmt->execute(['car_id' => $selected_car_id, 'date' => $selected_date]);
                $trajets = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        }

        // Fonction helper pour chercher une charge après un trajet
        $fn_get_charge = function($drive_end_local, $car_id, $next_start_local = null) use ($pdo) {
            $extra = $next_start_local ? "AND (end_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') <= :start_next" : "";
            $params = ['car_id' => $car_id, 'end_prev' => $drive_end_local];
            if ($next_start_local) $params['start_next'] = $next_start_local;
            try {
                $stmt_ch = $pdo->prepare("SELECT cp.charge_energy_added, cp.charge_energy_used, EXTRACT(EPOCH FROM (cp.end_date - cp.start_date))/60 as duree_charge, cp.start_battery_level, cp.end_battery_level, cp.start_battery_temp, cp.end_battery_temp, p.battery_heater FROM charging_processes cp LEFT JOIN positions p ON p.id = cp.position_id WHERE cp.car_id = :car_id AND (cp.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') >= :end_prev $extra AND cp.charge_energy_added > 0 ORDER BY cp.start_date ASC LIMIT 1");
                $stmt_ch->execute($params);
            } catch (Exception $e) {
                // Colonnes optionnelles absentes dans cette version de TeslaMate
                $stmt_ch = $pdo->prepare("SELECT cp.charge_energy_added, cp.charge_energy_used, EXTRACT(EPOCH FROM (cp.end_date - cp.start_date))/60 as duree_charge, cp.start_battery_level, cp.end_battery_level, NULL as start_battery_temp, NULL as end_battery_temp, p.battery_heater FROM charging_processes cp LEFT JOIN positions p ON p.id = cp.position_id WHERE cp.car_id = :car_id AND (cp.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') >= :end_prev $extra AND cp.charge_energy_added > 0 ORDER BY cp.start_date ASC LIMIT 1");
                $stmt_ch->execute($params);
            }
            return $stmt_ch->fetch(PDO::FETCH_ASSOC);
        };

        if ($is_full_day) {
            for ($i = 0; $i < count($trajets) - 1; $i++) {
                $end_prev = strtotime($trajets[$i]['end_date_local']);
                $start_next = strtotime($trajets[$i+1]['start_date_local']);
                $diff = ($start_next - $end_prev) / 60;
                if ($diff >= 5) {
                    $stmt_p = $pdo->prepare("SELECT latitude, longitude, elevation, outside_temp FROM positions WHERE drive_id = ? ORDER BY date DESC LIMIT 1");
                    $stmt_p->execute([$trajets[$i]['id']]);
                    $p_loc = $stmt_p->fetch(PDO::FETCH_ASSOC);
                    if ($p_loc) {
                        $charge = $fn_get_charge($trajets[$i]['end_date_local'], $selected_car_id, $trajets[$i+1]['start_date_local']);
                        $pauses[] = [
                            'lat'          => $p_loc['latitude'],
                            'lng'          => $p_loc['longitude'],
                            'dur'          => round($diff),
                            'is_charge'    => $charge ? true : false,
                            'kwh_added'    => $charge ? round($charge['charge_energy_added'], 1) : 0,
                            'kwh_used'     => $charge ? round($charge['charge_energy_used'], 1) : 0,
                            'duree_charge' => $charge ? round($charge['duree_charge']) : 0,
                            'elevation'    => $p_loc['elevation'] !== null ? round($p_loc['elevation']) : null,
                            'temp'         => $p_loc['outside_temp'] !== null ? round($p_loc['outside_temp'], 1) : null,
                            'bat_start'    => $charge ? $charge['start_battery_level'] : null,
                            'bat_end'      => $charge ? $charge['end_battery_level']   : null,
                            'bat_temp_start' => $charge ? ($charge['start_battery_temp'] ?? null) : null,
                            'bat_temp_end'   => $charge ? ($charge['end_battery_temp']   ?? null) : null,
                            'bat_heater'     => $charge ? ($charge['battery_heater']      ?? null) : null,
                        ];
                    }
                }
            }
        } elseif ($selected_drive_id) {
            // Vue trajet individuel : chercher une charge après la fin du trajet
            $current_drive = null;
            foreach ($trajets as $t) {
                if ($t['id'] == $selected_drive_id) { $current_drive = $t; break; }
            }
            if ($current_drive && !empty($current_drive['end_date_local'])) {
                // Borne de fin : trajet suivant s'il existe, sinon +2h max
                $next_drive = null;
                foreach ($trajets as $t) {
                    if (strtotime($t['start_date_local']) > strtotime($current_drive['end_date_local'])) {
                        $next_drive = $t;
                        break;
                    }
                }
                $charge_end_limit = $next_drive
                    ? $next_drive['start_date_local']
                    : date('Y-m-d H:i:s', strtotime($current_drive['end_date_local']) + 7200);
                $charge = $fn_get_charge($current_drive['end_date_local'], $selected_car_id, $charge_end_limit);
                if ($charge) {
                    $stmt_p = $pdo->prepare("SELECT latitude, longitude, elevation, outside_temp FROM positions WHERE drive_id = ? ORDER BY date DESC LIMIT 1");
                    $stmt_p->execute([$selected_drive_id]);
                    $p_loc = $stmt_p->fetch(PDO::FETCH_ASSOC);
                    if ($p_loc) {
                        $pauses[] = [
                            'lat'          => $p_loc['latitude'],
                            'lng'          => $p_loc['longitude'],
                            'dur'          => 0,
                            'is_charge'    => true,
                            'kwh_added'    => round($charge['charge_energy_added'], 1),
                            'kwh_used'     => round($charge['charge_energy_used'], 1),
                            'duree_charge' => round($charge['duree_charge']),
                            'elevation'    => $p_loc['elevation'] !== null ? round($p_loc['elevation']) : null,
                            'temp'         => $p_loc['outside_temp'] !== null ? round($p_loc['outside_temp'], 1) : null,
                            'bat_start'    => $charge['start_battery_level'],
                            'bat_end'      => $charge['end_battery_level'],
                            'bat_temp_start' => $charge['start_battery_temp'] ?? null,
                            'bat_temp_end'   => $charge['end_battery_temp']   ?? null,
                            'bat_heater'     => $charge['battery_heater']      ?? null,
                        ];
                    }
                }
            }
        }

        if (!$is_full_period && !$is_range_mode) foreach($trajets as $t) $total_day_km += $t['km'];

        if ($selected_drive_id || ($is_full_day && !$search_query)) {
            if ($selected_drive_id) {
                $sql_p = "SELECT date, latitude, longitude, elevation, speed, outside_temp, inside_temp, drive_id, battery_level FROM positions WHERE drive_id = ? AND latitude IS NOT NULL ORDER BY date ASC";
                $stmt_p = $pdo->prepare($sql_p);
                $stmt_p->execute([$selected_drive_id]);
            } elseif ($is_full_period && $is_range_mode) {
                // Période entière : toutes les positions entre date_from et date_to
                $sql_p = "SELECT p.date, p.latitude, p.longitude, p.elevation, p.speed, p.outside_temp, p.inside_temp, p.drive_id, p.battery_level FROM positions p JOIN drives d ON p.drive_id = d.id WHERE d.car_id = ? AND DATE(d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') BETWEEN ? AND ? AND p.latitude IS NOT NULL ORDER BY p.date ASC";
                $stmt_p = $pdo->prepare($sql_p);
                $stmt_p->execute([$selected_car_id, $date_from, $date_to]);
            } else {
                $sql_p = "SELECT p.date, p.latitude, p.longitude, p.elevation, p.speed, p.outside_temp, p.inside_temp, p.drive_id, p.battery_level FROM positions p JOIN drives d ON p.drive_id = d.id WHERE d.car_id = ? AND DATE(d.start_date AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Paris') = ? AND p.latitude IS NOT NULL ORDER BY p.date ASC";
                $stmt_p = $pdo->prepare($sql_p);
                $stmt_p->execute([$selected_car_id, $selected_date]);
            }
            $positions = $stmt_p->fetchAll(PDO::FETCH_ASSOC);

            if (count($positions) > 1) {
                $start_time = strtotime($positions[0]['date']);
                $end_time = strtotime($positions[count($positions)-1]['date']);
                $diff_sec = $end_time - $start_time;
                $h = floor($diff_sec / 3600);
                $m = floor(($diff_sec % 3600) / 60);
                $trip_duration_str = ($h > 0) ? $h."h".str_pad($m, 2, '0', STR_PAD_LEFT) : $m."min";
            }

            foreach ($positions as $idx => $p) {
                if ($p['speed'] > $v_max_trip) $v_max_trip = $p['speed'];
                if ($idx > 0 && $p['elevation'] > $positions[$idx-1]['elevation']) {
                    $elev_gain_trip += ($p['elevation'] - $positions[$idx-1]['elevation']);
                }
            }
        }
    }
} catch (PDOException $e) { die($e->getMessage()); }
?>

<!DOCTYPE html>
<html lang="<?= $lang ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= $txt['title'] ?></title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://cdn.plot.ly/plotly-2.24.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <style>
        body { font-family: -apple-system, sans-serif; background: #111; color: #eee; margin: 0; display: flex; height: 100vh; overflow: hidden; }
        #sidebar { width: 380px; background: #1c1c1c; border-right: 1px solid #333; display: flex; flex-direction: column; z-index: 10; }
        #main-viz { flex: 1; position: relative; background: #000; }
        #map, #plot3d { width: 100%; height: 100%; position: absolute; top: 0; left: 0; }
        #plot3d { display: none; }
        
        .header { padding: 15px 20px; background: #252525; border-bottom: 1px solid #333; }
        .top-nav { display: flex; align-items: center; gap: 15px; margin-bottom: 10px; }
        .back-button { width: 35px; height: 35px; background: rgba(255,255,255,0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; transition: 0.2s; }
        .back-button:hover { background: #dc2626; }
        .back-button svg { width: 20px; height: 20px; stroke: white; fill: none; stroke-width: 2.5; }
        
        .search-box { position: relative; margin-bottom: 10px; }
        .search-box input { width: 100%; padding: 10px 65px 10px 10px; background: #333; border: 1px solid #444; color: white; border-radius: 4px; box-sizing: border-box; }
        .search-icons { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); display: flex; gap: 8px; align-items: center; }
        .search-icons svg { width: 18px; height: 18px; fill: #888; cursor: pointer; transition: 0.2s; }
        .search-icons svg:hover { fill: #fff; }

        label { display: block; font-size: 10px; color: #888; text-transform: uppercase; margin: 10px 0 5px; }
        .input-field { width: 100%; padding: 10px; background: #333; border: 1px solid #444; color: white; border-radius: 4px; box-sizing: border-box; margin-bottom: 10px; }
        
        .btn-action { display: flex; align-items: center; justify-content: center; padding: 12px 8px; border-radius: 10px; text-align: center; text-decoration: none; font-weight: bold; font-size: 11px; text-transform: uppercase; cursor: pointer; border: none; color: white; white-space: normal; line-height: 1.3; }
        .btn-kml { background: #dc2626; } .btn-3d { background: #3b82f6; } .btn-2d { background: #444; }
        .btn-full-day { background: #059669; } .btn-full-day.active { background: #059669; border: 2px solid #fff; }
        #btn-actions-row { display: flex; flex-wrap: nowrap; gap: 8px; margin-top: 8px; }
        #btn-actions-row .btn-action { flex: 1; min-height: 60px; }
        
        .summary-day { background: #059669; color: white; padding: 15px; margin: 10px; border-radius: 8px; text-align: center; }
        .trajet-card { background: #2a2a2a; border-radius: 8px; padding: 15px; margin: 10px; cursor: pointer; border: 2px solid transparent; }
        .trajet-card.active { border-color: #dc2626; background: #331a1a; }
        
        #replay-bar { position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,0.85); padding: 15px; border-radius: 30px; display: flex; align-items: center; gap: 12px; z-index: 1000; border: 1px solid #444; cursor: grab; user-select: none; touch-action: none; }
        #replay-bar:active { cursor: grabbing; }
        .play-btn, .save-video-btn { background: #dc2626; border: none; color: white; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; font-size: 18px; display: flex; align-items: center; justify-content: center; }
        .save-video-btn { background: #3b82f6; }

        #gen-overlay { display: none; position: absolute; inset: 0; background: rgba(0,0,0,0.9); z-index: 2000; flex-direction: column; align-items: center; justify-content: center; }
        .progress-box { width: 300px; background: #333; height: 8px; border-radius: 4px; margin-top: 15px; overflow: hidden; }
        .progress-bar { width: 0%; height: 100%; background: #3b82f6; transition: 0.1s; }
        
        #info-box { 
            position: absolute; top: 15px; left: 50%; transform: translateX(-50%); 
            z-index: 1000; background: rgba(0,0,0,0.85); color: white; 
            padding: 10px 20px; border-radius: 20px; font-size: 13px; 
            border: 1px solid #444; display: none; pointer-events: none;
            white-space: nowrap; box-shadow: 0 4px 15px rgba(0,0,0,0.5);
        }
        #info-box span.item { margin: 0 10px; }
        #info-box .stats-divider { border-left: 1px solid #555; height: 20px; margin: 0 10px; }

        #speed-legend {
            position: absolute; bottom: 25px; right: 25px; 
            z-index: 1000; background: rgba(0,0,0,0.85); color: white; 
            padding: 12px; border-radius: 8px; font-size: 11px; 
            border: 1px solid #444; display: none; cursor: grab; user-select: none; touch-action: none;
        }
        #speed-legend:active { cursor: grabbing; }
        .legend-title { font-weight: bold; margin-bottom: 8px; font-size: 10px; text-transform: uppercase; color: #888; border-bottom: 1px solid #333; padding-bottom: 4px; }
        .legend-row { display: flex; align-items: center; margin-bottom: 4px; gap: 8px; }
        .color-dot { width: 10px; height: 10px; border-radius: 2px; }

        .custom-marker { display: flex; align-items: center; justify-content: center; font-weight: bold; color: white; border: 2px solid white; border-radius: 50%; width: 22px; height: 22px; font-size: 10px; cursor: pointer; }
        .pause-marker { background: #3b82f6; border: 2px solid #fff; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 10px; color: white; box-shadow: 0 0 10px rgba(0,0,0,0.5); }
        .charge-marker { background: #f59e0b; border: 2px solid #fff; border-radius: 50%; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; font-size: 14px; box-shadow: 0 0 10px rgba(245,158,11,0.6); cursor: pointer; }
        .alt-max-marker { background: #dc2626; color: white; font-weight: 900; font-size: 14px; width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 0 6px rgba(220,38,38,0.8); cursor: pointer; line-height: 1; }
        .alt-min-marker { background: #3b82f6; color: white; font-weight: 900; font-size: 14px; width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 0 6px rgba(59,130,246,0.8); cursor: pointer; line-height: 1; }
        .snap-btn { position: absolute; top: 15px; right: 50px; z-index: 1000; padding: 8px 12px; background: rgba(5, 150, 105, 0.85); color: white; border-radius: 6px; font-size: 11px; cursor: pointer; border: 1px solid rgba(255,255,255,0.2); }
        #sidebar-toggle { display: none; }

        /* ===== RESPONSIVE MOBILE / TABLETTE ===== */
        @media (max-width: 768px) {
            body { flex-direction: column; height: 100dvh; overflow: hidden; }

            /* Sidebar : panneau compact en haut, hauteur réduite */
            #sidebar {
                width: 100%;
                height: auto;
                max-height: 38vh;
                border-right: none;
                border-bottom: 2px solid #333;
                overflow: hidden;
                flex-shrink: 0;
                transition: max-height 0.35s ease;
            }
            #sidebar.collapsed {
                max-height: 0 !important;
                border-bottom: none;
            }

            /* Bouton toggle sidebar */
            #sidebar-toggle {
                display: flex; align-items: center; justify-content: center;
                position: absolute;
                top: 50px; right: 10px;
                z-index: 500;
                width: 36px; height: 36px;
                background: rgba(30,30,30,0.92);
                border-radius: 8px;
                cursor: pointer;
                border: 1px solid #444;
                box-shadow: 0 2px 6px rgba(0,0,0,0.4);
            }
            #sidebar-toggle svg {
                width: 16px; height: 16px;
                stroke: #dc2626; fill: none; stroke-width: 2.5;
                transition: transform 0.35s ease;
            }
            #sidebar-toggle.collapsed svg { transform: rotate(180deg); }

            /* Header : compact, une seule ligne */
            .header { padding: 8px 12px; }
            .top-nav { margin-bottom: 6px; gap: 8px; }
            h1 { font-size: 15px !important; }
            .back-button { width: 30px; height: 30px; flex-shrink: 0; }
            #header-toggle { padding: 2px; }

            /* Masquer la recherche et les labels sur mobile — trop encombrant */
            .search-box { display: none; }
            .header > label { display: none; }
            #header-controls > label { display: none; }

            /* Véhicule + date : côte à côte sur une ligne */
            #header-controls {
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
                align-items: center;
            }
            #header-controls .input-field {
                flex: 1;
                min-width: 120px;
                padding: 7px 8px;
                font-size: 13px;
                margin-bottom: 0;
            }

            /* Boutons d'action : ligne compacte */
            #btn-actions-row {
                width: 100%;
                display: flex;
                gap: 5px;
                margin-top: 0;
            }
            #btn-actions-row .btn-action {
                flex: 1;
                min-height: unset;
                padding: 7px 4px;
                font-size: 9px;
            }
            .btn-analyse { font-size: 9px; padding: 7px 6px; }

            /* Liste des trajets : horizontale scrollable */
            #sidebar > div[style*="flex:1"] {
                display: flex;
                flex-direction: row;
                overflow-x: auto;
                overflow-y: hidden;
                padding: 6px 10px;
                gap: 8px;
                flex: none;
                -webkit-overflow-scrolling: touch;
            }
            .trajet-card {
                min-width: 120px; max-width: 140px;
                padding: 8px 10px;
                margin: 0; flex-shrink: 0;
                font-size: 12px;
            }
            .summary-day {
                margin: 4px 10px;
                padding: 8px 12px;
                flex-shrink: 0;
            }
            .summary-day > div:first-child { font-size: 9px; }
            .summary-day > div:last-child { font-size: 18px !important; }

            /* Zone carte : prend tout le reste */
            #main-viz { flex: 1; min-height: 0; position: relative; }
            #map, #plot3d { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }

            /* Info-box : compacte, centrée en haut */
            #info-box {
                top: 8px; left: 8px; right: 54px;
                transform: none; width: auto;
                font-size: 10px; padding: 6px 10px;
                white-space: normal; flex-wrap: wrap;
                gap: 3px; justify-content: center;
            }
            #info-box span.item { margin: 0 3px; }
            #info-box .stats-divider { display: none; }

            /* Légende vitesse masquée */
            #speed-legend { display: none !important; }

            /* Replay bar : compacte en bas */
            #replay-bar {
                bottom: 10px; left: 50%; transform: translateX(-50%);
                padding: 8px 12px; gap: 6px;
                max-width: calc(100% - 30px);
                border-radius: 20px;
            }
            #replay-bar input[type="range"] { width: 90px; min-width: 60px; }
            .play-btn, .save-video-btn { width: 32px; height: 32px; font-size: 14px; flex-shrink: 0; }

            /* Snap button */
            .snap-btn { top: auto; bottom: 80px; right: 10px; font-size: 10px; padding: 6px 9px; }

            /* Leaflet décalé */
            .leaflet-top.leaflet-right { top: 90px; }

            /* Panneau analyse : pleine largeur en bas sur mobile */
            #analyse-panel {
                top: auto !important; bottom: 10px;
                left: 10px !important; right: 10px;
                width: auto; max-height: 60vh;
            }
        }

        /* Petits mobiles */
        @media (max-width: 420px) {
            #sidebar { max-height: 35vh; }
            .trajet-card { min-width: 105px; font-size: 11px; }
            #info-box { font-size: 9px; }
            .leaflet-top.leaflet-right { top: 95px; }
        }

        /* --- Panneau flottant Analyse conduite --- */
        #analyse-panel {
            display: none;
            position: absolute;
            top: 60px; right: 14px;
            width: 290px;
            background: rgba(15,15,15,0.97);
            border: 1px solid #333;
            border-radius: 14px;
            padding: 16px;
            z-index: 900;
            box-shadow: 0 8px 32px rgba(0,0,0,0.7);
            overflow-y: auto;
            max-height: calc(100% - 80px);
        }
        #analyse-panel.visible { display: block; }
        #analyse-panel { font-size: calc(var(--an-scale, 1) * 13px); }
        .an-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; cursor: move; user-select: none; gap: 6px; }
        .an-title { font-size: 1.08em; font-weight: 700; color: #fff; flex: 1; }
        .an-size-btn { background: #2a2a2a; border: 1px solid #444; color: #aaa; font-size: 11px; font-weight: 700; width: 22px; height: 22px; border-radius: 4px; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: background 0.15s; }
        .an-size-btn:hover { background: #444; color: #fff; }
        .an-title { font-size: 14px; font-weight: 700; color: #fff; }
        .an-close { background: none; border: none; color: #888; font-size: 1.4em; cursor: pointer; line-height: 1; padding: 0 2px; flex-shrink: 0; }
        .an-close:hover { color: #fff; }
        .an-kpis { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 12px; }
        .an-kpi { background: #1a1a1a; border-radius: 8px; padding: 8px 10px; border: 1px solid #2a2a2a; }
        .an-kpi-lbl { font-size: 0.77em; color: #666; text-transform: uppercase; margin-bottom: 2px; }
        .an-kpi-val { font-size: 1.3em; font-weight: 700; color: #fff; }
        .an-kpi-unit { font-size: 0.77em; color: #666; }
        .an-ring { display: flex; flex-direction: column; align-items: center; margin: 8px 0 12px; }
        .an-ring-lbl { font-size: 0.92em; color: #888; margin-top: 4px; }
        .an-bars { margin-bottom: 12px; }
        .an-bar-row { display: flex; align-items: center; gap: 8px; margin-bottom: 7px; }
        .an-bar-lbl { font-size: 0.85em; color: #777; width: 110px; flex-shrink: 0; }
        .an-bar-track { flex: 1; height: 6px; background: #2a2a2a; border-radius: 3px; overflow: hidden; }
        .an-bar-fill { height: 100%; border-radius: 3px; transition: width 0.6s ease; }
        .an-bar-val { font-size: 0.85em; font-weight: 600; width: 26px; text-align: right; }
        .an-verdict { border-radius: 10px; padding: 10px 12px; display: flex; align-items: center; gap: 10px; }
        .an-verdict-icon { font-size: 1.7em; flex-shrink: 0; }
        .an-verdict-title { font-size: 1em; font-weight: 700; color: #fff; }
        .an-verdict-sub { font-size: 0.85em; color: #aaa; margin-top: 2px; }
        .btn-analyse { background: #1a1a2e; border: 1px solid #444; color: #ccc; font-size: 11px; padding: 6px 10px; border-radius: 6px; cursor: pointer; transition: background 0.2s; }
        .btn-analyse:hover { background: #dc2626; border-color: #dc2626; color: #fff; }
        #header-controls { overflow: hidden; transition: max-height 0.3s ease, opacity 0.3s ease; max-height: 600px; opacity: 1; }
        #header-controls.collapsed { max-height: 0; opacity: 0; pointer-events: none; }
        #header-toggle { margin-left: auto; }
    </style>
</head>
<body>

<div id="gen-overlay">
    <div style="font-weight:bold; font-size:18px; color:#fff;">GÉNÉRATION VIDÉO COMPATIBLE</div>
    <div id="gen-status" style="margin-top:5px; font-size:12px; color:#aaa;">Préparation...</div>
    <div class="progress-box"><div id="p-bar" class="progress-bar"></div></div>
</div>

<div id="sidebar">
    <div class="header">
        <div class="top-nav">
            <a href="tesla.php" class="back-button"><svg viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></a>
            <h1 style="margin:0; font-size:18px; color:#dc2626;"><?= $txt['title'] ?></h1>
            <button id="header-toggle" onclick="toggleHeaderControls()" title="Masquer/afficher les contrôles" style="background:none;border:none;cursor:pointer;padding:4px;color:#aaa;display:flex;align-items:center;">
                <svg id="header-toggle-icon" viewBox="0 0 24 24" style="width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;transition:transform 0.3s;"><path d="M18 15l-6-6-6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>
        </div>

        <div id="header-controls">
        <div class="search-box">
            <input type="text" id="citySearch" placeholder="<?= $txt['search_placeholder'] ?>" value="<?= htmlspecialchars($search_query ?? '') ?>" onkeypress="if(event.key === 'Enter') searchCity()">
            <div class="search-icons">
                <?php if($search_query): ?>
                    <svg class="close-icon" onclick="clearSearch()" viewBox="0 0 24 24" style="fill:#dc2626;"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                <?php endif; ?>
                <svg onclick="searchCity()" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
            </div>
        </div>

        <label><?= $txt['vehicle'] ?></label>
        <div style="display:flex;gap:6px;align-items:center;">
        <select id="selectVehicle" class="input-field" style="margin-bottom:0;flex:1;">
            <?php foreach ($cars as $car): ?>
                <option value="<?= $car['id'] ?>" <?= $selected_car_id == $car['id'] ? 'selected' : '' ?>><?= htmlspecialchars($car['display_name']) ?></option>
            <?php endforeach; ?>
        </select>
        <button id="btnGoVehicle" onclick="location.href='?date=<?= $selected_date ?>&car_id='+document.getElementById('selectVehicle').value" style="background:#dc2626;border:none;color:white;padding:8px 12px;border-radius:6px;cursor:pointer;font-weight:bold;white-space:nowrap;">GO</button>
        </div>

        <label><?= $txt['date'] ?></label>
        <div style="display:flex;gap:6px;align-items:center;">
            <!-- Flèche précédent -->
            <button onclick="location.href='?car_id=<?= $selected_car_id ?>&date=<?= $prev_date ?>'"
                style="background:#333;border:1px solid #555;color:#fff;width:36px;height:36px;border-radius:6px;cursor:pointer;font-size:16px;flex-shrink:0;display:flex;align-items:center;justify-content:center;">◀</button>
            <input type="date" id="inputDate" class="input-field" value="<?= $selected_date ?>" style="margin-bottom:0;flex:1;">
            <!-- Flèche suivant -->
            <?php if ($next_date): ?>
            <button onclick="location.href='?car_id=<?= $selected_car_id ?>&date=<?= $next_date ?>'"
                style="background:#333;border:1px solid #555;color:#fff;width:36px;height:36px;border-radius:6px;cursor:pointer;font-size:16px;flex-shrink:0;display:flex;align-items:center;justify-content:center;">▶</button>
            <?php else: ?>
            <button disabled style="background:#222;border:1px solid #333;color:#555;width:36px;height:36px;border-radius:6px;font-size:16px;flex-shrink:0;display:flex;align-items:center;justify-content:center;cursor:not-allowed;">▶</button>
            <?php endif; ?>
            <!-- Bouton plage -->
            <button id="btnToggleRange" onclick="toggleRangePanel()"
                title="Sélectionner une plage de dates"
                style="background:<?= $is_range_mode ? '#7c3aed' : '#333' ?>;border:1px solid <?= $is_range_mode ? '#7c3aed' : '#555' ?>;color:#fff;width:36px;height:36px;border-radius:6px;cursor:pointer;font-size:16px;flex-shrink:0;display:flex;align-items:center;justify-content:center;">📅</button>
        </div>

        <!-- Panneau plage de dates -->
        <div id="range-panel" style="display:<?= $is_range_mode ? 'block' : 'none' ?>;background:#222;border:1px solid #7c3aed;border-radius:8px;padding:10px;margin-top:8px;">
            <div style="font-size:10px;color:#a78bfa;text-transform:uppercase;margin-bottom:6px;">📅 Plage de dates</div>
            <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
                <div style="flex:1;min-width:110px;">
                    <div style="font-size:9px;color:#888;margin-bottom:3px;"><?= $txt['date_from'] ?></div>
                    <input type="date" id="inputDateFrom" class="input-field" value="<?= htmlspecialchars($date_from ?? $selected_date) ?>" style="margin-bottom:0;padding:7px 8px;">
                </div>
                <div style="flex:1;min-width:110px;">
                    <div style="font-size:9px;color:#888;margin-bottom:3px;"><?= $txt['date_to'] ?></div>
                    <input type="date" id="inputDateTo" class="input-field" value="<?= htmlspecialchars($date_to ?? $selected_date) ?>" style="margin-bottom:0;padding:7px 8px;">
                </div>
                <button onclick="applyRange()"
                    style="background:#7c3aed;border:none;color:#fff;padding:8px 14px;border-radius:6px;cursor:pointer;font-weight:bold;font-size:12px;align-self:flex-end;white-space:nowrap;">OK</button>
            </div>
            <?php if ($is_range_mode): ?>
            <div style="margin-top:6px;font-size:10px;color:#a78bfa;">
                <?= htmlspecialchars($date_from) ?> → <?= htmlspecialchars($date_to) ?>
                &nbsp;|&nbsp; <?= number_format($total_day_km, 1, ',', ' ') ?> km
                &nbsp;<a href="?car_id=<?= $selected_car_id ?>&date=<?= $selected_date ?>" style="color:#f87171;font-size:10px;">✕ Quitter</a>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($positions)): ?>
            <div id="btn-actions-row" style="margin-top:10px;">
                <?php if ($is_range_mode): ?>
                <a href="?car_id=<?= $selected_car_id ?>&date_from=<?= $date_from ?>&date_to=<?= $date_to ?>&full_period=1" class="btn-action <?= $is_full_period ? 'btn-full-day active' : 'btn-full-day' ?>"><?= $txt['btn_full_period'] ?></a>
                <?php else: ?>
                <a href="?car_id=<?= $selected_car_id ?>&date=<?= $selected_date ?>&full_day=1" class="btn-action btn-full-day <?= ($is_full_day && !$selected_drive_id) ? 'active' : '' ?>"><?= $txt['btn_full_day'] ?></a>
                <?php endif; ?>
                <a href="?export_kml=1&<?= $selected_drive_id ? "drive_id=$selected_drive_id" : "car_id=$selected_car_id&date=$selected_date" ?>" class="btn-action btn-kml"><?= $txt['btn_kml'] ?></a>
                <button id="btnShow3D" class="btn-action btn-3d" onclick="toggleVision('3D')"><?= $txt['btn_3d'] ?></button>
                <button id="btnShow2D" class="btn-action btn-2d" style="display:none;" onclick="toggleVision('2D')"><?= $txt['btn_2d'] ?></button>
                <button class="btn-analyse" onclick="showAnalyse()"><?= $txt['btn_analyse'] ?></button>
            </div>
        <?php else: ?>
            <div id="btn-actions-row" style="margin-top:10px;">
                <?php if ($is_range_mode): ?>
                <a href="?car_id=<?= $selected_car_id ?>&date_from=<?= $date_from ?>&date_to=<?= $date_to ?>&full_period=1" class="btn-action <?= $is_full_period ? 'btn-full-day active' : 'btn-full-day' ?>"><?= $txt['btn_full_period'] ?></a>
                <?php else: ?>
                <a href="?car_id=<?= $selected_car_id ?>&date=<?= $selected_date ?>&full_day=1" class="btn-action btn-full-day <?= ($is_full_day && !$selected_drive_id) ? 'active' : '' ?>"><?= $txt['btn_full_day'] ?></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        </div><!-- #header-controls -->
    </div>

    <?php if ($is_range_mode && !$is_full_period): ?>
        <!-- MODE PLAGE : résumé par jour -->
        <div class="summary-day" style="background:#4c1d95;">
            <div style="font-size:10px; opacity:0.8;"><?= $txt['period_km'] ?></div>
            <div style="font-size:24px; font-weight:800;"><?= number_format($total_day_km, 1, ',', ' ') ?> km</div>
            <div style="font-size:10px;opacity:0.7;margin-top:2px;"><?= htmlspecialchars($date_from) ?> → <?= htmlspecialchars($date_to) ?></div>
        </div>
        <div style="flex:1; overflow-y:auto;">
            <?php if (empty($range_days)): ?>
                <div style="padding:20px;text-align:center;color:#555;font-size:13px;">Aucun trajet sur cette période</div>
            <?php endif; ?>
            <?php foreach ($range_days as $rd): ?>
                <?php $day_url = "?car_id=$selected_car_id&date={$rd['day']}&date_from=$date_from&date_to=$date_to&full_day=1"; ?>
                <div class="trajet-card" onclick="location.href='<?= $day_url ?>'" style="border-left:3px solid #7c3aed;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <span style="font-weight:bold;color:#a78bfa;"><?= date('d/m', strtotime($rd['day'])) ?></span>
                        <span style="color:#dc2626;font-weight:bold;"><?= number_format($rd['total_km'], 1, ',', '.') ?> km</span>
                    </div>
                    <div style="font-size:11px;color:#aaa;margin-top:3px;"><?= $rd['nb_trajets'] ?> trajet<?= $rd['nb_trajets'] > 1 ? 's' : '' ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php elseif ($is_full_day && !$selected_drive_id): ?>
        <div class="summary-day">
            <div style="font-size:10px; opacity:0.8;"><?= $txt['total_km'] ?></div>
            <div style="font-size:24px; font-weight:800;"><?= number_format($total_day_km, 1, ',', ' ') ?> km</div>
        </div>
        <div style="flex:1; overflow-y:auto;">
            <?php foreach ($trajets as $t): ?>
                <?php $trip_url = "?car_id=$selected_car_id&drive_id={$t['id']}&date=$selected_date" . ($is_range_mode ? "&date_from=$date_from&date_to=$date_to" : "") . ($search_query ? "&search=".urlencode($search_query)."&lat=$search_lat&lng=$search_lng" : ""); ?>
                <div class="trajet-card <?= $selected_drive_id == $t['id'] ? 'active' : '' ?>" onclick="location.href='<?= $trip_url ?>'">
                    <div style="display:flex; justify-content:space-between;">
                        <span style="font-weight:bold;"><?= date('H:i', strtotime($t['start_date_local'])) ?></span>
                        <span style="color:#dc2626; font-weight:bold;"><?= $t['km'] ?> km</span>
                    </div>
                    <div style="font-size:11px; color:#aaa; margin-top:5px;"><?= $txt['to'] ?> : <?= htmlspecialchars($t['end_point'] ?? $txt['unknown']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="flex:1; overflow-y:auto;">
            <?php foreach ($trajets as $t): ?>
                <?php $trip_url = "?car_id=$selected_car_id&drive_id={$t['id']}&date=$selected_date" . ($search_query ? "&search=".urlencode($search_query)."&lat=$search_lat&lng=$search_lng" : ""); ?>
                <div class="trajet-card <?= $selected_drive_id == $t['id'] ? 'active' : '' ?>" onclick="location.href='<?= $trip_url ?>'">
                    <div style="display:flex; justify-content:space-between;">
                        <span style="font-weight:bold;"><?= date('H:i', strtotime($t['start_date_local'])) ?></span>
                        <span style="color:#dc2626; font-weight:bold;"><?= $t['km'] ?> km</span>
                    </div>
                    <div style="font-size:11px; color:#aaa; margin-top:5px;"><?= $txt['to'] ?> : <?= htmlspecialchars($t['end_point'] ?? $txt['unknown']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<div id="main-viz">
    <button id="sidebar-toggle" onclick="toggleSidebar()" title="Masquer/afficher le panneau">
        <svg viewBox="0 0 24 24"><path d="M18 15l-6-6-6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
    <button class="snap-btn" onclick="takeSnapshot()"><?= $txt['btn_snap'] ?></button>
    
    <div id="info-box">
        <span class="item">⏱️ <b><?= $txt['duration'] ?>:</b> <?= $trip_duration_str ?></span>
        <span class="item">🌡️ <span id="info-temp">--</span>°C</span>
        <span class="item">⏲️ <span id="info-speed">--</span> km/h</span>
        <span class="item">⛰️ <span id="info-elevation">--</span> m</span>
        <span class="item">🔋 <span id="info-battery">--</span>%</span>
        <div class="stats-divider"></div>
        <span class="item">🏁 <b><?= $txt['vmax'] ?>:</b> <?= round($v_max_trip) ?> km/h</span>
    </div>

    <div id="map"></div>
    <div id="plot3d"></div>

    <div id="speed-legend">
        <div class="legend-title"><?= $txt['legend_speed'] ?></div>
        <div class="legend-row"><div class="color-dot" style="background:#7f1d1d;"></div> > 131</div>
        <div class="legend-row"><div class="color-dot" style="background:#dc2626;"></div> 111 - 130</div>
        <div class="legend-row"><div class="color-dot" style="background:#ea580c;"></div> 91 - 110</div>
        <div class="legend-row"><div class="color-dot" style="background:#f97316;"></div> 81 - 90</div>
        <div class="legend-row"><div class="color-dot" style="background:#eab308;"></div> 71 - 80</div>
        <div class="legend-row"><div class="color-dot" style="background:#84cc16;"></div> 51 - 70</div>
        <div class="legend-row"><div class="color-dot" style="background:#22c55e;"></div> 0 - 50</div>
    </div>

    <?php if(!empty($positions)): ?>
    <div id="replay-bar">
        <div id="rb-handle" style="display:flex;flex-direction:column;gap:3px;flex-shrink:0;opacity:0.5;padding-right:4px;">
            <span style="display:block;width:16px;height:2px;background:#fff;border-radius:1px;"></span>
            <span style="display:block;width:16px;height:2px;background:#fff;border-radius:1px;"></span>
            <span style="display:block;width:16px;height:2px;background:#fff;border-radius:1px;"></span>
        </div>
        <button class="play-btn" id="playBtn" onclick="togglePlay()">▶</button>
        <select id="speedSelector" style="background: #333; color: white; border: 1px solid #444; border-radius: 4px; padding: 5px; font-size: 11px; cursor: pointer;">
            <option value="1">x1</option>
            <option value="5">x5</option>
            <option value="10" selected>x10</option>
            <option value="20">x20</option>
        </select>
        <button class="save-video-btn" title="Générer Vidéo" onclick="generateVideoFast()">💾</button>
        <input type="range" id="replayRange" min="0" max="<?= count($positions)-1 ?>" value="0" oninput="updateCarPos(this.value)">
    </div>
    <?php endif; ?>

    <!-- Panneau flottant analyse conduite -->
    <div id="analyse-panel">
        <div class="an-header">
            <span class="an-title"><?= $txt['an_title'] ?></span>
            <button class="an-size-btn" onclick="resizeAnalyse(-1)" title="Réduire">A−</button>
            <button class="an-size-btn" onclick="resizeAnalyse(+1)" title="Agrandir">A+</button>
            <button class="an-close" onclick="document.getElementById('analyse-panel').classList.remove('visible')">✕</button>
        </div>
        <div id="analyse-content"><p style="color:#666;font-size:12px;text-align:center">...</p></div>
    </div>

</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    const pos = <?= json_encode($positions) ?>;
    const isSingleDrive = <?= $selected_drive_id ? 'true' : 'false' ?>;
    const pauses = <?= json_encode($pauses) ?>;

    // Traductions JS
    const i18n = {
        charge:      <?= json_encode($lang==='fr' ? '⚡ Charge' : '⚡ Charge') ?>,
        added:       <?= json_encode($lang==='fr' ? 'Ajoutés' : 'Added') ?>,
        used:        <?= json_encode($lang==='fr' ? 'Consommés' : 'Used') ?>,
        duration:    <?= json_encode($lang==='fr' ? 'Durée' : 'Duration') ?>,
        altitude:    <?= json_encode($lang==='fr' ? 'Altitude' : 'Altitude') ?>,
        temp_ext:    <?= json_encode($lang==='fr' ? 'Temp. ext.' : 'Outside temp.') ?>,
        battery:     <?= json_encode($lang==='fr' ? 'Batterie' : 'Battery') ?>,
        pause:       <?= json_encode($lang==='fr' ? 'Pause' : 'Stop') ?>,
        depart:      <?= json_encode($lang==='fr' ? 'Départ' : 'Start') ?>,
        arrivee:     <?= json_encode($lang==='fr' ? 'Arrivée' : 'Arrival') ?>,
        min:         <?= json_encode($lang==='fr' ? 'min' : 'min') ?>,
        alt_max:     <?= json_encode($lang==='fr' ? 'Altitude max.' : 'Max. altitude') ?>,
        alt_min:     <?= json_encode($lang==='fr' ? 'Altitude min.' : 'Min. altitude') ?>,
        bat_temp:    <?= json_encode($lang==='fr' ? 'Temp. batterie' : 'Battery temp.') ?>,
        bat_heater:  <?= json_encode($lang==='fr' ? 'Chauffe batterie' : 'Battery heater') ?>,
        on:          <?= json_encode($lang==='fr' ? 'ON' : 'ON') ?>,
        off:         <?= json_encode($lang==='fr' ? 'OFF' : 'OFF') ?>,
    };
    
    // Configuration des couches de carte
    const nightLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { crossOrigin: 'anonymous' });
    const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri', crossOrigin: 'anonymous'
    });
    const hybridLayer = L.layerGroup([
        satelliteLayer,
        L.tileLayer('https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png', { 
            pane: 'shadowPane', crossOrigin: 'anonymous' 
        })
    ]);

    const map = L.map('map', { 
        preferCanvas: true,
        layers: [nightLayer]
    }).setView([46, 2], 6);

    const baseMaps = {
        "<?= $txt['layer_plan'] ?>": nightLayer,
        "<?= $txt['layer_sat'] ?>": satelliteLayer,
        "<?= $txt['layer_hybrid'] ?>": hybridLayer
    };
    L.control.layers(baseMaps, null, {position: 'topright'}).addTo(map);

    let carMarker = L.circleMarker([0,0], {radius: 8, color: '#fff', fillColor: '#dc2626', fillOpacity: 1, weight: 3, zIndexOffset:1000}).addTo(map);
    let pathLine = null;
    let playInterval = null;

    function getSpeedColor(speed) {
        if (speed <= 50) return '#22c55e';
        if (speed <= 70) return '#84cc16';
        if (speed <= 80) return '#eab308';
        if (speed <= 90) return '#f97316';
        if (speed <= 110) return '#ea580c';
        if (speed <= 130) return '#dc2626';
        return '#7f1d1d';
    }

    if(pos.length > 0) {
        document.getElementById('speed-legend').style.display = 'block';
        let latlngs = pos.map(p => [parseFloat(p.latitude), parseFloat(p.longitude)]);
        
        for(let i = 0; i < pos.length - 1; i++) {
            const speed = parseFloat(pos[i].speed) || 0;
            const nextSpeed = parseFloat(pos[i+1].speed) || 0;
            const avgSpeed = (speed + nextSpeed) / 2;
            let color = getSpeedColor(avgSpeed);
            
            let segment = L.polyline([
                [parseFloat(pos[i].latitude), parseFloat(pos[i].longitude)],
                [parseFloat(pos[i+1].latitude), parseFloat(pos[i+1].longitude)]
            ], {color: color, weight: 6, opacity: 0.8}).addTo(map);

            segment.on('mouseover', function() {
                document.getElementById('info-box').style.display = 'flex';
                this.setStyle({weight: 12, opacity: 1});
                updateInfoBox(i);
            });
            segment.on('mouseout', function() {
                this.setStyle({weight: 6, opacity: 0.8});
            });
            // Touch Tesla : tap sur segment affiche l'infobox
            segment.on('click', function() {
                document.getElementById('info-box').style.display = 'flex';
                this.setStyle({weight: 12, opacity: 1});
                updateInfoBox(i);
                setTimeout(() => this.setStyle({weight: 6, opacity: 0.8}), 1500);
            });
        }
        
        pathLine = L.polyline(latlngs, {color: 'transparent', weight: 15, zIndex: 500}).addTo(map);
        pathLine.on('mousemove', function(e) {
            let minDest = Infinity;
            let closestIdx = 0;
            pos.forEach((p, idx) => {
                let d = e.latlng.distanceTo([p.latitude, p.longitude]);
                if(d < minDest) { minDest = d; closestIdx = idx; }
            });
            document.getElementById('info-box').style.display = 'flex';
            updateInfoBox(closestIdx);
        });

        if(isSingleDrive) {
            const batStart = pos[0].battery_level ? ` | <?= $txt['battery'] ?>: ${pos[0].battery_level}%` : '';
            const batEnd = pos[pos.length-1].battery_level ? ` | <?= $txt['battery'] ?>: ${pos[pos.length-1].battery_level}%` : '';

            L.marker(latlngs[0], {
                icon: L.divIcon({className:'custom-marker', html:'<?= $txt['start'] ?>', iconAnchor:[11,11]}),
                title: '<?= $txt['start'] ?>' + batStart
            }).addTo(map).getElement().style.backgroundColor='#22c55e';
            
            L.marker(latlngs[latlngs.length-1], {
                icon: L.divIcon({className:'custom-marker', html:'<?= $txt['end'] ?>', iconAnchor:[11,11]}),
                title: '<?= $txt['end'] ?>' + batEnd
            }).addTo(map).getElement().style.backgroundColor='#dc2626';
            // Afficher l'éclair de charge après le trajet (si applicable)
            pauses.forEach(p => {
                if (p.is_charge) {
                    const h = Math.floor(p.duree_charge / 60);
                    const m = p.duree_charge % 60;
                    const dureeStr = h > 0 ? `${h}h${String(m).padStart(2,'0')}` : `${m} ${i18n.min}`;
                    const altStr  = p.elevation !== null ? ` | ⛰️ ${p.elevation} m` : '';
                    const tempStr = p.temp !== null ? ` | 🌡️ ${p.temp}°C` : '';
                    const batStr  = (p.bat_start != null && p.bat_end != null) ? ` | 🔋 ${p.bat_start}%→${p.bat_end}%` : '';
                    const tooltip = `⚡ ${i18n.charge} : ${p.kwh_added} kWh / ${p.kwh_used} kWh\n⏱️ ${i18n.duration} : ${dureeStr}${altStr}${tempStr}${batStr}`;
                    const heaterStr = p.bat_heater != null ? `<br>🔥 ${i18n.bat_heater} : <b style="color:${p.bat_heater ? '#f97316' : '#60a5fa'}">${p.bat_heater ? i18n.on : i18n.off}</b>` : '';
                    L.marker([p.lat, p.lng], {
                        icon: L.divIcon({className: 'charge-marker', html: '⚡', iconAnchor: [13, 13]}),
                        title: tooltip
                    }).addTo(map).bindPopup(
                        `<b>⚡ ${i18n.charge}</b><br>` +
                        `${i18n.added} : <b>${p.kwh_added} kWh</b><br>` +
                        `${i18n.used} : <b>${p.kwh_used} kWh</b><br>` +
                        `${i18n.duration} : <b>${dureeStr}</b>` +
                        (p.bat_start != null && p.bat_end != null ? `<br>🔋 ${i18n.battery} : <b>${p.bat_start}% → ${p.bat_end}%</b>` : '') +
                        (p.bat_temp_start != null && p.bat_temp_end != null ? `<br>🌡️ ${i18n.bat_temp} : <b>${p.bat_temp_start}°C → ${p.bat_temp_end}°C</b>` : '') +
                        heaterStr +
                        (p.elevation !== null ? `<br>⛰️ ${i18n.altitude} : <b>${p.elevation} m</b>` : '') +
                        (p.temp !== null ? `<br>🌡️ ${i18n.temp_ext} : <b>${p.temp}°C</b>` : '')
                    );
                }
            });
        } else {
            pauses.forEach(p => {
                if (p.is_charge) {
                    const h = Math.floor(p.duree_charge / 60);
                    const m = p.duree_charge % 60;
                    const dureeStr = h > 0 ? `${h}h${String(m).padStart(2,'0')}` : `${m} ${i18n.min}`;
                    const altStr  = p.elevation !== null ? ` | ⛰️ ${p.elevation} m` : '';
                    const tempStr = p.temp !== null ? ` | 🌡️ ${p.temp}°C` : '';
                    const batStr  = (p.bat_start != null && p.bat_end != null) ? ` | 🔋 ${p.bat_start}%→${p.bat_end}%` : '';
                    const tooltip = `⚡ ${i18n.charge} : ${p.kwh_added} kWh / ${p.kwh_used} kWh\n⏱️ ${i18n.duration} : ${dureeStr}${altStr}${tempStr}${batStr}`;
                    const heaterStr = p.bat_heater != null ? `<br>🔥 ${i18n.bat_heater} : <b style="color:${p.bat_heater ? '#f97316' : '#60a5fa'}">${p.bat_heater ? i18n.on : i18n.off}</b>` : '';
                    L.marker([p.lat, p.lng], {
                        icon: L.divIcon({className: 'charge-marker', html: '⚡', iconAnchor: [13, 13]}),
                        title: tooltip
                    }).addTo(map).bindPopup(
                        `<b>⚡ ${i18n.charge}</b><br>` +
                        `${i18n.added} : <b>${p.kwh_added} kWh</b><br>` +
                        `${i18n.used} : <b>${p.kwh_used} kWh</b><br>` +
                        `${i18n.duration} : <b>${dureeStr}</b>` +
                        (p.bat_start != null && p.bat_end != null ? `<br>🔋 ${i18n.battery} : <b>${p.bat_start}% → ${p.bat_end}%</b>` : '') +
                        (p.bat_temp_start != null && p.bat_temp_end != null ? `<br>🌡️ ${i18n.bat_temp} : <b>${p.bat_temp_start}°C → ${p.bat_temp_end}°C</b>` : '') +
                        heaterStr +
                        (p.elevation !== null ? `<br>⛰️ ${i18n.altitude} : <b>${p.elevation} m</b>` : '') +
                        (p.temp !== null ? `<br>🌡️ ${i18n.temp_ext} : <b>${p.temp}°C</b>` : '')
                    );
                } else {
                    const altStr  = p.elevation !== null ? `<br>⛰️ ${i18n.altitude} : <b>${p.elevation} m</b>` : '';
                    const tempStr = p.temp !== null ? `<br>🌡️ ${i18n.temp_ext} : <b>${p.temp}°C</b>` : '';
                    L.marker([p.lat, p.lng], {
                        icon: L.divIcon({className:'pause-marker', html:'P', iconAnchor:[10,10]})
                    }).addTo(map).bindPopup(`${i18n.pause} : ${p.dur} ${i18n.min}${altStr}${tempStr}`);
                }
            });
        }

        // --- Triangles altitude max (rouge ▲) et min (bleu ▽) ---
        if (pos.length > 0) {
            let maxIdx = 0, minIdx = 0;
            pos.forEach((p, i) => {
                if ((p.elevation || 0) > (pos[maxIdx].elevation || 0)) maxIdx = i;
                if ((p.elevation || 0) < (pos[minIdx].elevation || 0)) minIdx = i;
            });
            const fmtAltMarker = (p, label) => {
                const d = new Date(p.date);
                const heure = d.toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'});
                const temp = p.outside_temp !== null && p.outside_temp !== undefined ? ` | 🌡️ ${p.outside_temp}°C` : '';
                return `${label} : ${Math.round(p.elevation || 0)} m | 🕐 ${heure}${temp}`;
            };
            // Max
            const pMax = pos[maxIdx];
            L.marker([pMax.latitude, pMax.longitude], {
                icon: L.divIcon({className:'alt-max-marker', html:'+', iconAnchor:[10,10]}),
                zIndexOffset: 900
            }).addTo(map).bindPopup(`<b>🔴 ${i18n.alt_max}</b><br>⛰️ <b>${Math.round(pMax.elevation||0)} m</b><br>🕐 ${new Date(pMax.date).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}` + (pMax.outside_temp!=null?`<br>🌡️ ${pMax.outside_temp}°C`:''));
            // Min
            const pMin = pos[minIdx];
            L.marker([pMin.latitude, pMin.longitude], {
                icon: L.divIcon({className:'alt-min-marker', html:'−', iconAnchor:[10,10]}),
                zIndexOffset: 900
            }).addTo(map).bindPopup(`<b>🔵 ${i18n.alt_min}</b><br>⛰️ <b>${Math.round(pMin.elevation||0)} m</b><br>🕐 ${new Date(pMin.date).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}` + (pMin.outside_temp!=null?`<br>🌡️ ${pMin.outside_temp}°C`:''));
        }

        map.fitBounds(L.latLngBounds(latlngs), {padding:[50,50]});
        updateCarPos(0);
    }

    function updateInfoBox(idx) {
        if(!pos[idx]) return;
        const infoBox = document.getElementById('info-box');
        infoBox.style.display = 'flex';
        
        const temp = pos[idx].outside_temp || pos[idx].inside_temp || null;
        document.getElementById('info-temp').textContent = temp !== null ? Math.round(temp) : '--';
        document.getElementById('info-speed').textContent = Math.round(pos[idx].speed || 0);
        document.getElementById('info-elevation').textContent = Math.round(pos[idx].elevation || 0);
        document.getElementById('info-battery').textContent = pos[idx].battery_level !== null && pos[idx].battery_level !== undefined ? pos[idx].battery_level : '--';
    }

    function updateCarPos(idx) {
        if(!pos[idx]) return;
        carMarker.setLatLng([pos[idx].latitude, pos[idx].longitude]);
        document.getElementById('replayRange').value = idx;
        updateInfoBox(idx);
    }

    function togglePlay() {
        const btn = document.getElementById('playBtn');
        if(playInterval) { clearInterval(playInterval); playInterval = null; btn.innerText = "▶"; }
        else {
            btn.innerText = "⏸";
            playInterval = setInterval(() => {
                let r = document.getElementById('replayRange');
                let next = parseInt(r.value) + 1;
                if(next < pos.length) updateCarPos(next);
                else { clearInterval(playInterval); playInterval = null; btn.innerText = "▶"; }
            }, 50);
        }
    }

    async function generateVideoFast() {
        const overlay = document.getElementById('gen-overlay');
        const pBar = document.getElementById('p-bar');
        const statusText = document.getElementById('gen-status');
        overlay.style.display = 'flex';
        const speedMultiplier = parseInt(document.getElementById('speedSelector').value) || 10;
        
        document.getElementById('replay-bar').style.display = 'none';
        document.querySelector('.snap-btn').style.display = 'none';
        document.getElementById('speed-legend').style.display = 'none';

        const mapContainer = document.getElementById('map');
        const canvas = document.createElement('canvas');
        const bounds = mapContainer.getBoundingClientRect();
        canvas.width = bounds.width; canvas.height = bounds.height;
        const ctx = canvas.getContext('2d');
        const stream = canvas.captureStream(30);

        const recorder = new MediaRecorder(stream, { 
            mimeType: 'video/mp4;codecs=avc1.42E01E',
            videoBitsPerSecond: 5000000 
        });

        const chunks = [];
        recorder.ondataavailable = e => chunks.push(e.data);
        recorder.onstop = () => {
            const blob = new Blob(chunks, { type: 'video/mp4' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = `tesla_trip_${Date.now()}.mp4`;
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
            location.reload(); 
        };

        recorder.start();
        const totalFrames = pos.length;
        const captureStep = 3 * speedMultiplier;
        const framesToCapture = Math.ceil(totalFrames / captureStep);
        
        for(let frameIndex = 0; frameIndex < framesToCapture; frameIndex++) {
            const i = Math.min(frameIndex * captureStep, totalFrames - 1);
            updateCarPos(i);
            
            await new Promise(r => setTimeout(r, 20));
            const frameCanvas = await html2canvas(mapContainer, { useCORS: true, logging: false, scale: 1 });
            ctx.drawImage(frameCanvas, 0, 0, canvas.width, canvas.height);
            
            const progress = ((frameIndex + 1) / framesToCapture * 100);
            pBar.style.width = progress + "%";
            statusText.innerText = `Capture : ${Math.round(progress)}%`;
        }
        setTimeout(() => recorder.stop(), 1000);
    }

    async function searchCity() {
        const q = document.getElementById('citySearch').value;
        if (!q.trim()) return;
        const r = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q)}&limit=1`);
        const d = await r.json();
        if(d.length>0) location.href=`?car_id=<?= $selected_car_id ?>&search=${encodeURIComponent(q)}&lat=${d[0].lat}&lng=${d[0].lon}`;
    }

    function clearSearch() { location.href=`?car_id=<?= $selected_car_id ?>&date=<?= $selected_date ?>`; }

    function toggleVision(mode) {
        let is3D = mode === '3D';
        document.getElementById('map').style.display = is3D ? 'none' : 'block';
        document.getElementById('plot3d').style.display = is3D ? 'block' : 'none';
        document.getElementById('btnShow3D').style.display = is3D ? 'none' : 'block';
        document.getElementById('btnShow2D').style.display = is3D ? 'block' : 'none';
        document.getElementById('speed-legend').style.display = is3D ? 'none' : 'block';
        if(is3D) render3D();
    }

    function render3D() {
        // Infobulles sur la trace : heure, altitude, température, batterie
        const hoverTexts = pos.map(p => {
            const d = new Date(p.date);
            const heure = d.toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'});
            let s = `🕐 ${heure}<br>⛰️ ${Math.round(p.elevation || 0)} m`;
            if (p.outside_temp !== null && p.outside_temp !== undefined) s += `<br>🌡️ ${p.outside_temp}°C`;
            s += `<br>⏲️ ${Math.round(p.speed || 0)} km/h`;
            if (p.battery_level !== null && p.battery_level !== undefined) s += `<br>🔋 ${p.battery_level}%`;
            return s;
        });

        const mainData = {
            type: 'scatter3d', mode: 'lines',
            x: pos.map(p => p.longitude), y: pos.map(p => p.latitude), z: pos.map(p => p.elevation || 0),
            line: { width: 6, color: pos.map(p => p.elevation || 0), colorscale: 'Viridis' },
            text: hoverTexts, hoverinfo: 'text'
        };
        const plotData = [mainData];

        // --- Triangles altitude max (rouge) et min (bleu) ---
        if (pos.length > 0) {
            let maxIdx = 0, minIdx = 0;
            pos.forEach((p, i) => {
                if ((p.elevation || 0) > (pos[maxIdx].elevation || 0)) maxIdx = i;
                if ((p.elevation || 0) < (pos[minIdx].elevation || 0)) minIdx = i;
            });
            const pMax = pos[maxIdx];
            const pMin = pos[minIdx];
            const maxTmp = (pMax.outside_temp != null) ? `<br>🌡️ ${pMax.outside_temp}°C` : '';
            const minTmp = (pMin.outside_temp != null) ? `<br>🌡️ ${pMin.outside_temp}°C` : '';
            plotData.push({
                type: 'scatter3d', mode: 'markers', showlegend: false,
                x: [pMax.longitude], y: [pMax.latitude], z: [pMax.elevation || 0],
                marker: { color: '#dc2626', size: 10, symbol: 'triangle-up', line: { color: '#fff', width: 1.5 } },
                hovertext: [`<b>🔴 ${i18n.alt_max}</b><br>⛰️ ${Math.round(pMax.elevation||0)} m<br>🕐 ${fmtHeure(pMax.date)}${maxTmp}`],
                hoverinfo: 'text'
            });
            plotData.push({
                type: 'scatter3d', mode: 'markers', showlegend: false,
                x: [pMin.longitude], y: [pMin.latitude], z: [pMin.elevation || 0],
                marker: { color: '#3b82f6', size: 10, symbol: 'triangle-down', line: { color: '#fff', width: 1.5 } },
                hovertext: [`<b>🔵 ${i18n.alt_min}</b><br>⛰️ ${Math.round(pMin.elevation||0)} m<br>🕐 ${fmtHeure(pMin.date)}${minTmp}`],
                hoverinfo: 'text'
            });
        }

        function fmtHeure(dateStr) {
            if (!dateStr) return '';
            const d = new Date(dateStr);
            return d.toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'});
        }

        // geocodeQueue : tous les points annotés à géocoder via Nominatim
        const geocodeQueue = [];

        // --- Départ et Arrivée ---
        if (pos.length > 0) {
            const startP = pos[0];
            const endP   = pos[pos.length - 1];
            const startAlt = Math.round(startP.elevation || 0);
            const endAlt   = Math.round(endP.elevation   || 0);
            const startTmp = (startP.outside_temp !== null && startP.outside_temp !== undefined) ? `<br>🌡️ ${startP.outside_temp}°C` : '';
            const endTmp   = (endP.outside_temp   !== null && endP.outside_temp   !== undefined) ? `<br>🌡️ ${endP.outside_temp}°C`   : '';

            plotData.push({
                type: 'scatter3d', mode: 'markers+text', showlegend: false,
                x: [startP.longitude], y: [startP.latitude], z: [startAlt],
                text: ['<?= $txt['start'] ?>'], textposition: 'top center',
                textfont: { color: '#22c55e', size: 13, family: 'Arial Black' },
                marker: { color: '#22c55e', size: 7, symbol: 'circle', line: { color: '#fff', width: 2 } },
                hovertext: [`<b>${i18n.depart}</b><br>📍 …<br>🕐 ${fmtHeure(startP.date)}<br>⛰️ ${startAlt} m${startTmp}`],
                hoverinfo: 'text'
            });
            geocodeQueue.push({ lat: startP.latitude, lng: startP.longitude,
                traceIdx: plotData.length - 1, pointIdx: 0,
                buildHover: v => `<b>${i18n.depart}</b><br>📍 ${v}<br>🕐 ${fmtHeure(startP.date)}<br>⛰️ ${startAlt} m${startTmp}` });

            plotData.push({
                type: 'scatter3d', mode: 'markers+text', showlegend: false,
                x: [endP.longitude], y: [endP.latitude], z: [endAlt],
                text: ['<?= $txt['end'] ?>'], textposition: 'top center',
                textfont: { color: '#dc2626', size: 13, family: 'Arial Black' },
                marker: { color: '#dc2626', size: 7, symbol: 'circle', line: { color: '#fff', width: 2 } },
                hovertext: [`<b>${i18n.arrivee}</b><br>📍 …<br>🕐 ${fmtHeure(endP.date)}<br>⛰️ ${endAlt} m${endTmp}`],
                hoverinfo: 'text'
            });
            geocodeQueue.push({ lat: endP.latitude, lng: endP.longitude,
                traceIdx: plotData.length - 1, pointIdx: 0,
                buildHover: v => `<b>${i18n.arrivee}</b><br>📍 ${v}<br>🕐 ${fmtHeure(endP.date)}<br>⛰️ ${endAlt} m${endTmp}` });
        }

        // --- Pauses P et Charges ⚡ (une trace par point) ---
        pauses.forEach(p => {
            const alt      = p.elevation !== null && p.elevation !== undefined ? p.elevation : 0;
            const tempTxt  = p.temp  !== null && p.temp  !== undefined ? `<br>🌡️ ${p.temp}°C`  : '';
            const heureTxt = p.heure ? `<br>🕐 ${p.heure}` : '';

            if (p.is_charge) {
                const h = Math.floor(p.duree_charge / 60);
                const m = p.duree_charge % 60;
                const dureeStr = h > 0 ? `${h}h${String(m).padStart(2,'0')}` : `${m} ${i18n.min}`;
                const batStr = (p.bat_start != null && p.bat_end != null) ? `<br>🔋 ${i18n.battery} : ${p.bat_start}% → ${p.bat_end}%` : '';
                const batTempStr = (p.bat_temp_start != null && p.bat_temp_end != null) ? `<br>🌡️ ${i18n.bat_temp} : ${p.bat_temp_start}°C → ${p.bat_temp_end}°C` : '';
                const heaterStr3d = p.bat_heater != null ? `<br>🔥 ${i18n.bat_heater} : ${p.bat_heater ? i18n.on : i18n.off}` : '';
                plotData.push({
                    type: 'scatter3d', mode: 'markers+text', showlegend: false,
                    x: [p.lng], y: [p.lat], z: [alt],
                    text: ['⚡'], textposition: 'top center',
                    textfont: { color: '#fbbf24', size: 13, family: 'Arial Black' },
                    marker: { color: '#f59e0b', size: 10, symbol: 'diamond', line: { color: '#fff', width: 2 } },
                    hovertext: [`<b>⚡ ${i18n.charge}</b><br>📍 …${heureTxt}<br>⛰️ ${alt} m${tempTxt}<br>⚡ ${p.kwh_added} kWh<br>⏱️ ${dureeStr}${batStr}${batTempStr}${heaterStr3d}`],
                    hoverinfo: 'text'
                });
                geocodeQueue.push({ lat: p.lat, lng: p.lng,
                    traceIdx: plotData.length - 1, pointIdx: 0,
                    buildHover: v => `<b>⚡ ${i18n.charge}</b><br>📍 ${v}${heureTxt}<br>⛰️ ${alt} m${tempTxt}<br>⚡ ${p.kwh_added} kWh<br>⏱️ ${dureeStr}${batStr}${batTempStr}${heaterStr3d}` });
            } else {
                plotData.push({
                    type: 'scatter3d', mode: 'markers+text', showlegend: false,
                    x: [p.lng], y: [p.lat], z: [alt],
                    text: ['P'], textposition: 'top center',
                    textfont: { color: '#60a5fa', size: 12, family: 'Arial Black' },
                    marker: { color: '#3b82f6', size: 9, symbol: 'circle', line: { color: '#fff', width: 2 } },
                    hovertext: [`<b>P ${i18n.pause} ${p.dur} ${i18n.min}</b><br>📍 …${heureTxt}<br>⛰️ ${alt} m${tempTxt}`],
                    hoverinfo: 'text'
                });
                geocodeQueue.push({ lat: p.lat, lng: p.lng,
                    traceIdx: plotData.length - 1, pointIdx: 0,
                    buildHover: v => `<b>P ${i18n.pause} ${p.dur} ${i18n.min}</b><br>📍 ${v}${heureTxt}<br>⛰️ ${alt} m${tempTxt}` });
            }
        });

        Plotly.newPlot('plot3d', plotData, {
            paper_bgcolor: '#000', plot_bgcolor: '#000', margin: {l:0, r:0, b:0, t:0},
            scene: {
                aspectratio: {x:1, y:1, z:0.3},
                xaxis: {backgroundcolor: '#000', gridcolor: '#333', showbackground: true, title: ''},
                yaxis: {backgroundcolor: '#000', gridcolor: '#333', showbackground: true, title: ''},
                zaxis: {backgroundcolor: '#000', gridcolor: '#333', showbackground: true, title: 'Altitude (m)'}
            }
        });
        document.getElementById('info-box').style.display = 'flex';

        // --- Nominatim asynchrone pour tous les points annotés ---
        const delay = ms => new Promise(r => setTimeout(r, ms));
        (async () => {
            for (let i = 0; i < geocodeQueue.length; i++) {
                if (i > 0) await delay(1200);
                const item = geocodeQueue[i];
                try {
                    const r = await fetch(
                        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${item.lat}&lon=${item.lng}&zoom=10`,
                        { headers: { 'Accept-Language': 'fr' } }
                    );
                    const d = await r.json();
                    const ville = d.address?.city || d.address?.town || d.address?.village || d.address?.municipality || d.address?.county || '?';
                    Plotly.restyle('plot3d', { hovertext: [[item.buildHover(ville)]] }, [item.traceIdx]);
                } catch(e) { /* silencieux */ }
            }
        })();
    }

    async function takeSnapshot() {
        const canvas = await html2canvas(document.getElementById('map'), { useCORS: true });
        const link = document.createElement('a');
        link.download = 'tesla_snap.png'; link.href = canvas.toDataURL(); link.click();
    }

    // --- Toggle contrôles sidebar ---
    function toggleHeaderControls() {
        const ctrl = document.getElementById('header-controls');
        const icon = document.getElementById('header-toggle-icon');
        const collapsed = ctrl.classList.toggle('collapsed');
        icon.style.transform = collapsed ? 'rotate(180deg)' : 'rotate(0deg)';
    }

    // --- Toggle sidebar mobile ---
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const btn     = document.getElementById('sidebar-toggle');
        sidebar.classList.toggle('collapsed');
        btn.classList.toggle('collapsed');
        // Forcer Leaflet à recalculer la taille de la carte après l'animation
        setTimeout(() => { if(typeof map !== 'undefined') map.invalidateSize(); }, 370);
    }

    // --- Analyse conduite ---
    function showAnalyse() {
        const panel   = document.getElementById('analyse-panel');
        const content = document.getElementById('analyse-content');
        panel.classList.add('visible');

        if (!pos || pos.length < 2) {
            content.innerHTML = '<p style="color:#666;font-size:12px;text-align:center">Pas de données.</p>';
            return;
        }

        // Calculs
        const vmax    = Math.round(Math.max(...pos.map(p => parseFloat(p.speed) || 0)));
        const hiCount = pos.filter(p => parseFloat(p.speed) > 110).length;
        const hiPct   = Math.round(hiCount / pos.length * 100);

        let hardAcc = 0, hardBrk = 0;
        for (let i = 1; i < pos.length; i++) {
            const dt = (new Date(pos[i].date) - new Date(pos[i-1].date)) / 1000;
            if (dt <= 0 || dt > 15) continue;
            const dv = (parseFloat(pos[i].speed) || 0) - (parseFloat(pos[i-1].speed) || 0);
            if (dv > 20)  hardAcc++;
            if (dv < -25) hardBrk++;
        }

        // Scores partiels /100
        const s_vmax = Math.max(0, Math.min(100, Math.round(100 - Math.max(0, vmax - 90) * 1.1)));
        const s_hi   = Math.max(0, Math.min(100, Math.round(100 - hiPct * 1.5)));
        const s_acc  = Math.max(0, Math.min(100, Math.round(100 - hardAcc * 3)));
        const s_brk  = Math.max(0, Math.min(100, Math.round(100 - hardBrk * 4)));
        const score  = Math.round(s_vmax * 0.3 + s_hi * 0.3 + s_acc * 0.25 + s_brk * 0.15);
        const conso  = (15 + (100 - score) * 0.12).toFixed(1);

        const bColor = v => v >= 70 ? '#22c55e' : v >= 40 ? '#f59e0b' : '#ef4444';

        // Verdict
        const T = {
            eco: '<?= addslashes($txt['an_eco']) ?>', eco_s: '<?= addslashes($txt['an_eco_s']) ?>',
            bal: '<?= addslashes($txt['an_bal']) ?>', bal_s: '<?= addslashes($txt['an_bal_s']) ?>',
            spo: '<?= addslashes($txt['an_spo']) ?>', spo_s: '<?= addslashes($txt['an_spo_s']) ?>',
            vsp: '<?= addslashes($txt['an_vsp']) ?>', vsp_s: '<?= addslashes($txt['an_vsp_s']) ?>',
        };
        let icon, title, sub, bg, border;
        if      (score >= 75) { icon='🌿'; title=T.eco; sub=T.eco_s; bg='rgba(34,197,94,0.1)';   border='rgba(34,197,94,0.3)'; }
        else if (score >= 50) { icon='⚖️';  title=T.bal; sub=T.bal_s; bg='rgba(245,158,11,0.1)'; border='rgba(245,158,11,0.3)'; }
        else if (score >= 30) { icon='🏎️';  title=T.spo; sub=T.spo_s; bg='rgba(239,68,68,0.1)';  border='rgba(239,68,68,0.3)'; }
        else                  { icon='🔥';  title=T.vsp; sub=T.vsp_s; bg='rgba(239,68,68,0.18)'; border='rgba(239,68,68,0.5)'; }

        // Anneau SVG
        const circ   = (2 * Math.PI * 50).toFixed(2);
        const offset = (circ * (1 - score / 100)).toFixed(2);

        content.innerHTML = `
            <div class="an-kpis">
                <div class="an-kpi"><div class="an-kpi-lbl"><?= $txt['an_vmax'] ?></div><div class="an-kpi-val">${vmax}<span class="an-kpi-unit"> km/h</span></div></div>
                <div class="an-kpi"><div class="an-kpi-lbl"><?= $txt['an_conso'] ?></div><div class="an-kpi-val">${conso}<span class="an-kpi-unit"> kWh/100</span></div></div>
                <div class="an-kpi"><div class="an-kpi-lbl"><?= $txt['an_acc'] ?></div><div class="an-kpi-val">${hardAcc}<span class="an-kpi-unit"> ×</span></div></div>
                <div class="an-kpi"><div class="an-kpi-lbl"><?= $txt['an_brk'] ?></div><div class="an-kpi-val">${hardBrk}<span class="an-kpi-unit"> ×</span></div></div>
            </div>
            <div class="an-ring">
                <svg width="120" height="120" viewBox="0 0 120 120">
                    <circle cx="60" cy="60" r="50" fill="none" stroke="#2a2a2a" stroke-width="9"/>
                    <circle cx="60" cy="60" r="50" fill="none" stroke="${bColor(score)}" stroke-width="9"
                            stroke-linecap="round" stroke-dasharray="${circ}" stroke-dashoffset="${offset}"
                            transform="rotate(-90 60 60)"/>
                    <text x="60" y="55" text-anchor="middle" font-size="28" font-weight="700" fill="#ffffff">${score}</text>
                    <text x="60" y="72" text-anchor="middle" font-size="11" fill="#888">/ 100</text>
                </svg>
                <div class="an-ring-lbl">${title}</div>
            </div>
            <div class="an-bars">
                <div class="an-bar-row"><div class="an-bar-lbl"><?= $txt['an_vmax'] ?></div><div class="an-bar-track"><div class="an-bar-fill" style="width:${s_vmax}%;background:${bColor(s_vmax)}"></div></div><div class="an-bar-val" style="color:${bColor(s_vmax)}">${s_vmax}</div></div>
                <div class="an-bar-row"><div class="an-bar-lbl"><?= $txt['an_hi'] ?></div><div class="an-bar-track"><div class="an-bar-fill" style="width:${s_hi}%;background:${bColor(s_hi)}"></div></div><div class="an-bar-val" style="color:${bColor(s_hi)}">${s_hi}</div></div>
                <div class="an-bar-row"><div class="an-bar-lbl"><?= $txt['an_acc'] ?></div><div class="an-bar-track"><div class="an-bar-fill" style="width:${s_acc}%;background:${bColor(s_acc)}"></div></div><div class="an-bar-val" style="color:${bColor(s_acc)}">${s_acc}</div></div>
                <div class="an-bar-row"><div class="an-bar-lbl"><?= $txt['an_brk'] ?></div><div class="an-bar-track"><div class="an-bar-fill" style="width:${s_brk}%;background:${bColor(s_brk)}"></div></div><div class="an-bar-val" style="color:${bColor(s_brk)}">${s_brk}</div></div>
            </div>
            <div class="an-verdict" style="background:${bg};border:1px solid ${border}">
                <div class="an-verdict-icon">${icon}</div>
                <div><div class="an-verdict-title">${title}</div><div class="an-verdict-sub">${sub}</div></div>
            </div>
        `;
    }

    // --- Resize panneau analyse ---
    let anScale = 1.0;
    function resizeAnalyse(dir) {
        anScale = Math.min(2.0, Math.max(0.6, anScale + dir * 0.1));
        document.getElementById('analyse-panel').style.setProperty('--an-scale', anScale.toFixed(1));
        // Ajuster aussi la largeur du panneau proportionnellement
        const baseW = 290;
        document.getElementById('analyse-panel').style.width = Math.round(baseW * anScale) + 'px';
    }

    // --- Drag & drop panneau analyse ---
    (function() {
        const panel  = document.getElementById('analyse-panel');
        const header = panel.querySelector('.an-header');
        const parent = panel.parentElement;
        let dragging = false, ox = 0, oy = 0;

        function getParentOffset() {
            const r = parent.getBoundingClientRect();
            return { x: r.left, y: r.top };
        }

        header.addEventListener('mousedown', function(e) {
            if (e.target.classList.contains('an-close')) return;
            dragging = true;
            const rect = panel.getBoundingClientRect();
            panel.style.right = 'auto';
            panel.style.left  = rect.left - getParentOffset().x + 'px';
            panel.style.top   = rect.top  - getParentOffset().y + 'px';
            ox = e.clientX - rect.left;
            oy = e.clientY - rect.top;
            e.preventDefault();
        });

        header.addEventListener('touchstart', function(e) {
            if (e.target.classList.contains('an-close')) return;
            dragging = true;
            const rect = panel.getBoundingClientRect();
            panel.style.right = 'auto';
            panel.style.left  = rect.left - getParentOffset().x + 'px';
            panel.style.top   = rect.top  - getParentOffset().y + 'px';
            ox = e.touches[0].clientX - rect.left;
            oy = e.touches[0].clientY - rect.top;
        }, { passive: true });

        document.addEventListener('mousemove', function(e) {
            if (!dragging) return;
            const po = getParentOffset();
            panel.style.left = (e.clientX - ox - po.x) + 'px';
            panel.style.top  = (e.clientY - oy - po.y) + 'px';
        });

        document.addEventListener('touchmove', function(e) {
            if (!dragging) return;
            const po = getParentOffset();
            panel.style.left = (e.touches[0].clientX - ox - po.x) + 'px';
            panel.style.top  = (e.touches[0].clientY - oy - po.y) + 'px';
        }, { passive: true });

        document.addEventListener('mouseup',  () => dragging = false);
        document.addEventListener('touchend', () => dragging = false);
    })();

    // --- Plage de dates ---
    function toggleRangePanel() {
        const panel = document.getElementById('range-panel');
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }

    function applyRange() {
        const from = document.getElementById('inputDateFrom').value;
        const to   = document.getElementById('inputDateTo').value;
        if (!from || !to) return;
        if (from > to) { alert('La date de début doit être avant la date de fin.'); return; }
        location.href = '?car_id=<?= $selected_car_id ?>&date_from=' + from + '&date_to=' + to;
    }

    // --- Listeners select/date : robustes pour touch Tesla ---
    (function() {
        const isTesla = (
            /Linux x86_64/.test(navigator.userAgent) &&
            /Chrome/.test(navigator.userAgent) &&
            !/Android|Mobile/.test(navigator.userAgent) &&
            navigator.maxTouchPoints >= 1
        );

        // Select véhicule
        const selVehicle = document.getElementById('selectVehicle');
        if (selVehicle) {
            const goVehicle = function() {
                location.href = '?date=<?= $selected_date ?>&car_id=' + selVehicle.value;
            };
            selVehicle.addEventListener('change', goVehicle);
            if (isTesla) {
                selVehicle.addEventListener('touchend', function(e) {
                    setTimeout(goVehicle, 300);
                });
            }
        }

        // Input date principal (jour unique) — préserve date_from/date_to si en mode plage
        const inputDate = document.getElementById('inputDate');
        if (inputDate) {
            const goDate = function() {
                if (!inputDate.value) return;
                <?php if ($is_range_mode): ?>
                location.href = '?car_id=<?= $selected_car_id ?>&date=' + inputDate.value + '&date_from=<?= $date_from ?>&date_to=<?= $date_to ?>';
                <?php else: ?>
                location.href = '?car_id=<?= $selected_car_id ?>&date=' + inputDate.value;
                <?php endif; ?>
            };
            inputDate.addEventListener('change', goDate);
        }

        // Inputs date_from / date_to dans le panneau plage
        ['inputDateFrom', 'inputDateTo'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('change', function() {
                // auto-appliquer si les deux sont remplis
                const from = document.getElementById('inputDateFrom').value;
                const to   = document.getElementById('inputDateTo').value;
                if (from && to && from <= to) applyRange();
            });
        });
    })();

    // --- Polyfill vieux navigateur (Tesla browser) : numpad date ---
    (function() {
        const isTesla = (
            /Linux x86_64/.test(navigator.userAgent) &&
            /Chrome/.test(navigator.userAgent) &&
            !/Android|Mobile/.test(navigator.userAgent) &&
            navigator.maxTouchPoints >= 1
        );

        const testInput = document.createElement('input');
        testInput.setAttribute('type', 'date');
        testInput.setAttribute('value', 'not-a-date');
        const supportsDate = (testInput.value !== 'not-a-date');

        // Sur Tesla : forcer le numpad même si Chrome supporte type=date
        // car le date picker natif touch est inutilisable
        if (supportsDate && !isTesla) return;

        // Styles du numpad
        const style = document.createElement('style');
        style.textContent = `
            .date-numpad-wrap { display:inline-block; }
            .date-numpad-display { font-size:20px; letter-spacing:4px; color:#f59e0b; text-align:center; padding:6px 0 10px 0; }
            .date-numpad-grid { display:grid; grid-template-columns:repeat(3,44px); gap:5px; }
            .date-numpad-grid button { width:44px; height:44px; background:#222; border:1px solid #555; border-radius:6px; color:#fff; font-size:15px; cursor:pointer; }
            .date-numpad-grid button.ok { background:#dc2626; border:none; font-size:12px; font-weight:bold; }
            .date-numpad-grid button.cl { background:#444; }
            .date-numpad-hint { font-size:10px; color:#666; text-align:center; margin-top:4px; }
        `;
        document.head.appendChild(style);

        function makeNumpad(input) {
            const inputId = input.id || '';
            const initVal = input.value || '';
            const parts  = initVal.split('-');
            let digits = parts.length === 3
                ? parts[2] + parts[1] + parts[0]  // JJMMAAAA depuis AAAA-MM-JJ
                : '';

            const hidden = document.createElement('input');
            hidden.type  = 'hidden';
            hidden.name  = input.getAttribute('name') || '';
            hidden.value = initVal;

            const display = document.createElement('div');
            display.className = 'date-numpad-display';

            function updateDisplay() {
                const s = digits.padEnd(8, '_');
                display.textContent = s.slice(0,2) + '/' + s.slice(2,4) + '/' + s.slice(4,8);
            }
            updateDisplay();

            function pressDigit(n) {
                if (digits.length < 8) {
                    digits += n;
                    updateDisplay();
                    if (digits.length === 8) confirmDate();
                }
            }

            function clearDigit() {
                digits = digits.slice(0, -1);
                updateDisplay();
            }

            function confirmDate() {
                if (digits.length !== 8) return;
                const dd = digits.slice(0,2), mm = digits.slice(2,4), yyyy = digits.slice(4,8);
                const iso = `${yyyy}-${mm}-${dd}`;
                hidden.value = iso;
                // Navigation selon le champ
                if (inputId === 'inputDateFrom') {
                    const to = document.querySelector('input[name="inputDateTo_h"]');
                    const toVal = to ? to.value : iso;
                    location.href = '?car_id=<?= $selected_car_id ?>&date_from=' + iso + '&date_to=' + (toVal || iso);
                } else if (inputId === 'inputDateTo') {
                    const from = document.querySelector('input[name="inputDateFrom_h"]');
                    const fromVal = from ? from.value : iso;
                    location.href = '?car_id=<?= $selected_car_id ?>&date_from=' + (fromVal || iso) + '&date_to=' + iso;
                } else {
                    <?php if ($is_range_mode): ?>
                    location.href = '?car_id=<?= $selected_car_id ?>&date=' + iso + '&date_from=<?= $date_from ?>&date_to=<?= $date_to ?>';
                    <?php else: ?>
                    location.href = '?car_id=<?= $selected_car_id ?>&date=' + iso;
                    <?php endif; ?>
                }
            }

            // Grille de boutons
            const grid = document.createElement('div');
            grid.className = 'date-numpad-grid';
            [1,2,3,4,5,6,7,8,9,'C',0,'OK'].forEach(v => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.textContent = v;
                let handler;
                if (v === 'OK')     { btn.className = 'ok'; handler = confirmDate; }
                else if (v === 'C') { btn.className = 'cl'; handler = clearDigit; }
                else                { handler = () => pressDigit(String(v)); }
                btn.addEventListener('click', handler);
                btn.addEventListener('touchend', function(e) { e.preventDefault(); handler(); });
                grid.appendChild(btn);
            });

            // Label du champ
            const label = inputId === 'inputDateFrom' ? '<?= $txt['date_from'] ?>' :
                          inputId === 'inputDateTo'   ? '<?= $txt['date_to'] ?>'   : '';
            const hint = document.createElement('div');
            hint.className = 'date-numpad-hint';
            hint.textContent = (label ? label + ' : ' : '') + 'JJ MM AAAA';

            const wrap = document.createElement('div');
            wrap.className = 'date-numpad-wrap';
            // Stocker la valeur cachée avec un nom unique pour récupérer entre les deux numpads
            hidden.name = inputId + '_h';
            wrap.appendChild(display);
            wrap.appendChild(grid);
            wrap.appendChild(hint);
            wrap.appendChild(hidden);

            input.parentNode.insertBefore(wrap, input);
            input.parentNode.removeChild(input);
        }

        document.querySelectorAll('input[type=date]').forEach(makeNumpad);
    })();

    // --- Drag speed-legend ---
    (function() {
        const leg = document.getElementById('speed-legend');
        if (!leg) return;
        const parent = leg.parentElement;
        let dragging = false, ox = 0, oy = 0;

        window.addEventListener('load', function() {
            const rect = leg.getBoundingClientRect();
            const pr   = parent.getBoundingClientRect();
            leg.style.bottom = 'auto';
            leg.style.right  = 'auto';
            leg.style.left   = (rect.left - pr.left) + 'px';
            leg.style.top    = (rect.top  - pr.top)  + 'px';
        });

        function startDrag(cx, cy) {
            const rect = leg.getBoundingClientRect();
            dragging = true;
            ox = cx - rect.left;
            oy = cy - rect.top;
        }
        function moveDrag(cx, cy) {
            if (!dragging) return;
            const pr = parent.getBoundingClientRect();
            let nx = cx - pr.left - ox;
            let ny = cy - pr.top  - oy;
            nx = Math.max(0, Math.min(nx, pr.width  - leg.offsetWidth));
            ny = Math.max(0, Math.min(ny, pr.height - leg.offsetHeight));
            leg.style.left = nx + 'px';
            leg.style.top  = ny + 'px';
        }

        leg.addEventListener('mousedown', function(e) { startDrag(e.clientX, e.clientY); e.preventDefault(); });
        leg.addEventListener('touchstart', function(e) { startDrag(e.touches[0].clientX, e.touches[0].clientY); }, { passive: true });
        document.addEventListener('mousemove',  function(e) { moveDrag(e.clientX, e.clientY); });
        document.addEventListener('touchmove',  function(e) { if (dragging) moveDrag(e.touches[0].clientX, e.touches[0].clientY); }, { passive: true });
        document.addEventListener('mouseup',    function() { dragging = false; });
        document.addEventListener('touchend',   function() { dragging = false; });
    })();

    // --- Drag replay-bar ---
    (function() {
        const bar = document.getElementById('replay-bar');
        if (!bar) return;
        const parent = bar.parentElement;
        let dragging = false, ox = 0, oy = 0;

        // Convertir position initiale (transform+bottom) en left+top au chargement
        window.addEventListener('load', function() {
            const rect = bar.getBoundingClientRect();
            const pr   = parent.getBoundingClientRect();
            bar.style.transform = 'none';
            bar.style.bottom    = 'auto';
            bar.style.left      = (rect.left - pr.left) + 'px';
            bar.style.top       = (rect.top  - pr.top)  + 'px';
        });

        function startDrag(cx, cy) {
            // Lire la position réelle au moment du touch/click
            const rect = bar.getBoundingClientRect();
            dragging = true;
            ox = cx - rect.left;
            oy = cy - rect.top;
        }
        function moveDrag(cx, cy) {
            if (!dragging) return;
            const pr = parent.getBoundingClientRect();
            let nx = cx - pr.left - ox;
            let ny = cy - pr.top  - oy;
            nx = Math.max(0, Math.min(nx, pr.width  - bar.offsetWidth));
            ny = Math.max(0, Math.min(ny, pr.height - bar.offsetHeight));
            bar.style.left = nx + 'px';
            bar.style.top  = ny + 'px';
        }

        bar.addEventListener('mousedown', function(e) {
            if (['BUTTON','INPUT','SELECT'].includes(e.target.tagName)) return;
            startDrag(e.clientX, e.clientY);
            e.preventDefault();
        });
        bar.addEventListener('touchstart', function(e) {
            if (['BUTTON','INPUT','SELECT'].includes(e.target.tagName)) return;
            startDrag(e.touches[0].clientX, e.touches[0].clientY);
        }, { passive: true });
        document.addEventListener('mousemove',  function(e) { moveDrag(e.clientX, e.clientY); });
        document.addEventListener('touchmove',  function(e) { if (dragging) moveDrag(e.touches[0].clientX, e.touches[0].clientY); }, { passive: true });
        document.addEventListener('mouseup',    function() { dragging = false; });
        document.addEventListener('touchend',   function() { dragging = false; });
    })();
</script>
</body>
</html>	
