<?php
require_once __DIR__ . '/auth_check.php';
// --- 1. CONFIGURATION ---
$file = "/var/www/html/cgi-bin/setup";

function read_setup($file) {
    $cfg = [];
    if (file_exists($file)) {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos($line, '=') !== false) {
                list($key, $value) = explode('=', $line, 2);
                $cfg[strtoupper(trim($key))] = trim($value);
            }
        }
    }
    return $cfg;
}

function save_setup_key($file, $keyToSave, $valueToSave) {
    $lines = file_exists($file) ? file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
    $found = false;
    $keyToSave = strtolower($keyToSave); 
    foreach ($lines as $idx => $line) {
        if (preg_match("/^" . preg_quote($keyToSave) . "\s*=/i", trim($line))) {
            $lines[$idx] = "$keyToSave=$valueToSave";
            $found = true;
            break;
        }
    }
    if (!$found) $lines[] = "$keyToSave=$valueToSave";
    if (!is_dir(dirname($file))) mkdir(dirname($file), 0755, true);
    file_put_contents($file, implode("\n", $lines) . "\n", LOCK_EX);
}

$config = read_setup($file);

if (isset($_GET['save_lang'])) {
    $lang = strtoupper(trim($_GET['save_lang']));
    if ($lang === 'FR' || $lang === 'EN') {
        save_setup_key($file, 'language', $lang);
        header('Content-Type: application/json');
        echo json_encode(['status' => 'ok', 'saved' => $lang]);
        exit;
    }
}

if (isset($_GET['check_update'])) {
    $gh_url = 'https://api.github.com/repos/infrarik/teslamatemail/contents/files.zip';
    $ch = curl_init($gh_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_RANGE, '0-500');
    curl_setopt($ch, CURLOPT_USERAGENT, 'TeslaMateMailUpdater/1.0');
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $raw = curl_exec($ch);
    curl_close($ch);
    $gh_sha = null; $gh_size = null;
    if ($raw) {
        if (preg_match('/"sha"\s*:\s*"([^"]+)"/', $raw, $m)) $gh_sha = $m[1];
        if (preg_match('/"size"\s*:\s*(\d+)/', $raw, $m)) $gh_size = (int)$m[1];
    }
    $local_sha  = $config['GITHUB_SHA']  ?? null;
    $local_size = $config['GITHUB_SIZE'] ?? null;
    $update_available = ($gh_sha && ($gh_sha !== $local_sha || (string)$gh_size !== (string)$local_size));
    header('Content-Type: application/json');
    echo json_encode(['update' => $update_available, 'gh_sha' => $gh_sha, 'gh_size' => $gh_size, 'local_sha' => $local_sha]);
    exit;
}

if (isset($_GET['do_update'])) {
    $gh_sha  = $_GET['sha']  ?? '';
    $gh_size = $_GET['size'] ?? '';
    $result  = ['status' => 'error', 'msg' => ''];
    
    // dans tous les cas, on télécharge les fichiers en premier
    $zip_url  = 'https://raw.githubusercontent.com/infrarik/teslamatemail/main/files.zip';
    $zip_dest = '/tmp/files.zip';
    $ch = curl_init($zip_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'TeslaMateMailUpdater/1.0');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    $zip_data = curl_exec($ch);
    curl_close($ch);
    
    if ($zip_data && strlen($zip_data) > 1000) {
        file_put_contents($zip_dest, $zip_data);
        
        $sh_url  = 'https://raw.githubusercontent.com/infrarik/teslamatemail/main/installweb.sh';
        $sh_dest = '/tmp/installweb.sh';
        $ch2 = curl_init($sh_url);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch2, CURLOPT_USERAGENT, 'TeslaMateMailUpdater/1.0');
        curl_setopt($ch2, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch2, CURLOPT_TIMEOUT, 15);
        $sh_data = curl_exec($ch2);
        curl_close($ch2);
        
        if ($sh_data) { 
            file_put_contents($sh_dest, $sh_data); 
            chmod($sh_dest, 0755); 
        }
        
        // après le téléchargement systématique, on regarde si on a l'ordre d'exécuter
        if (isset($_GET['confirm']) && $_GET['confirm'] === '1') {
            exec($sh_dest . " > /dev/null 2>&1");
            save_setup_key($file, 'github_sha',  $gh_sha);
            save_setup_key($file, 'github_size', $gh_size);
            $result['status'] = 'installed';
            $result['msg'] = 'Mise à jour installée avec succès.';
        } else {
            // si pas encore de confirmation, on indique au js qu'il doit afficher le choix oui/non
            $result['status'] = 'requires_confirmation';
            $result['msg'] = 'Téléchargement ok, en attente de confirmation.';
        }
    } else {
        $result['msg'] = 'Échec du téléchargement de files.zip';
    }
    header('Content-Type: application/json');
    echo json_encode($result);
    exit;
}

if (!isset($config['LANGUAGE'])) {
    save_setup_key($file, 'language', 'FR');
    $config['LANGUAGE'] = 'FR';
}

$default_lang = strtolower($config['LANGUAGE']);
$app_version = trim(@file_get_contents('/var/www/html/cgi-bin/version')) ?: '—';
$server_ip = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';

if (!empty($config['DOCKER_PATH']) && file_exists($config['DOCKER_PATH'])) {
    $docker_content = file_get_contents($config['DOCKER_PATH']);
    if (preg_match('/POSTGRES_USER[:=]\s*(\S+)/', $docker_content, $m)) $db_user = str_replace(['"', "'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_PASSWORD[:=]\s*(\S+)/', $docker_content, $m)) $db_pass = str_replace(['"', "'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_DB[:=]\s*(\S+)/', $docker_content, $m)) $db_name = str_replace(['"', "'"], '', trim($m[1]));
}

$last_charge_added = 0;
$last_charge_used = 0;
$address_road = '';
$address_city = '';
try {
    $pdo = new PDO("pgsql:host=$server_ip;port=5432;dbname=$db_name", $db_user, $db_pass);
    $sql = "SELECT charge_energy_added, charge_energy_used FROM charging_processes WHERE end_date IS NOT NULL ORDER BY end_date DESC LIMIT 1";
    $stmt = $pdo->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        $last_charge_added = round((float)$row['charge_energy_added'], 2);
        $last_charge_used = round((float)$row['charge_energy_used'], 2);
    }
    $stmt2 = $pdo->query("SELECT a.road, a.city, p2.latitude, p2.longitude FROM drives d JOIN addresses a ON a.id = d.end_address_id JOIN positions p2 ON p2.id = d.end_position_id WHERE d.end_date IS NOT NULL ORDER BY d.end_date DESC LIMIT 1");
    $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
    if ($row2) {
        $address_road = $row2['road'] ?? '';
        $address_city = $row2['city'] ?? '';
        $address_lat  = $row2['latitude'] ?? '';
        $address_lng  = $row2['longitude'] ?? '';
    }
} catch (Exception $e) { 
    $last_charge_added = 0; 
    $last_charge_used = 0; 
}
?>
<!DOCTYPE html>
<html lang="<?= $default_lang ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>TeslaMate Mail</title>
  <link rel="manifest" href="manifest.json">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root {
      --red:   #e5232a;
      --blue:  #1a8cff;
      --glass: rgba(255,255,255,0.05);
      --glass-border: rgba(255,255,255,0.10);
      --glass-hover:  rgba(255,255,255,0.09);
    }

    * { box-sizing: border-box; }

    body {
      font-family: 'Inter', sans-serif;
      background: #080c14;
      background-image:
        radial-gradient(ellipse 80% 60% at 20% -10%, rgba(229,35,42,0.18) 0%, transparent 60%),
        radial-gradient(ellipse 60% 50% at 80% 110%, rgba(26,140,255,0.15) 0%, transparent 60%);
      background-attachment: fixed;
      min-height: 100vh;
      color: #e8eaf0;
      overflow-x: hidden;
    }

    h1, h2, .label-font { font-family: 'Rajdhani', sans-serif; }

    .glass {
      background: var(--glass);
      backdrop-filter: blur(16px) saturate(180%);
      -webkit-backdrop-filter: blur(16px) saturate(180%);
      border: 1px solid var(--glass-border);
    }
    .glass-hover:hover {
      background: var(--glass-hover);
      border-color: rgba(255,255,255,0.18);
    }

    .glow-red  { box-shadow: 0 0 24px rgba(229,35,42,0.35), 0 0 60px rgba(229,35,42,0.10); }
    .glow-blue { box-shadow: 0 0 24px rgba(26,140,255,0.35), 0 0 60px rgba(26,140,255,0.10); }
    .glow-green{ box-shadow: 0 0 20px rgba(74,222,128,0.30); }

    .battery-track {
      background: rgba(255,255,255,0.07);
      border-radius: 99px;
      height: 10px;
      overflow: hidden;
      position: relative;
    }
    .battery-fill {
      height: 100%;
      border-radius: 99px;
      transition: width 1.2s cubic-bezier(.4,0,.2,1);
      position: relative;
    }
    .battery-fill::after {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.25) 50%, transparent 100%);
      animation: shimmer 2.5s infinite;
    }
    @keyframes shimmer { 0%{transform:translateX(-100%)} 100%{transform:translateX(100%)} }

    .tire-val { font-family: 'Rajdhani', sans-serif; font-size: 1.8rem; font-weight: 700; line-height: 1; }

    .nav-btn {
      display: flex; flex-direction: column; align-items: center; gap: 4px;
      padding: 10px 14px; border-radius: 14px;
      background: var(--glass);
      border: 1px solid var(--glass-border);
      transition: all 0.2s;
      text-decoration: none;
    }
    .nav-btn:hover { background: var(--glass-hover); border-color: rgba(255,255,255,0.2); transform: translateY(-2px); }
    .nav-btn svg { width: 22px; height: 22px; stroke: #9ca3af; }
    .nav-btn:hover svg { stroke: #fff; }
    .nav-btn span { font-size: 9px; font-weight: 600; letter-spacing: 0.06em; color: #6b7280; text-transform: uppercase; }

    .kpi-card {
      padding: 14px 12px; border-radius: 16px;
      display: flex; flex-direction: column; gap: 4px;
    }
    .kpi-label {
      font-size: 9px; font-weight: 600; letter-spacing: 0.1em;
      text-transform: uppercase; color: #6b7280;
    }
    .kpi-val {
      font-family: 'Rajdhani', sans-serif;
      font-size: 1.55rem; font-weight: 700; line-height: 1; color: #fff;
    }
    .kpi-unit { font-size: 0.7rem; font-weight: 500; color: #6b7280; }

    .h-divider { height: 1px; background: var(--glass-border); margin: 0; }

    .lang-btn { cursor: pointer; transition: all 0.2s; border: 2px solid transparent; border-radius: 4px; opacity: 0.45; }
    .lang-btn:hover { opacity: 0.8; transform: scale(1.08); }
    .lang-active { border-color: rgba(255,255,255,0.6); opacity: 1; }

    @keyframes pulse-charge { 0%,100%{opacity:1} 50%{opacity:0.55} }
    .pulse-charge { animation: pulse-charge 1.8s ease-in-out infinite; }

    @keyframes spin-slow { to { transform: rotate(360deg); } }
    .spin-slow { animation: spin-slow 1.2s linear infinite; }

    .footer-link {
      text-decoration: none; padding: 16px;
      border-radius: 16px; text-align: center;
      transition: all 0.2s;
    }
    .footer-link:hover { background: var(--glass-hover); }

    ::-webkit-scrollbar { width: 4px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
  </style>
</head>
<body>
  <div id="app"></div>

  <script>
    const API_URL = 'teslamate_api.php';
    const REFRESH_INTERVAL = 30;
    const PHP_ADDRESS = '<?= htmlspecialchars(implode(', ', array_filter([$address_road, $address_city])), ENT_QUOTES) ?>';
    const PHP_ADDRESS_LAT = '<?= $address_lat ?? '' ?>';
    const PHP_ADDRESS_LNG = '<?= $address_lng ?? '' ?>';
    const PHP_LAST_CHARGE_ADDED = <?= $last_charge_added ?>;
    const PHP_LAST_CHARGE_USED = <?= $last_charge_used ?>;
    const SERVER_IP = '<?= $server_ip ?>';
    const APP_VERSION = '<?= $app_version ?>';

    const i18n = {
      fr: {
        loading: "Chargement...", refresh: "Rafraîchir",
        tooltip_trips: "Trajets", tooltip_notif: "Notifications",
        tooltip_export: "Export / Calcul", tooltip_conf: "Configuration",
        tooltip_dashcam: "Dashcam", state: "État", odometer: "Kilométrage",
        battery: "Batterie", est_range: "Autonomie estimée",
        interior: "Intérieur", exterior: "Extérieur",
        tires: "Pneus", fl: "AVG", fr: "AVD", rl: "ARG", rr: "ARD",
        last_charge: "Dernière charge", added: "kWh ajoutés", used: "kWh consommés",
        update_msg: "Mise à jour automatique toutes les 30s",
        credits: "Credits", referral: "Parrainage", referral2: "Lien de parrainage",
        charging: "EN CHARGE", version: "Version",
        asleep: "EN VEILLE", parked: "STATIONNEMENT", online: "EN LIGNE", offline: "HORS LIGNE",
        charge_limit: "Limite charge", time_remaining: "Temps restant",
        updated_ago: "mis à jour il y a", just_now: "à l'instant",
        check_update_label: "Vérification mise à jour :",
        minutes: "min", hours: "h",
        update_available: "Mise à jour disponible",
        update_btn: "Télécharger", update_installing: "Téléchargement...",
        update_done: "Fichiers téléchargés dans /tmp ✓",
        teslamate: "TeslaMate", grafana: "Grafana",
        location: "Position", nav: "Navigation",
        install_confirm: "INSTALLER ?", yes: "OUI", no: "NON",
        update_success: "MISE À JOUR INSTALLÉE", continue: "CONTINUER"
      },
      en: {
        loading: "Loading...", refresh: "Refresh",
        tooltip_trips: "Trips", tooltip_notif: "Notifications",
        tooltip_export: "Export / Calculator", tooltip_conf: "Settings",
        tooltip_dashcam: "Dashcam", state: "Status", odometer: "Odometer",
        battery: "Battery", est_range: "Estimated Range",
        interior: "Interior", exterior: "Exterior",
        tires: "Tires", fl: "FL", fr: "FR", rl: "RL", rr: "RR",
        last_charge: "Last Charge", added: "kWh added", used: "kWh used",
        update_msg: "Auto-refresh every 30s",
        credits: "Credits", referral: "Referral", referral2: "Referral link",
        charging: "CHARGING", version: "Version",
        asleep: "ASLEEP", parked: "PARKED", online: "ONLINE", offline: "OFFLINE",
        charge_limit: "Charge limit", time_remaining: "Time remaining",
        updated_ago: "updated", just_now: "just now",
        check_update_label: "Update check:",
        minutes: "min", hours: "h",
        update_available: "Update available",
        update_btn: "Download", update_installing: "Downloading...",
        update_done: "Files downloaded to /tmp ✓",
        teslamate: "TeslaMate", grafana: "Grafana",
        location: "Location", nav: "Navigation",
        install_confirm: "INSTALL ?", yes: "YES", no: "NO",
        update_success: "UPDATE INSTALLED", continue: "CONTINUE"
      }
    };

    let currentLang = '<?= $default_lang ?>';
    let carData = null;
    let loading = false;
    let lastFetchTime = null;
    let updateAvailable = false;
    let updateInfo = null;
    let updateInstalling = false;
    let updateDone = false;
    let lastCheckTime = null;

    async function checkUpdate() {
      try {
        const res = await fetch('tesla.php?check_update=1&t=' + Date.now());
        const data = await res.json();
        lastCheckTime = Date.now();
        if (data.update) { updateAvailable = true; updateInfo = data; render(); }
      } catch(e) { console.error('checkUpdate:', e); }
    }

    async function doUpdate() {
      if (!updateInfo || updateInstalling) return;
      
      const t = i18n[currentLang];
      updateInstalling = true;
      render();
      
      try {
        // étape 1 : déclenchement systématique du téléchargement dans /tmp
        const res = await fetch(`tesla.php?do_update=1&sha=${encodeURIComponent(updateInfo.gh_sha)}&size=${encodeURIComponent(updateInfo.gh_size)}&t=${Date.now()}`);
        const data = await res.json();
        
        if (data.status === 'requires_confirmation') {
          // création de l'overlay de confirmation au centre de l'écran
          const overlay = document.createElement('div');
          overlay.style = "position:fixed;inset:0;background:rgba(0,0,0,0.85);backdrop-filter:blur(8px);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;";
          
          overlay.innerHTML = `
            <div class="glass rounded-2xl p-6 max-w-sm w-full text-center border border-white/10 glow-blue">
              <p class="label-font text-3xl font-bold text-white mb-6 tracking-wide">${t.install_confirm}</p>
              <div class="flex gap-4">
                <button id="btn-yes" class="flex-1 py-3 rounded-xl font-bold text-white bg-green-600 hover:bg-green-500 transition-colors uppercase tracking-wider">${t.yes}</button>
                <button id="btn-no" class="flex-1 py-3 rounded-xl font-bold text-white bg-red-600 hover:bg-red-500 transition-colors uppercase tracking-wider">${t.no}</button>
              </div>
            </div>
          `;
          document.body.appendChild(overlay);

          // action si non : on ferme et on redirige pour nettoyer l'état graphique
          document.getElementById('btn-no').onclick = () => {
            document.body.removeChild(overlay);
            window.location.href = 'tesla.php';
          };

          // action si oui : on execute le script synchrone
          document.getElementById('btn-yes').onclick = async () => {
            overlay.innerHTML = `
              <div class="text-center">
                <div class="w-12 h-12 rounded-full border-2 border-transparent border-t-green-500 border-r-blue-500 spin-slow mx-auto mb-4"></div>
                <p class="text-gray-400 text-sm tracking-widest uppercase">${t.update_installing}</p>
              </div>
            `;
            
            try {
              const res2 = await fetch(`tesla.php?do_update=1&sha=${encodeURIComponent(updateInfo.gh_sha)}&size=${encodeURIComponent(updateInfo.gh_size)}&confirm=1&t=${Date.now()}`);
              const data2 = await res2.json();
              
              if (data2.status === 'installed') {
                overlay.innerHTML = `
                  <div class="text-center px-4 max-w-md w-full">
                    <h2 class="label-font text-5xl md:text-6xl font-extrabold text-green-400 mb-8 tracking-tight drop-shadow-[0_0_25px_rgba(74,222,128,0.4)]">
                      ${t.update_success}
                    </h2>
                    <button id="btn-continue" class="px-8 py-3 rounded-xl font-bold text-black bg-green-400 hover:bg-green-300 transition-all shadow-lg shadow-green-500/20 uppercase tracking-widest text-sm">
                      ${t.continue}
                    </button>
                  </div>
                `;
                
                document.getElementById('btn-continue').onclick = () => {
                  document.body.removeChild(overlay);
                  window.location.href = 'tesla.php';
                };
              } else {
                alert(data2.msg || 'error');
                document.body.removeChild(overlay);
                window.location.href = 'tesla.php';
              }
            } catch(e) {
              console.error(e);
              document.body.removeChild(overlay);
              window.location.href = 'tesla.php';
            }
          };
        } else {
          alert(data.msg || 'error');
          updateInstalling = false;
          render();
        }
      } catch(e) {
        console.error(e);
        updateInstalling = false;
        render();
      }
    }

    function timeAgo(t) {
      if (!t) return '';
      const sec = Math.floor((Date.now() - t) / 1000);
      const lang = i18n[currentLang];
      if (sec < 10) return lang.just_now;
      if (sec < 3600) return lang.updated_ago + ' ' + Math.floor(sec / 60) + ' ' + lang.minutes;
      return lang.updated_ago + ' ' + Math.floor(sec / 3600) + lang.hours + Math.floor((sec % 3600) / 60) + lang.minutes;
    }

    function formatTimeRemaining(hours, t) {
      if (hours === null || hours === undefined) return null;
      const totalMin = Math.round(hours * 60);
      if (totalMin <= 0) return null;
      const h = Math.floor(totalMin / 60);
      const m = totalMin % 60;
      return h > 0 ? `${h}${t.hours} ${m}${t.minutes}` : `${m} ${t.minutes}`;
    }

    function tireColor(p) {
      if (p >= 2.8 && p <= 3.1) return '#4ade80';
      if ((p >= 2.5 && p < 2.8) || (p > 3.1 && p <= 3.3)) return '#fb923c';
      return '#f87171';
    }

    async function setLanguage(lang) {
      if (currentLang === lang) return;
      currentLang = lang; render();
      try { await fetch(`tesla.php?save_lang=${lang.toUpperCase()}&t=${Date.now()}`); }
      catch (e) { console.error(e); }
    }

    async function fetchData() {
      loading = true; render();
      try {
        const response = await fetch(API_URL);
        const data = await response.json();
        carData = data; lastFetchTime = Date.now();
      } catch (err) { console.error(err); }
      finally { loading = false; render(); }
    }

    let touchStartY = 0;
    document.addEventListener('touchstart', e => { touchStartY = e.touches[0].clientY; }, { passive: true });
    document.addEventListener('touchend', e => {
      const dy = e.changedTouches[0].clientY - touchStartY;
      if (dy > 80 && window.scrollY === 0) fetchData();
    }, { passive: true });

    function render() {
      const app = document.getElementById('app');
      if (!app) return;
      const t = i18n[currentLang];

      if (loading && !carData) {
        app.innerHTML = `
          <div class="min-h-screen flex flex-col items-center justify-center gap-4">
            <div class="w-10 h-10 rounded-full border-2 border-transparent border-t-red-500 border-r-blue-500 spin-slow"></div>
            <p class="text-gray-500 text-sm tracking-widest uppercase">${t.loading}</p>
          </div>`;
        return;
      }
      if (!carData) return;

      const isAsleep  = (carData.state === 'asleep');
      const isCharging = !isAsleep && (carData.state === 'charging' || carData.is_charging === true || parseFloat(carData.charger_power) > 0);

      const battPct    = carData.battery_level || 0;
      const battRange  = Math.round(carData.est_battery_range_km || 0);
      const battColor  = isCharging ? 'linear-gradient(90deg,#22c55e,#4ade80)' : battPct > 30 ? 'linear-gradient(90deg,#1a8cff,#60a5fa)' : 'linear-gradient(90deg,#e5232a,#f87171)';
      const timeLeft   = formatTimeRemaining(carData.time_to_full_charge, t);
      const chargeLimit = carData.charge_limit_soc ? carData.charge_limit_soc + '%' : null;

      app.innerHTML = `
      <div class="min-h-screen pb-16 max-w-lg mx-auto px-3">

        <div class="glass rounded-2xl px-4 pt-4 pb-3 mb-4">

          <div class="flex items-center justify-between mb-3">
            <button onclick="fetchData()" title="${t.refresh}"
              class="w-8 h-8 rounded-full glass glass-hover flex items-center justify-center transition-all">
              <svg class="w-4 h-4 ${loading ? 'spin-slow' : ''}" style="stroke:${loading?'#e5232a':'#6b7280'}" fill="none" viewBox="0 0 24 24">
                <path stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
              </svg>
            </button>
            <div class="flex gap-2">
              <img src="https://flagcdn.com/w40/fr.png" class="lang-btn w-7 h-5 ${currentLang==='fr'?'lang-active':''}" onclick="setLanguage('fr')" alt="FR">
              <img src="https://flagcdn.com/w40/gb.png" class="lang-btn w-7 h-5 ${currentLang==='en'?'lang-active':''}" onclick="setLanguage('en')" alt="EN">
            </div>
          </div>

          <div class="flex items-center justify-between gap-3 mb-3">
            <img src="tmmlogo.jpg" class="w-16 h-16 rounded-xl object-contain" style="opacity:0.9" alt="Logo">
            <div class="flex-1 text-center">
              <h1 class="label-font text-5xl font-bold tracking-tight text-white" style="letter-spacing:-1px">
                ${carData.name || 'Tesla'}
              </h1>
            </div>
            <img src="tmmlogo.jpg" class="w-16 h-16 rounded-xl object-contain" style="opacity:0.9" alt="Logo">
          </div>

          <div class="flex justify-center items-center gap-2 mb-2 flex-wrap">
            <a href="tesladashcam.php" class="nav-btn" title="${t.tooltip_dashcam}">
              <img src="dashcam_logosmall.jpg" class="w-6 h-6 object-contain rounded" alt="Dashcam">
              <span>${t.tooltip_dashcam}</span>
            </a>
            <a href="teslamap.php" class="nav-btn" title="${t.tooltip_trips}">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="2" d="M9 20l-5.447-2.724A2 2 0 013 15.488V5.13a2 2 0 011.106-1.789L9 1m0 19v-19m0 19l6-3m-6-16l6 3m0 0l5.447-2.724A2 2 0 0121 4.512v10.358a2 2 0 01-1.106 1.789L15 20m0-19v19"/></svg>
              <span>${t.tooltip_trips}</span>
            </a>
            <a href="teslanotif.php" class="nav-btn" title="${t.tooltip_notif}">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
              <span>${t.tooltip_notif}</span>
            </a>
            <a href="teslacalcul.php" class="nav-btn" title="${t.tooltip_export}">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.017H7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
              <span>${t.tooltip_export}</span>
            </a>
            <a href="teslaconf.php" class="nav-btn" title="${t.tooltip_conf}">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><circle cx="12" cy="12" r="3"/></svg>
              <span>${t.tooltip_conf}</span>
            </a>
          </div>

          <div class="flex justify-center gap-6">
            <a href="http://${SERVER_IP}:4000" target="_blank"
               class="text-xs font-bold tracking-widest uppercase text-gray-600 hover:text-white transition-colors">${t.teslamate}</a>
            <a href="http://${SERVER_IP}:3000" target="_blank"
               class="text-xs font-bold tracking-widest uppercase text-gray-600 hover:text-white transition-colors">${t.grafana}</a>
          </div>
        </div>

        <div class="space-y-3">

          ${PHP_ADDRESS ? `
          <a href="https://www.google.com/maps?q=${PHP_ADDRESS_LAT},${PHP_ADDRESS_LNG}" target="_blank"
             class="glass glass-hover rounded-2xl px-4 py-3 flex items-center gap-3 transition-all" style="text-decoration:none">
            <svg class="w-4 h-4 shrink-0" style="stroke:#1a8cff" fill="none" viewBox="0 0 24 24">
              <path stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
              <path stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            <span class="text-sm text-gray-300 truncate">${PHP_ADDRESS}</span>
          </a>` : ''}

          <div class="glass rounded-2xl p-4 ${isCharging ? 'glow-green' : ''}">
            <div class="flex items-end justify-between mb-3">
              <div>
                <p class="kpi-label">${t.battery}</p>
                <p class="label-font text-6xl font-bold leading-none" style="color:${isCharging?'#4ade80':battPct>30?'#1a8cff':'#e5232a'}">${battPct}<span class="text-2xl text-gray-500">%</span></p>
              </div>
              <div class="text-right">
                <p class="kpi-label">${t.est_range}</p>
                <p class="label-font text-3xl font-bold text-white">${battRange} <span class="text-base text-gray-500">km</span></p>
                ${isCharging && carData.charger_power_kw ? `<p class="text-sm font-bold pulse-charge" style="color:#4ade80">${carData.charger_power_kw} kW</p>` : ''}
              </div>
            </div>
            <div class="battery-track mb-3">
              <div class="battery-fill" style="width:${battPct}%;background:${battColor}"></div>
            </div>
            ${chargeLimit || timeLeft ? `
            <div class="flex gap-3 mt-1">
              ${chargeLimit ? `<div class="glass rounded-xl px-3 py-2 flex-1 text-center"><p class="kpi-label">${t.charge_limit}</p><p class="label-font text-lg font-bold text-white">${chargeLimit}</p></div>` : ''}
              ${timeLeft ? `<div class="glass rounded-xl px-3 py-2 flex-1 text-center"><p class="kpi-label">${t.time_remaining}</p><p class="label-font text-lg font-bold" style="color:#4ade80">${timeLeft}</p></div>` : ''}
            </div>` : ''}
          </div>

          <div class="grid grid-cols-2 gap-3">
            <div class="kpi-card glass rounded-2xl">
              <p class="kpi-label">${t.odometer}</p>
              <p class="kpi-val">${Math.round(carData.odometer || 0).toLocaleString()}</p>
              <p class="kpi-unit">km</p>
            </div>
            <div class="kpi-card glass rounded-2xl">
              <p class="kpi-label">${t.version}</p>
              <a href="https://www.notateslaapp.com/software-updates/version/${carData.version}/release-notes" target="_blank"
                 class="kpi-val hover:underline decoration-dotted" style="color:#1a8cff;text-decoration:none">${carData.version || '—'}</a>
              <p class="kpi-unit">firmware</p>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-3">
            <div class="kpi-card glass rounded-2xl">
              <p class="kpi-label">${t.interior}</p>
              <p class="kpi-val" style="color:#fb923c">${parseFloat(carData.inside_temp || 0).toFixed(1)}<span class="text-xl">°</span></p>
            </div>
            <div class="kpi-card glass rounded-2xl">
              <p class="kpi-label">${t.exterior}</p>
              <p class="kpi-val" style="color:#60a5fa">${parseFloat(carData.outside_temp || 0).toFixed(1)}<span class="text-xl">°</span></p>
            </div>
          </div>

          <div class="glass rounded-2xl p-4">
            <p class="kpi-label mb-3">${t.tires} (bar)</p>
            <div class="grid grid-cols-2 gap-x-6 gap-y-3">
              ${[['fl','fr'],['rl','rr']].map(row => `
                <div class="text-center">
                  <p class="kpi-label">${t[row[0]]}</p>
                  <p class="tire-val" style="color:${tireColor(carData['tpms_pressure_' + row[0]])}">${parseFloat(carData['tpms_pressure_' + row[0]] || 0).toFixed(1)}</p>
                </div>
                <div class="text-center">
                  <p class="kpi-label">${t[row[1]]}</p>
                  <p class="tire-val" style="color:${tireColor(carData['tpms_pressure_' + row[1]])}">${parseFloat(carData['tpms_pressure_' + row[1]] || 0).toFixed(1)}</p>
                </div>`).join('')}
            </div>
          </div>

          <div class="glass rounded-2xl p-4">
            <p class="kpi-label mb-3">${t.last_charge}</p>
            <div class="grid grid-cols-2 gap-3">
              <div class="glass rounded-xl px-4 py-3 text-center" style="border-color:rgba(26,140,255,0.3)">
                <p class="kpi-label" style="color:#1a8cff">${t.added}</p>
                <p class="label-font text-3xl font-bold text-white">${PHP_LAST_CHARGE_ADDED}</p>
                <p class="kpi-unit">kWh</p>
              </div>
              <div class="glass rounded-xl px-4 py-3 text-center" style="border-color:rgba(229,35,42,0.3)">
                <p class="kpi-label" style="color:#e5232a">${t.used}</p>
                <p class="label-font text-3xl font-bold text-white">${PHP_LAST_CHARGE_USED}</p>
                <p class="kpi-unit">kWh</p>
              </div>
            </div>
          </div>

          <p class="text-center text-sm font-bold text-gray-500 uppercase tracking-wide">
            ${lastCheckTime ? t.check_update_label + ' ' + timeAgo(lastCheckTime) : ''}
          </p>

          ${updateAvailable ? `
          <div class="glass rounded-2xl p-4 flex items-center justify-between gap-4" style="border-color:rgba(251,191,36,0.4)">
            <span class="font-bold text-yellow-400">🔄 ${t.update_available}</span>
            <button onclick="doUpdate()"
              class="px-4 py-2 rounded-xl font-bold text-sm text-black transition-all ${updateInstalling ? 'opacity-50 cursor-wait' : 'hover:brightness-110'}"
              style="background:#fbbf24">
              ${updateInstalling ? t.update_installing : t.update_btn}
            </button>
          </div>` : ''}

        </div>

        <div class="glass rounded-2xl mt-4 grid grid-cols-2 divide-x divide-white/10 overflow-hidden">
          <a href="credits.php" class="footer-link">
            <p class="kpi-label mb-1">${t.credits}</p>
            <p class="label-font text-lg font-bold text-white">Credits</p>
          </a>
          <a href="parrain.php" class="footer-link">
            <p class="kpi-label mb-1">${t.referral}</p>
            <p class="label-font text-lg font-bold text-white">${t.referral2}</p>
          </a>
        </div>
        <p class="text-center text-xs text-gray-700 mt-3 uppercase tracking-widest">TeslaMate Mail ${APP_VERSION}</p>

      </div>`;
    }

    fetchData();
    setInterval(fetchData, REFRESH_INTERVAL * 1000);
    checkUpdate();
    setInterval(checkUpdate, 3600 * 1000);
  </script>
</body>
</html>

