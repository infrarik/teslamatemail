<?php
require_once __DIR__ . '/auth_check.php';
// --- 1. LECTURE DU SETUP ---
$file = __DIR__ . '/cgi-bin/setup';
$config = ['NOTIFICATION_EMAIL' => '', 'DOCKER_PATH' => '', 'LANGUAGE' => 'fr', 'CURRENCY' => 'EUR', 'RAPPORT_HEBDO' => 'False', 'KWH_PRICE' => '0'];

if (file_exists($file)) {
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) { 
            $config[strtoupper(trim($parts[0]))] = trim($parts[1]); 
        }
    }
}

// Détection de la langue unique via setup
$lang = (isset($config['LANGUAGE']) && strtolower($config['LANGUAGE']) === 'en') ? 'en' : 'fr';
$monnaie = $config['CURRENCY'] ?? 'EUR';

// --- 2. DICTIONNAIRE DE TRADUCTION ---
$texts = [
    'fr' => [
        'title' => "Consommation",
        'lbl_car' => "Véhicule",
        'lbl_geo' => "Lieu (Geofence)",
        'all_locations' => "-- TOUS LES LIEUX --",
        'lbl_start' => "Début",
        'lbl_end' => "Fin",
        'lbl_price' => "Prix du kWh",
        'lbl_price_geo' => "Prix pour ce lieu",
        'lbl_details' => "Export complet",
        'lbl_select_all' => "TOUT SÉLECTIONNER",
        'btn_valider' => "VALIDER",
        'res_dist' => "Distance :",
        'res_count' => "Charges :",
        'res_energy_added' => "Énergie ajoutée :",
        'res_energy_used' => "Énergie consommée :",
        'res_cost' => "Coût total :",
        'btn_email' => "ENVOI PAR EMAIL",
        'btn_pdf' => "TÉLÉCHARGER PDF",
        'btn_csv' => "TÉLÉCHARGER CSV",
        'report_title' => "Rapport TeslaMate",
        'period' => "Période",
        'car' => "Véhicule",
        'dist_label' => "Distance",
        'charges_label' => "Charges",
        'energy_added_label' => "Énergie ajoutée",
        'energy_used_label' => "Énergie consommée",
        'cost_label' => "Coût",
        'print_btn' => "Imprimer / PDF",
        'sent_to' => "Envoyé à",
        'period_week' => "Cette semaine",
        'period_last_week' => "Semaine dernière",
        'period_month' => "Ce mois",
        'period_last_month' => "Mois dernier",
        'period_year' => "Cette année",
        'period_last_year' => "Année précédente",
        'period_custom' => "Période personnalisée",
        'no_data' => "Pas de données disponibles",
        'lbl_v2l' => "V2L (Vehicle-to-Load)",
        'lbl_rapport' => "Rapport hebdo (lundi 4h)",
        'rapport_on' => "Activé",
        'rapport_off' => "Désactivé",
        'cols' => ['date'=>'Date','kwh'=>'kWh ajoutés','kwh_used'=>'kWh consommés','cost'=>'Coût','duree'=>'Durée de charge','km'=>'km parcourus','ville'=>'Ville','gps'=>'GPS']
    ],
    'en' => [
        'title' => "Consumption",
        'lbl_car' => "Vehicle",
        'lbl_geo' => "Location (Geofence)",
        'all_locations' => "-- ALL LOCATIONS --",
        'lbl_start' => "Start",
        'lbl_end' => "End",
        'lbl_price' => "kWh Price",
        'lbl_price_geo' => "Price for this location",
        'lbl_details' => "Detailed Export",
        'lbl_select_all' => "SELECT ALL",
        'btn_valider' => "CALCULATE",
        'res_dist' => "Distance:",
        'res_count' => "Charges:",
        'res_energy_added' => "Energy added:",
        'res_energy_used' => "Energy used:",
        'res_cost' => "Total Cost:",
        'btn_email' => "SEND BY EMAIL",
        'btn_pdf' => "DOWNLOAD PDF",
        'btn_csv' => "DOWNLOAD CSV",
        'report_title' => "TeslaMate Report",
        'period' => "Period",
        'car' => "Vehicle",
        'dist_label' => "Distance",
        'charges_label' => "Charges",
        'energy_added_label' => "Energy added",
        'energy_used_label' => "Energy used",
        'cost_label' => "Cost",
        'print_btn' => "Print / PDF",
        'sent_to' => "Sent to",
        'period_week' => "This week",
        'period_last_week' => "Last week",
        'period_month' => "This month",
        'period_last_month' => "Last month",
        'period_year' => "This year",
        'period_last_year' => "Last year",
        'period_custom' => "Custom period",
        'no_data' => "No data available",
        'lbl_v2l' => "V2L (Vehicle-to-Load)",
        'lbl_rapport' => "Weekly report (Monday 4am)",
        'rapport_on' => "Enabled",
        'rapport_off' => "Disabled",
        'cols' => ['date'=>'Date','kwh'=>'kWh added','kwh_used'=>'kWh used','cost'=>'Cost','duree'=>'Duration','km'=>'km driven','ville'=>'City','gps'=>'GPS']
    ]
];
$t = $texts[$lang];

// --- TOGGLE RAPPORT HEBDO (GET) ---
if (isset($_GET['toggle_rapport']) && file_exists($file)) {
    $new_val = ($config['RAPPORT_HEBDO'] === 'True') ? 'False' : 'True';
    $lines = file($file, FILE_IGNORE_NEW_LINES);
    $found = false;
    $newLines = [];
    foreach ($lines as $line) {
        if (preg_match('/^rapport_hebdo=/i', trim($line))) {
            $newLines[] = 'rapport_hebdo=' . $new_val;
            $found = true;
        } else {
            $newLines[] = $line;
        }
    }
    if (!$found) $newLines[] = 'rapport_hebdo=' . $new_val;
    file_put_contents($file, implode("\n", $newLines) . "\n");
    header("Location: teslacalcul.php");
    exit;
}

// --- 3. EXTRACTION IDENTIFIANTS DOCKER ---
if (!empty($config['DOCKER_PATH']) && file_exists($config['DOCKER_PATH'])) {
    $docker_content = file_get_contents($config['DOCKER_PATH']);
    if (preg_match('/POSTGRES_USER[:=]\s*(\S+)/', $docker_content, $m)) $db_user = str_replace(['"', "'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_PASSWORD[:=]\s*(\S+)/', $docker_content, $m)) $db_pass = str_replace(['"', "'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_DB[:=]\s*(\S+)/', $docker_content, $m)) $db_name = str_replace(['"', "'"], '', trim($m[1]));
}

// --- 4. CONNEXION DB ---
try {
    $pdo = new PDO("pgsql:host=localhost;port=5432;dbname=$db_name", $db_user, $db_pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// --- 5. RÉCUPÉRATION DES VÉHICULES ET GEOFENCES ---
$stmt_cars = $pdo->query("SELECT id, COALESCE(name, model) as display_name FROM cars ORDER BY id ASC");
$cars = $stmt_cars->fetchAll(PDO::FETCH_ASSOC);
$stmt_geo = $pdo->query("SELECT id, name FROM geofences ORDER BY name ASC");
$geofences = $stmt_geo->fetchAll(PDO::FETCH_ASSOC);

// --- 6. LOGIQUE DE CALCUL ET EXPORT ---
$resultats = ['nb' => 0, 'total_kwh_added' => 0, 'total_kwh_used' => 0, 'total_km' => 0, 'total_cost' => 0];
$historique_fusionne = [];

$date_debut = $_POST['date_debut'] ?? date('Y-m-01');
$date_fin = $_POST['date_fin'] ?? date('Y-m-d');

if (isset($_POST['quick_period'])) {
    switch ($_POST['quick_period']) {
        case 'week': $date_debut = date('Y-m-d', strtotime('monday this week')); $date_fin = date('Y-m-d'); break;
        case 'last_week': $date_debut = date('Y-m-d', strtotime('monday last week')); $date_fin = date('Y-m-d', strtotime('sunday last week')); break;
        case 'month': $date_debut = date('Y-m-01'); $date_fin = date('Y-m-d'); break;
        case 'last_month': $date_debut = date('Y-m-01', strtotime('first day of last month')); $date_fin = date('Y-m-t', strtotime('last day of last month')); break;
        case 'year': $date_debut = date('Y-01-01'); $date_fin = date('Y-m-d'); break;
        case 'last_year': $date_debut = date('Y-01-01', strtotime('first day of january last year')); $date_fin = date('Y-12-31', strtotime('last day of december last year')); break;
    }
}

// Prix kWh : POST > setup, et sauvegarde dans setup si soumis
$kwh_price = floatval($_POST['kwh_price'] ?? $config['KWH_PRICE'] ?? 0);

// Charger tous les prix par geofence depuis setup : KWH_PRICE_GEO_[id]
$prix_geo = [];
foreach ($config as $k => $v) {
    if (preg_match('/^KWH_PRICE_GEO_(\d+)$/i', $k, $m)) {
        $prix_geo[(int)$m[1]] = floatval($v);
    }
}

if (isset($_POST['kwh_price']) && file_exists($file)) {
    $geo_id_save  = $_POST['geofence'] ?? 'TOUS';
    $price_to_save = floatval($_POST['kwh_price']);
    // Clé à écrire : KWH_PRICE_GEO_[id] si geofence, sinon KWH_PRICE
    $key_to_save  = ($geo_id_save !== 'TOUS') ? 'KWH_PRICE_GEO_' . $geo_id_save : 'KWH_PRICE';
    $val_to_save  = number_format($price_to_save, 4, '.', '');

    if ($price_to_save > 0) {
        $lines  = file($file, FILE_IGNORE_NEW_LINES);
        $found  = false;
        $newLines = [];
        foreach ($lines as $line) {
            if (preg_match('/^' . preg_quote($key_to_save, '/') . '=/i', trim($line))) {
                $newLines[] = $key_to_save . '=' . $val_to_save;
                $found = true;
            } else {
                $newLines[] = $line;
            }
        }
        if (!$found) $newLines[] = $key_to_save . '=' . $val_to_save;
        file_put_contents($file, implode("\n", $newLines) . "\n");
        // Mettre à jour $prix_geo en mémoire
        if ($geo_id_save !== 'TOUS') $prix_geo[(int)$geo_id_save] = $price_to_save;
        else $kwh_price = $price_to_save;
    }
}
$selected_car = $_POST['car_id'] ?? ($cars[0]['id'] ?? 1);
$selected_geo = $_POST['geofence'] ?? 'TOUS';
$export_complet = isset($_POST['export_complet']) ? 1 : 0;
$v2l_mode = isset($_POST['v2l_mode']) ? 1 : 0;
$cols = $_POST['cols'] ?? ['date', 'kwh', 'kwh_used', 'cost', 'duree', 'km', 'ville', 'gps'];
$status_message = "";

$car_name_display = "Vehicle";
foreach ($cars as $car) { if ($car['id'] == $selected_car) { $car_name_display = $car['display_name']; break; } }

if (isset($_POST['calculer']) || isset($_POST['envoyer_email']) || isset($_POST['telecharger_pdf']) || isset($_POST['telecharger_csv']) || isset($_POST['quick_period'])) {
    try {
        $params = ['debut' => $date_debut, 'fin' => $date_fin, 'car_id' => $selected_car];
        if ($v2l_mode) {
            // Mode V2L : énergie ajoutée = 0 ET énergie consommée > 0
            $where_charge = " WHERE cp.car_id = :car_id AND cp.start_date >= :debut AND cp.start_date < (:fin::date + interval '1 day') AND cp.charge_energy_added = 0 AND cp.charge_energy_used > 0";
        } else {
            $where_charge = " WHERE cp.car_id = :car_id AND cp.start_date >= :debut AND cp.start_date < (:fin::date + interval '1 day') AND cp.charge_energy_added > 0";
        }
        if ($selected_geo !== 'TOUS') {
            $where_charge .= " AND cp.geofence_id = :geo_id";
            $params['geo_id'] = $selected_geo;
        }

        // Récupération de chaque charge individuellement (pas de GROUP BY date)
        $sql_rec = "SELECT cp.id, cp.start_date, cp.start_date::date as date_f, cp.charge_energy_added as kwh, cp.charge_energy_used as kwh_used, EXTRACT(EPOCH FROM (cp.end_date - cp.start_date))/60 as duree, p.latitude as lat, p.longitude as lon, a.city as ville, cp.geofence_id
                    FROM charging_processes cp 
                    LEFT JOIN addresses a ON cp.address_id = a.id
                    LEFT JOIN positions p ON cp.position_id = p.id
                    " . $where_charge . " ORDER BY cp.start_date ASC";
        $stmt_rec = $pdo->prepare($sql_rec);
        $stmt_rec->execute($params);
        $charges_individuelles = $stmt_rec->fetchAll(PDO::FETCH_ASSOC);

        if (!$v2l_mode) {
            $sql_tra = "SELECT start_date::date as date_f, SUM(distance) as km, SUM(EXTRACT(EPOCH FROM (end_date - start_date))/60) as duree 
                        FROM drives WHERE car_id = :car_id AND start_date >= :debut AND start_date < (:fin::date + interval '1 day') AND distance > 0.1 
                        GROUP BY start_date::date";
            $stmt_tra = $pdo->prepare($sql_tra);
            $stmt_tra->execute(['car_id' => $selected_car, 'debut' => $date_debut, 'fin' => $date_fin]);
            $trajets_par_jour = $stmt_tra->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $trajets_par_jour = [];
        }

        $temp_hist = [];
        $total_kwh_added_accumule = 0; $total_kwh_used_accumule = 0; $total_km_accumule = 0; $compteur_charges = 0;

        // Une entrée par charge individuelle, clé = id de la charge
        foreach ($charges_individuelles as $c) {
            $key = 'charge_' . $c['id'];
            // Prix : géofence spécifique > prix général
            $geo_id_charge = (int)($c['geofence_id'] ?? 0);
            $price_charge  = ($geo_id_charge > 0 && isset($prix_geo[$geo_id_charge]))
                             ? $prix_geo[$geo_id_charge] : $kwh_price;
            $cost_charge = $c['kwh_used'] * $price_charge;
            $temp_hist[$key] = ['date' => $c['date_f'], 'start_date' => $c['start_date'], 'kwh' => $c['kwh'], 'kwh_used' => $c['kwh_used'], 'cost' => $cost_charge, 'duree' => $c['duree'], 'km' => 0, 'ville' => $c['ville'], 'gps' => round($c['lat'],5).','.round($c['lon'],5)];
            $total_kwh_added_accumule += $c['kwh'];
            $total_kwh_used_accumule += $c['kwh_used'];
            if ($c['kwh'] > 0 || $v2l_mode) $compteur_charges++;
        }
        // Ajout des km par jour de trajet (associés à la première charge du jour)
        $km_par_date_attribue = [];
        foreach ($trajets_par_jour as $trajet) {
            $d = $trajet['date_f'];
            $total_km_accumule += $trajet['km'];
            if (!isset($km_par_date_attribue[$d])) {
                foreach ($temp_hist as $key => &$entry) {
                    if ($entry['date'] === $d) {
                        $entry['km'] += $trajet['km'];
                        $km_par_date_attribue[$d] = true;
                        break;
                    }
                }
                unset($entry);
                // Si aucune charge ce jour-là, créer une entrée de trajet seul
                if (!isset($km_par_date_attribue[$d])) {
                    $temp_hist['drive_' . $d] = ['date' => $d, 'start_date' => $d, 'kwh' => 0, 'kwh_used' => 0, 'cost' => 0, 'duree' => $trajet['duree'], 'km' => $trajet['km'], 'ville' => '', 'gps' => ''];
                    $km_par_date_attribue[$d] = true;
                }
            }
        }
        // Tri chronologique par heure de début
        uasort($temp_hist, function($a, $b) { return strcmp($a['start_date'], $b['start_date']); });
        $historique_fusionne = $temp_hist;
        $total_cost_accumule = array_sum(array_column(array_filter(array_values($temp_hist), fn($e) => isset($e['cost'])), 'cost'));
        $resultats = [
            'nb' => $compteur_charges, 
            'total_kwh_added' => round($total_kwh_added_accumule, 2), 
            'total_kwh_used' => round($total_kwh_used_accumule, 2),
            'total_km' => round($total_km_accumule, 1),
            'total_cost' => round($total_cost_accumule, 2),
            'conso_100' => ($total_km_accumule > 0) ? round($total_kwh_used_accumule / $total_km_accumule * 100, 1) : 0,
        ];

    } catch (Exception $e) { die("Erreur : " . $e->getMessage()); }

    // --- EMAIL / PDF / CSV ---
    if (isset($_POST['envoyer_email']) && !empty($config['NOTIFICATION_EMAIL'])) {
        require_once __DIR__ . '/fn_mail_rapport.php';
        $to       = $config['NOTIFICATION_EMAIL'];
        $subject  = $t['report_title'] . " - $car_name_display - $date_debut / $date_fin";
        // Adapter les noms de variables pour le gabarit ($rap_debut / $rap_fin)
        $rap_debut = $date_debut;
        $rap_fin   = $date_fin;
        if (fn_envoyer_rapport($to, $subject, __DIR__,
            $rap_debut, $rap_fin, $t, $monnaie, $car_name_display,
            $resultats, $historique_fusionne, $v2l_mode, $cols, $lang)) {
            $status_message = $t['sent_to'] . " $to";
        }
    }
    if (isset($_POST['telecharger_pdf'])) {
        // Formatage de la date pour l'en-tête selon la langue
        $display_start = ($lang === 'fr') ? date('d/m/Y', strtotime($date_debut)) : $date_debut;
        $display_end = ($lang === 'fr') ? date('d/m/Y', strtotime($date_fin)) : $date_fin;

        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:sans-serif;padding:20px} h1{color:#dc2626;text-align:center} table{width:100%;border-collapse:collapse;margin-top:20px} td,th{border:1px solid #ddd;padding:10px;text-align:center;font-size:13px} th{background:#dc2626;color:#fff}</style></head><body>';
        echo '<h1>'.$t['report_title'].' - '.htmlspecialchars($car_name_display).'</h1>';
        echo '<p style="text-align:center">'.$t['period'].' : '.$display_start.' au '.$display_end.'</p>';
        if ($v2l_mode) {
            echo '<div style="margin-bottom:20px;text-align:center"><strong>'.$t['res_count'].'</strong> '.$resultats['nb'].' &nbsp;|&nbsp; <strong>'.$t['energy_used_label'].' :</strong> '.$resultats['total_kwh_used'].' kWh</div>';
            $cols_pdf = ['date', 'kwh_used', 'duree', 'ville', 'gps'];
        } else {
            echo '<div style="margin-bottom:20px;text-align:center"><strong>'.$t['dist_label'].' :</strong> '.$resultats['total_km'].' km | <strong>'.$t['energy_added_label'].' :</strong> '.$resultats['total_kwh_added'].' kWh | <strong>'.$t['energy_used_label'].' :</strong> '.$resultats['total_kwh_used'].' kWh | <strong>'.$t['cost_label'].' :</strong> '.$resultats['total_cost'].' '.$monnaie.'</div>';
            $cols_pdf = $cols;
        }
        echo '<table><tr>';
        foreach($cols_pdf as $c) echo "<th>".$t['cols'][$c]."</th>";
        echo '</tr>';
        foreach ($historique_fusionne as $l) {
            if ($v2l_mode && $l['kwh_used'] <= 0) continue;
            if (!$v2l_mode && $l['kwh'] == 0 && $l['kwh_used'] == 0) continue;
            echo '<tr>';
            if(in_array('date', $cols_pdf)) echo '<td>'.date('d/m/Y', strtotime($l['date'])).'</td>';
            if(in_array('kwh', $cols_pdf)) echo '<td>'.($l['kwh']>0?round($l['kwh'],2):'').'</td>';
            if(in_array('kwh_used', $cols_pdf)) echo '<td>'.($l['kwh_used']>0?round($l['kwh_used'],2):'').'</td>';
            if(in_array('cost', $cols_pdf)) echo '<td>'.($l['cost']>0?round($l['cost'],2):'').'</td>';
            if(in_array('duree', $cols_pdf)) echo '<td>'.round($l['duree']).' min</td>';
            if(in_array('km', $cols_pdf)) echo '<td>'.($l['km']>0?round($l['km'],1):'').'</td>';
            if(in_array('ville', $cols_pdf)) echo '<td>'.htmlspecialchars($l['ville']).'</td>';
            if(in_array('gps', $cols_pdf)) echo '<td>'.($l['gps'] != '0,0' ? $l['gps'] : '-').'</td>';
            echo '</tr>';
        }
        echo '</table><br><button onclick="window.print()" style="display:block;margin:auto;padding:10px 20px;background:#dc2626;color:#fff;border:none;border-radius:5px;cursor:pointer">'.$t['print_btn'].'</button></body></html>';
        exit;
    }
    if (isset($_POST['telecharger_csv'])) {
        header('Content-Type: text/csv'); header('Content-Disposition: attachment; filename="export.csv"');
        $f = fopen('php://output', 'w'); 
        $cols_csv = $v2l_mode ? ['date', 'kwh_used', 'duree', 'ville', 'gps'] : $cols;
        $headers = [];
        foreach($cols_csv as $c) $headers[] = $t['cols'][$c];
        fputcsv($f, $headers, ';');
        foreach($historique_fusionne as $l) {
            if ($v2l_mode && $l['kwh_used'] <= 0) continue;
            if (!$v2l_mode && $l['kwh'] == 0 && $l['kwh_used'] == 0) continue;
            $row = [];
            foreach($cols_csv as $c) {
                if ($c == 'kwh') $row[] = round($l['kwh'],2);
                elseif ($c == 'kwh_used') $row[] = round($l['kwh_used'],2);
                elseif ($c == 'date' && $lang === 'fr') $row[] = date('d/m/Y', strtotime($l['date']));
                else $row[] = $l[$c] ?? '';
            }
            fputcsv($f, $row, ';');
        }
        fclose($f); exit;
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TeslaCalcul</title>
    <style>
        body { font-family: -apple-system, sans-serif; background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); color: #fff; margin: 0; padding: 20px; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .container { background: rgba(255, 255, 255, 0.05); border-radius: 20px; padding: 40px; max-width: 500px; width: 100%; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3); border: 1px solid rgba(255, 255, 255, 0.1); position: relative; }
        .back-button { position: absolute; top: 20px; left: 20px; width: 40px; height: 40px; background: rgba(255, 255, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; }
        .back-button svg { width: 24px; height: 24px; stroke: #fff; stroke-width: 2; fill: none; }
        h1 { margin: 10px 0 30px 0; font-size: 28px; text-align: center; color: #dc2626; }
        label { display: block; font-size: 11px; color: #999; text-transform: uppercase; margin-bottom: 8px; margin-top: 15px; }
        input[type="date"], input[type="number"], select { width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.2); background: rgba(0,0,0,0.3); color: #fff; font-size: 16px; box-sizing: border-box; }
        .quick-periods { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 10px; }
        .btn-period { background: #8a2b2b; border: none; padding: 12px; border-radius: 10px; color: white; font-size: 14px; cursor: pointer; transition: background 0.2s; }
        .btn-period:hover { background: #dc2626; }
        .btn-period.active { background: #dc2626; font-weight: bold; border: 1px solid rgba(255,255,255,0.4); }
        .checkbox-group { background: rgba(0, 0, 0, 0.3); padding: 15px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1); margin-top: 10px; display: none; }
        .checkbox-item { display: flex; align-items: center; margin-bottom: 8px; font-size: 14px; cursor: pointer; }
        .checkbox-item input { margin-right: 12px; width: 18px; height: 18px; }
        .btn { width: 100%; padding: 14px; border: none; border-radius: 10px; color: white; font-weight: bold; cursor: pointer; margin-top: 20px; }
        .btn-calc { background: #16a34a; }
        .btn-mail { background: #2563eb; }
        .btn-pdf { background: #dc2626; }
        .btn-csv { background: #16a34a; }
        .result-box { background: rgba(0, 0, 0, 0.4); border-radius: 12px; padding: 20px; margin-top: 30px; border-left: 4px solid #16a34a; }
        .result-item { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 18px; }
        .result-value { font-weight: bold; color: #4ade80; }
        .alert { padding: 12px; border-radius: 8px; text-align: center; margin-bottom: 20px; background: rgba(34, 197, 94, 0.2); color: #4ade80; }
        #export_complet:checked ~ .checkbox-group { display: block; }
        .price-input-container { position: relative; }
        .currency-badge { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: #999; font-weight: bold; }
        .dates-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .switch-row { display: flex; align-items: center; justify-content: space-between; margin-top: 4px; }
        .switch { position: relative; display: inline-block; width: 52px; height: 28px; flex-shrink: 0; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; inset: 0; background: #4b5563; border-radius: 28px; transition: .3s; }
        .slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 4px; bottom: 4px; background: white; border-radius: 50%; transition: .3s; }
        input:checked + .slider { background: #16a34a; }
        input:checked + .slider:before { transform: translateX(24px); }
        .rapport-block { margin-top: 15px; background: rgba(0,0,0,0.3); padding: 12px 15px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1); }
    </style>
</head>
<body>
    <div class="container">
        <a href="tesla.php" class="back-button"><svg viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
        <h1><?php echo $t['title']; ?></h1>
        <?php if ($status_message): ?><div class="alert"><?php echo $status_message; ?></div><?php endif; ?>
        <form method="POST" id="mainForm">
            <label><?php echo $t['lbl_car']; ?></label>
            <select name="car_id"><?php foreach ($cars as $car): ?><option value="<?php echo $car['id']; ?>" <?php if($selected_car == $car['id']) echo 'selected'; ?>><?php echo htmlspecialchars($car['display_name']); ?></option><?php endforeach; ?></select>
            <label><?php echo $t['lbl_geo']; ?></label>
            <select name="geofence"><option value="TOUS"><?php echo $t['all_locations']; ?></option><?php foreach ($geofences as $geo): ?><option value="<?php echo $geo['id']; ?>" <?php if($selected_geo == $geo['id']) echo 'selected'; ?>><?php echo htmlspecialchars($geo['name']); ?></option><?php endforeach; ?></select>
            <label><?php echo $t['period']; ?></label>
            <div class="quick-periods">
                <button type="submit" name="quick_period" value="week" class="btn-period"><?php echo $t['period_week']; ?></button>
                <button type="submit" name="quick_period" value="last_week" class="btn-period"><?php echo $t['period_last_week']; ?></button>
                <button type="submit" name="quick_period" value="month" class="btn-period"><?php echo $t['period_month']; ?></button>
                <button type="submit" name="quick_period" value="last_month" class="btn-period"><?php echo $t['period_last_month']; ?></button>
                <button type="submit" name="quick_period" value="year" class="btn-period"><?php echo $t['period_year']; ?></button>
                <button type="submit" name="quick_period" value="last_year" class="btn-period"><?php echo $t['period_last_year']; ?></button>
                <button type="button" class="btn-period active"><?php echo $t['period_custom']; ?></button>
            </div>
            <div class="dates-row">
                <div><label><?php echo $t['lbl_start']; ?></label><input type="date" name="date_debut" value="<?php echo $date_debut; ?>" required></div>
                <div><label><?php echo $t['lbl_end']; ?></label><input type="date" name="date_fin" value="<?php echo $date_fin; ?>" required></div>
            </div>
            <label id="lbl_price_field"><?php
                // Afficher le bon label et la bonne valeur selon la geofence sélectionnée
                if ($selected_geo !== 'TOUS' && isset($prix_geo[(int)$selected_geo])) {
                    echo $t['lbl_price_geo'];
                    $kwh_price_display = $prix_geo[(int)$selected_geo];
                } else {
                    echo $t['lbl_price'];
                    $kwh_price_display = $kwh_price;
                }
            ?> (<?php echo $monnaie; ?>)</label>
            <div class="price-input-container">
                <input type="number" name="kwh_price" id="kwh_price_field" step="0.0001" value="<?php echo $kwh_price_display; ?>" placeholder="0.0000">
                <span class="currency-badge"><?php echo $monnaie; ?></span>
            </div>
            <?php
            // Injecter les prix geo en JS pour mise à jour dynamique
            $prix_geo_js = json_encode($prix_geo);
            $kwh_price_general = $kwh_price;
            ?>
            <div style="margin-top:20px;">
                <input type="checkbox" id="export_complet" name="export_complet" <?php if($export_complet) echo 'checked'; ?>>
                <label for="export_complet" style="display:inline; text-transform:none; color:white; font-size:14px; margin-left:10px;"><?php echo $t['lbl_details']; ?></label>
                <div class="checkbox-group">
                    <label class="checkbox-item"><input type="checkbox" id="toggleAll" checked> <span><?php echo $t['lbl_select_all']; ?></span></label>
                    <?php foreach($t['cols'] as $key => $label): ?>
                    <label class="checkbox-item"><input type="checkbox" name="cols[]" value="<?php echo $key; ?>" class="col-check" <?php if(in_array($key, $cols)) echo 'checked'; ?>> <span><?php echo $label; ?></span></label>
                    <?php endforeach; ?>
                </div>
            </div>
            <div style="margin-top:15px; background: rgba(0,0,0,0.3); padding: 12px 15px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1);">
                <input type="checkbox" id="v2l_mode" name="v2l_mode" <?php if($v2l_mode) echo 'checked'; ?>>
                <label for="v2l_mode" style="display:inline; text-transform:none; color:white; font-size:14px; margin-left:10px;"><?php echo $t['lbl_v2l']; ?></label>
            </div>
            <?php if (!empty($config['NOTIFICATION_EMAIL'])): ?>
            <div class="rapport-block">
                <div class="switch-row">
                    <label style="display:inline; text-transform:none; color:white; font-size:14px; margin:0;">
                        <?php echo $t['lbl_rapport']; ?>
                        <span style="margin-left:8px; font-size:12px; color:<?php echo $config['RAPPORT_HEBDO']==='True' ? '#4ade80' : '#9ca3af'; ?>;">
                            (<?php echo $config['RAPPORT_HEBDO']==='True' ? $t['rapport_on'] : $t['rapport_off']; ?>)
                        </span>
                    </label>
                    <a href="?toggle_rapport=1" class="switch" style="text-decoration:none;">
                        <input type="checkbox" onclick="window.location='?toggle_rapport=1'; return false;" <?php echo $config['RAPPORT_HEBDO']==='True' ? 'checked' : ''; ?>>
                        <span class="slider"></span>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <button type="submit" name="calculer" class="btn btn-calc"><?php echo $t['btn_valider']; ?></button>
            <?php if (isset($_POST['calculer']) || isset($_POST['quick_period'])): ?>
                <?php if ($resultats['total_kwh_added'] > 0 || $resultats['total_kwh_used'] > 0 || $resultats['nb'] > 0): ?>
                    <div class="result-box">
                        <?php if (!$v2l_mode): ?>
                        <div class="result-item"><span><?php echo $t['res_dist']; ?></span><span class="result-value"><?php echo $resultats['total_km']; ?> km</span></div>
                        <?php endif; ?>
                        <div class="result-item"><span><?php echo $t['res_count']; ?></span><span class="result-value"><?php echo $resultats['nb']; ?></span></div>
                        <?php if (!$v2l_mode): ?>
                        <div class="result-item"><span><?php echo $t['res_energy_added']; ?></span><span class="result-value"><?php echo $resultats['total_kwh_added']; ?> kWh</span></div>
                        <?php endif; ?>
                        <div class="result-item"><span><?php echo $t['res_energy_used']; ?></span><span class="result-value"><?php echo $resultats['total_kwh_used']; ?> kWh</span></div>
                        <?php if (!$v2l_mode): ?>
                        <div class="result-item"><span><?php echo $t['res_cost']; ?></span><span class="result-value"><?php echo $resultats['total_cost']; ?> <?php echo $monnaie; ?></span></div>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($config['NOTIFICATION_EMAIL'])): ?><button type="submit" name="envoyer_email" class="btn btn-mail"><?php echo $t['btn_email']; ?></button><?php endif; ?>
                    <button type="submit" name="telecharger_pdf" class="btn btn-pdf" formtarget="_blank"><?php echo $t['btn_pdf']; ?></button>
                    <button type="submit" name="telecharger_csv" class="btn btn-csv"><?php echo $t['btn_csv']; ?></button>
                <?php else: ?>
                    <div class="alert" style="background: rgba(220, 38, 38, 0.2); color: #fca5a5; margin-top: 20px;">
                        <?php echo $t['no_data']; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </form>
    </div>
    <script>
        const toggleAll = document.getElementById('toggleAll');
        const checkboxes = document.querySelectorAll('.col-check');
        if(toggleAll) { toggleAll.addEventListener('change', function() { checkboxes.forEach(cb => { cb.checked = toggleAll.checked; }); }); }

        // --- Prix par geofence ---
        const prixGeo     = <?= json_encode($prix_geo ?? []) ?>;
        const prixGeneral = <?= floatval($kwh_price_general ?? $kwh_price ?? 0) ?>;
        const lblPrice    = <?= json_encode($t['lbl_price'] . ' (' . $monnaie . ')') ?>;
        const lblPriceGeo = <?= json_encode($t['lbl_price_geo'] . ' (' . $monnaie . ')') ?>;

        const geoSelect   = document.querySelector('select[name="geofence"]');
        const priceInput  = document.getElementById('kwh_price_field');
        const priceLabel  = document.getElementById('lbl_price_field');

        if (geoSelect && priceInput) {
            geoSelect.addEventListener('change', function() {
                const geoId = parseInt(this.value);
                if (geoId && prixGeo[geoId] !== undefined) {
                    priceInput.value = prixGeo[geoId].toFixed(4);
                    if (priceLabel) priceLabel.textContent = lblPriceGeo;
                } else {
                    priceInput.value = prixGeneral > 0 ? prixGeneral.toFixed(4) : '';
                    if (priceLabel) priceLabel.textContent = lblPrice;
                }
            });
        }

        // --- Polyfill vieux navigateur (Tesla browser) ---
        (function() {
            const testInput = document.createElement('input');
            testInput.setAttribute('type', 'date');
            testInput.setAttribute('value', 'not-a-date');
            const supportsDate = (testInput.value !== 'not-a-date');

            if (!supportsDate) {
                const style = document.createElement('style');
                style.textContent = '.date-fallback-wrap{display:flex;gap:4px;margin-top:4px} .date-fallback-wrap select{flex:1;padding:10px 4px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.2);color:#fff;border-radius:10px;font-size:15px;}';
                document.head.appendChild(style);

                function makeDateSelects(input) {
                    const name  = input.getAttribute('name');
                    const val   = input.value || '';
                    const parts = val.split('-');
                    const yy = parts[0] || new Date().getFullYear();
                    const mm = parts[1] || '01';
                    const dd = parts[2] || '01';

                    const hidden = document.createElement('input');
                    hidden.type  = 'hidden';
                    hidden.name  = name;
                    hidden.value = val;

                    const selY = document.createElement('select');
                    const curY = new Date().getFullYear();
                    for (let y = curY; y >= curY - 5; y--) {
                        const o = document.createElement('option');
                        o.value = y; o.textContent = y;
                        if (String(y) === String(yy)) o.selected = true;
                        selY.appendChild(o);
                    }

                    const selM = document.createElement('select');
                    ['01','02','03','04','05','06','07','08','09','10','11','12'].forEach(m => {
                        const o = document.createElement('option');
                        o.value = m; o.textContent = m;
                        if (m === mm) o.selected = true;
                        selM.appendChild(o);
                    });

                    const selD = document.createElement('select');
                    for (let d = 1; d <= 31; d++) {
                        const dStr = String(d).padStart(2,'0');
                        const o = document.createElement('option');
                        o.value = dStr; o.textContent = dStr;
                        if (dStr === dd) o.selected = true;
                        selD.appendChild(o);
                    }

                    function updateHidden() {
                        hidden.value = `${selY.value}-${selM.value}-${selD.value}`;
                    }
                    [selY, selM, selD].forEach(s => s.addEventListener('change', updateHidden));

                    const wrap = document.createElement('div');
                    wrap.className = 'date-fallback-wrap';
                    wrap.appendChild(selD); wrap.appendChild(selM); wrap.appendChild(selY);
                    input.parentNode.insertBefore(wrap, input);
                    input.parentNode.insertBefore(hidden, input);
                    input.parentNode.removeChild(input);
                }

                document.querySelectorAll('input[type=date]').forEach(makeDateSelects);
            }

            // Sur vieux navigateur, les <select> ne soumettent pas toujours le formulaire
            // On s'assure que car_id et geofence déclenchent bien le bon comportement
            if (!supportsDate) {
                // select véhicule : recharge la page avec le bon car_id
                const carSelect = document.querySelector('select[name="car_id"]');
                if (carSelect) {
                    carSelect.addEventListener('change', function() {
                        const form = document.getElementById('mainForm');
                        if (form) form.submit();
                    });
                }
                // select geofence : idem
                if (geoSelect) {
                    geoSelect.addEventListener('change', function() {
                        const form = document.getElementById('mainForm');
                        if (form) form.submit();
                    });
                }
            }
        })();
    </script>
</body>
</html>
