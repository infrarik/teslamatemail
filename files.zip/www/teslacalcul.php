<?php
ob_start();
require_once __DIR__ . '/auth_check.php';
// --- 1. LECTURE DU SETUP ---
$file = __DIR__ . '/cgi-bin/setup';
$config = ['NOTIFICATION_EMAIL' => '', 'DOCKER_PATH' => '', 'LANGUAGE' => 'fr', 'CURRENCY' => 'EUR', 'RAPPORT_HEBDO' => 'False', 'KWH_PRICE' => '0', 'ADJUST' => '0'];

if (file_exists($file)) {
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) { 
            $config[strtoupper(trim($parts[0]))] = trim($parts[1]); 
        }
    }
}

$lang = (isset($config['LANGUAGE']) && strtolower($config['LANGUAGE']) === 'en') ? 'en' : 'fr';
$monnaie = $config['CURRENCY'] ?? 'EUR';

// Pourcentage d'ajustement
$adjust_percent = isset($config['ADJUST']) ? floatval($config['ADJUST']) : 0.0;
$adjust_factor = 1 + ($adjust_percent / 100);

// --- TRADUCTIONS ---
$texts = [
    'fr' => [
        'title' => "Consommation",
        'lbl_car' => "Véhicule",
        'lbl_geo' => "Lieu (Geofence)",
        'all_locations' => "-- TOUS LES LIEUX --",
        'lbl_start' => "Début",
        'lbl_end' => "Fin",
        'lbl_price' => "Prix du kWh",
        'lbl_price_geo' => "Prix pour ce lieu",
        'lbl_details' => "Export complet",
        'lbl_select_all' => "TOUT SÉLECTIONNER",
        'btn_valider' => "VALIDER",
        'res_dist' => "Distance :",
        'res_count' => "Charges :",
        'res_energy_added' => "Énergie ajoutée :",
        'res_energy_used' => "Énergie consommée :",
        'res_cost' => "Coût total :",
        'res_adjust' => "% d'ajustement :",
        'btn_email' => "ENVOI PAR EMAIL",
        'btn_pdf' => "TÉLÉCHARGER PDF",
        'btn_csv' => "TÉLÉCHARGER CSV",
        'btn_afficher' => "AFFICHER",
        'report_title' => "Rapport TeslaMate",
        'period' => "Période",
        'car' => "Véhicule",
        'dist_label' => "Distance",
        'charges_label' => "Charges",
        'energy_added_label' => "Énergie ajoutée",
        'energy_used_label' => "Énergie consommée",
        'cost_label' => "Coût",
        'print_btn' => "Imprimer / PDF",
        'sent_to' => "Envoyé à",
        'period_week' => "Cette semaine",
        'period_last_week' => "Semaine dernière",
        'period_month' => "Ce mois",
        'period_last_month' => "Mois dernier",
        'period_year' => "Cette année",
        'period_last_year' => "Année précédente",
        'period_today' => "Aujourd'hui",
        'period_custom' => "Période personnalisée",
        'no_data' => "Pas de données disponibles",
        'lbl_v2l' => "V2L (Vehicle-to-Load)",
        'lbl_rapport' => "Rapport hebdo (lundi 4h)",
        'rapport_on' => "Activé",
        'rapport_off' => "Désactivé",
        'lbl_adjust' => "% d'ajustement consommation",
        'cols' => ['date'=>'Date','kwh'=>'kWh ajoutés','kwh_used'=>'kWh consommés','cost'=>'Coût','duree'=>'Durée de charge','km'=>'km parcourus','ville'=>'Ville','gps'=>'GPS']
    ],
    'en' => [
        'title' => "Consumption",
        'lbl_car' => "Vehicle",
        'lbl_geo' => "Location (Geofence)",
        'all_locations' => "-- ALL LOCATIONS --",
        'lbl_start' => "Start",
        'lbl_end' => "End",
        'lbl_price' => "kWh Price",
        'lbl_price_geo' => "Price for this location",
        'lbl_details' => "Detailed Export",
        'lbl_select_all' => "SELECT ALL",
        'btn_valider' => "CALCULATE",
        'res_dist' => "Distance:",
        'res_count' => "Charges:",
        'res_energy_added' => "Energy added:",
        'res_energy_used' => "Energy used:",
        'res_cost' => "Total Cost:",
        'res_adjust' => "Adjustment %:",
        'btn_email' => "SEND BY EMAIL",
        'btn_pdf' => "DOWNLOAD PDF",
        'btn_csv' => "DOWNLOAD CSV",
        'btn_afficher' => "DISPLAY",
        'report_title' => "TeslaMate Report",
        'period' => "Period",
        'car' => "Vehicle",
        'dist_label' => "Distance",
        'charges_label' => "Charges",
        'energy_added_label' => "Energy added",
        'energy_used_label' => "Energy used",
        'cost_label' => "Cost",
        'print_btn' => "Print / PDF",
        'sent_to' => "Sent to",
        'period_week' => "This week",
        'period_last_week' => "Last week",
        'period_month' => "This month",
        'period_last_month' => "Last month",
        'period_year' => "This year",
        'period_last_year' => "Last year",
        'period_today' => "Today",
        'period_custom' => "Custom period",
        'no_data' => "No data available",
        'lbl_v2l' => "V2L (Vehicle-to-Load)",
        'lbl_rapport' => "Weekly report (Monday 4am)",
        'rapport_on' => "Enabled",
        'rapport_off' => "Disabled",
        'lbl_adjust' => "Consumption adjustment %",
        'cols' => ['date'=>'Date','kwh'=>'kWh added','kwh_used'=>'kWh used','cost'=>'Cost','duree'=>'Duration','km'=>'km driven','ville'=>'City','gps'=>'GPS']
    ]
];
$t = $texts[$lang];

// --- TOGGLE RAPPORT HEBDO ---
if (isset($_GET['toggle_rapport']) && file_exists($file)) {
    $new_val = ($config['RAPPORT_HEBDO'] === 'True') ? 'False' : 'True';
    $lines = file($file, FILE_IGNORE_NEW_LINES);
    $found = false;
    $newLines = [];
    foreach ($lines as $line) {
        if (preg_match('/^rapport_hebdo=/i', trim($line))) {
            $newLines[] = 'rapport_hebdo=' . $new_val;
            $found = true;
        } else {
            $newLines[] = $line;
        }
    }
    if (!$found) $newLines[] = 'rapport_hebdo=' . $new_val;
    file_put_contents($file, implode("\n", $newLines) . "\n");
    header("Location: teslacalcul.php");
    exit;
}

// --- SAUVEGARDE AJUSTEMENT ---
if (isset($_POST['save_adjust']) && file_exists($file)) {
    $new_adjust = floatval($_POST['adjust_percent']);
    $lines = file($file, FILE_IGNORE_NEW_LINES);
    $found = false;
    $newLines = [];
    foreach ($lines as $line) {
        if (preg_match('/^adjust=/i', trim($line))) {
            $newLines[] = 'adjust=' . number_format($new_adjust, 2, '.', '');
            $found = true;
        } else {
            $newLines[] = $line;
        }
    }
    if (!$found) $newLines[] = 'adjust=' . number_format($new_adjust, 2, '.', '');
    file_put_contents($file, implode("\n", $newLines) . "\n");
    header("Location: teslacalcul.php");
    exit;
}

// --- EXTRACTION DOCKER ---
if (!empty($config['DOCKER_PATH']) && file_exists($config['DOCKER_PATH'])) {
    $docker_content = file_get_contents($config['DOCKER_PATH']);
    if (preg_match('/POSTGRES_USER[:=]\s*(\S+)/', $docker_content, $m)) $db_user = str_replace(['"', "'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_PASSWORD[:=]\s*(\S+)/', $docker_content, $m)) $db_pass = str_replace(['"', "'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_DB[:=]\s*(\S+)/', $docker_content, $m)) $db_name = str_replace(['"', "'"], '', trim($m[1]));
}

// --- CONNEXION DB ---
try {
    $pdo = new PDO("pgsql:host=localhost;port=5432;dbname=$db_name", $db_user, $db_pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// --- RÉCUPÉRATION VÉHICULES ET GEOFENCES ---
$stmt_cars = $pdo->query("SELECT id, COALESCE(name, model) as display_name FROM cars ORDER BY id ASC");
$cars = $stmt_cars->fetchAll(PDO::FETCH_ASSOC);
$stmt_geo = $pdo->query("SELECT id, name FROM geofences ORDER BY name ASC");
$geofences = $stmt_geo->fetchAll(PDO::FETCH_ASSOC);

// --- VARIABLES PAR DÉFAUT ---
$resultats = ['nb' => 0, 'total_kwh_added' => 0, 'total_kwh_used' => 0, 'total_km' => 0, 'total_cost' => 0];
$historique_fusionne = [];
$date_debut = $_POST['date_debut'] ?? date('Y-m-01');
$date_fin = $_POST['date_fin'] ?? date('Y-m-d');

if (isset($_POST['quick_period'])) {
    switch ($_POST['quick_period']) {
        case 'today': $date_debut = date('Y-m-d'); $date_fin = date('Y-m-d'); break;
        case 'week': $date_debut = date('Y-m-d', strtotime('monday this week')); $date_fin = date('Y-m-d'); break;
        case 'last_week': $date_debut = date('Y-m-d', strtotime('monday last week')); $date_fin = date('Y-m-d', strtotime('sunday last week')); break;
        case 'month': $date_debut = date('Y-m-01'); $date_fin = date('Y-m-d'); break;
        case 'last_month': $date_debut = date('Y-m-01', strtotime('first day of last month')); $date_fin = date('Y-m-t', strtotime('last day of last month')); break;
        case 'year': $date_debut = date('Y-01-01'); $date_fin = date('Y-m-d'); break;
        case 'last_year': $date_debut = date('Y-01-01', strtotime('first day of january last year')); $date_fin = date('Y-12-31', strtotime('last day of december last year')); break;
    }
}

$kwh_price = floatval($_POST['kwh_price'] ?? $config['KWH_PRICE'] ?? 0);
$prix_geo = [];
foreach ($config as $k => $v) {
    if (preg_match('/^KWH_PRICE_GEO_(\d+)$/i', $k, $m)) {
        $prix_geo[(int)$m[1]] = floatval($v);
    }
}

if (isset($_POST['kwh_price']) && file_exists($file)) {
    $geo_id_save  = $_POST['geofence'] ?? 'TOUS';
    $price_to_save = floatval($_POST['kwh_price']);
    $key_to_save  = ($geo_id_save !== 'TOUS') ? 'KWH_PRICE_GEO_' . $geo_id_save : 'KWH_PRICE';
    $val_to_save  = number_format($price_to_save, 4, '.', '');
    if ($price_to_save > 0) {
        $lines  = file($file, FILE_IGNORE_NEW_LINES);
        $found  = false;
        $newLines = [];
        foreach ($lines as $line) {
            if (preg_match('/^' . preg_quote($key_to_save, '/') . '=/i', trim($line))) {
                $newLines[] = $key_to_save . '=' . $val_to_save;
                $found = true;
            } else {
                $newLines[] = $line;
            }
        }
        if (!$found) $newLines[] = $key_to_save . '=' . $val_to_save;
        file_put_contents($file, implode("\n", $newLines) . "\n");
        if ($geo_id_save !== 'TOUS') $prix_geo[(int)$geo_id_save] = $price_to_save;
        else $kwh_price = $price_to_save;
    }
}
$selected_car = $_POST['car_id'] ?? ($cars[0]['id'] ?? 1);
$selected_geo = $_POST['geofence'] ?? 'TOUS';
$export_complet = isset($_POST['export_complet']) ? 1 : 0;
$v2l_mode = isset($_POST['v2l_mode']) ? 1 : 0;
$cols = $_POST['cols'] ?? ['date', 'kwh', 'kwh_used', 'cost', 'duree', 'km', 'ville', 'gps'];
$status_message = "";

$car_name_display = "Vehicle";
foreach ($cars as $car) { if ($car['id'] == $selected_car) { $car_name_display = $car['display_name']; break; } }

// --- CALCUL PRINCIPAL (avec ajustement) ---
if (isset($_POST['calculer']) || isset($_POST['envoyer_email']) || isset($_POST['telecharger_pdf']) || isset($_POST['telecharger_csv']) || isset($_POST['quick_period']) || isset($_POST['afficher'])) {
    try {
        $params = ['debut' => $date_debut, 'fin' => $date_fin, 'car_id' => $selected_car];
        if ($v2l_mode) {
            $where_charge = " WHERE cp.car_id = :car_id AND cp.start_date >= :debut AND cp.start_date < (:fin::date + interval '1 day') AND cp.charge_energy_added = 0 AND cp.charge_energy_used > 0";
        } else {
            $where_charge = " WHERE cp.car_id = :car_id AND cp.start_date >= :debut AND cp.start_date < (:fin::date + interval '1 day') AND cp.charge_energy_added > 0";
        }
        if ($selected_geo !== 'TOUS') {
            $where_charge .= " AND cp.geofence_id = :geo_id";
            $params['geo_id'] = $selected_geo;
        }

        $sql_rec = "SELECT cp.id, cp.start_date, cp.start_date::date as date_f, cp.charge_energy_added as kwh, cp.charge_energy_used as kwh_used, EXTRACT(EPOCH FROM (cp.end_date - cp.start_date))/60 as duree, p.latitude as lat, p.longitude as lon, a.city as ville, cp.geofence_id
                    FROM charging_processes cp 
                    LEFT JOIN addresses a ON cp.address_id = a.id
                    LEFT JOIN positions p ON cp.position_id = p.id
                    " . $where_charge . " ORDER BY cp.start_date ASC";
        $stmt_rec = $pdo->prepare($sql_rec);
        $stmt_rec->execute($params);
        $charges_individuelles = $stmt_rec->fetchAll(PDO::FETCH_ASSOC);

        if (!$v2l_mode) {
            $sql_tra = "SELECT start_date::date as date_f, SUM(distance) as km, SUM(EXTRACT(EPOCH FROM (end_date - start_date))/60) as duree 
                        FROM drives WHERE car_id = :car_id AND start_date >= :debut AND start_date < (:fin::date + interval '1 day') AND distance > 0.1 
                        GROUP BY start_date::date";
            $stmt_tra = $pdo->prepare($sql_tra);
            $stmt_tra->execute(['car_id' => $selected_car, 'debut' => $date_debut, 'fin' => $date_fin]);
            $trajets_par_jour = $stmt_tra->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $trajets_par_jour = [];
        }

        $temp_hist = [];
        $total_kwh_added_accumule = 0;
        $total_kwh_used_accumule = 0;
        $total_km_accumule = 0;
        $compteur_charges = 0;

        foreach ($charges_individuelles as $c) {
            $key = 'charge_' . $c['id'];
            $geo_id_charge = (int)($c['geofence_id'] ?? 0);
            $price_charge  = ($geo_id_charge > 0 && isset($prix_geo[$geo_id_charge]))
                             ? $prix_geo[$geo_id_charge] : $kwh_price;
            // Application du facteur d'ajustement
            $cost_charge = $c['kwh_used'] * $price_charge * $adjust_factor;
            $temp_hist[$key] = [
                'date' => $c['date_f'],
                'start_date' => $c['start_date'],
                'kwh' => $c['kwh'],
                'kwh_used' => $c['kwh_used'],
                'cost' => $cost_charge,
                'duree' => $c['duree'],
                'km' => 0,
                'ville' => $c['ville'],
                'gps' => round($c['lat'],5).','.round($c['lon'],5)
            ];
            $total_kwh_added_accumule += $c['kwh'];
            $total_kwh_used_accumule += $c['kwh_used'];
            if ($c['kwh'] > 0 || $v2l_mode) $compteur_charges++;
        }

        $km_par_date_attribue = [];
        foreach ($trajets_par_jour as $trajet) {
            $d = $trajet['date_f'];
            $total_km_accumule += $trajet['km'];
            if (!isset($km_par_date_attribue[$d])) {
                foreach ($temp_hist as $key => &$entry) {
                    if ($entry['date'] === $d) {
                        $entry['km'] += $trajet['km'];
                        $km_par_date_attribue[$d] = true;
                        break;
                    }
                }
                unset($entry);
                if (!isset($km_par_date_attribue[$d])) {
                    $temp_hist['drive_' . $d] = [
                        'date' => $d,
                        'start_date' => $d,
                        'kwh' => 0,
                        'kwh_used' => 0,
                        'cost' => 0,
                        'duree' => $trajet['duree'],
                        'km' => $trajet['km'],
                        'ville' => '',
                        'gps' => ''
                    ];
                    $km_par_date_attribue[$d] = true;
                }
            }
        }
        uasort($temp_hist, function($a, $b) { return strcmp($a['start_date'], $b['start_date']); });
        $historique_fusionne = $temp_hist;
        $total_cost_accumule = array_sum(array_column(array_filter(array_values($temp_hist), fn($e) => isset($e['cost'])), 'cost'));
        $resultats = [
            'nb' => $compteur_charges,
            'total_kwh_added' => round($total_kwh_added_accumule, 2),
            'total_kwh_used' => round($total_kwh_used_accumule, 2),
            'total_km' => round($total_km_accumule, 1),
            'total_cost' => round($total_cost_accumule, 2),
            'conso_100' => ($total_km_accumule > 0) ? round($total_kwh_used_accumule / $total_km_accumule * 100, 1) : 0,
        ];

    } catch (Exception $e) { die("Erreur : " . $e->getMessage()); }

    // --- ENVOI EMAIL ---
    if (isset($_POST['envoyer_email']) && !empty($config['NOTIFICATION_EMAIL'])) {
        require_once __DIR__ . '/fn_mail_rapport.php';
        $to       = $config['NOTIFICATION_EMAIL'];
        $subject  = $t['report_title'] . " - $car_name_display - $date_debut / $date_fin";
        $rap_debut = $date_debut;
        $rap_fin   = $date_fin;
        if (fn_envoyer_rapport($to, $subject, __DIR__,
            $rap_debut, $rap_fin, $t, $monnaie, $car_name_display,
            $resultats, $historique_fusionne, $v2l_mode, $cols, $lang)) {
            $status_message = $t['sent_to'] . " $to";
        }
    }

    // --- TÉLÉCHARGEMENT PDF ---
    if (isset($_POST['telecharger_pdf'])) {
        require_once __DIR__ . '/fn_mail_rapport.php';
        $rap_debut = $date_debut;
        $rap_fin   = $date_fin;
        $pdf_data  = fn_generer_pdf($rap_debut, $rap_fin, $t, $monnaie, $car_name_display,
                                    $resultats, $historique_fusionne, $v2l_mode, $cols, $lang);
        $filename  = 'rapport_' . $rap_debut . '_' . $rap_fin . '.pdf';
        ob_end_clean();
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($pdf_data));
        echo $pdf_data;
        exit;
    }

    // --- TÉLÉCHARGEMENT CSV ---
    if (isset($_POST['telecharger_csv'])) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="export.csv"');
        $f = fopen('php://output', 'w');
        $cols_csv = $v2l_mode ? ['date', 'kwh_used', 'duree', 'ville', 'gps'] : $cols;
        $headers = [];
        foreach($cols_csv as $c) $headers[] = $t['cols'][$c];
        fputcsv($f, $headers, ';');
        foreach($historique_fusionne as $l) {
            if ($v2l_mode && $l['kwh_used'] <= 0) continue;
            if (!$v2l_mode && $l['kwh'] == 0 && $l['kwh_used'] == 0) continue;
            $row = [];
            foreach($cols_csv as $c) {
                if ($c == 'kwh') $row[] = round($l['kwh'],2);
                elseif ($c == 'kwh_used') $row[] = round($l['kwh_used'],2);
                elseif ($c == 'cost') $row[] = round($l['cost'],2);
                elseif ($c == 'date' && $lang === 'fr') $row[] = date('d/m/Y', strtotime($l['date']));
                else $row[] = $l[$c] ?? '';
            }
            fputcsv($f, $row, ';');
        }
        fclose($f);
        exit;
    }

    // --- AFFICHAGE HTML (bouton "AFFICHER") ---
    if (isset($_POST['afficher'])) {
        $display_start = ($lang === 'fr') ? date('d/m/Y', strtotime($date_debut)) : $date_debut;
        $display_end   = ($lang === 'fr') ? date('d/m/Y', strtotime($date_fin))   : $date_fin;
        
        $kwh_par_jour = [];
        foreach ($historique_fusionne as $l) {
            if (($l['kwh_used'] ?? 0) <= 0) continue;
            $kwh_par_jour[$l['date']] = ($kwh_par_jour[$l['date']] ?? 0) + $l['kwh_used'];
        }
        ksort($kwh_par_jour);
        $max_kwh = !empty($kwh_par_jour) ? max($kwh_par_jour) : 1;
        
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
        body{font-family:Arial,sans-serif;background:#f5f5f5;color:#222;padding:20px;margin:0}
        .wrap{max-width:900px;margin:auto;background:#fff;border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,.12);overflow:hidden}
        .hdr{background:#dc2626;color:#fff;padding:24px 30px;text-align:center;position:relative}
        .hdr h1{margin:0 0 6px;font-size:22px}
        .hdr p{margin:0;font-size:13px;opacity:.85}
        .logo{position:absolute;width:70px;height:70px;background:#1a1a2e;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:bold;color:#fff;line-height:1.2;text-align:center;padding:8px;box-sizing:border-box}
        .logo-left{left:20px;top:50%;transform:translateY(-50%)}
        .logo-right{right:20px;top:50%;transform:translateY(-50%)}
        .summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:0}
        .kpi{padding:18px 20px;border-right:1px solid #eee;border-bottom:1px solid #eee;text-align:center}
        .kpi .val{font-size:24px;font-weight:700;color:#dc2626}
        .kpi .lbl{font-size:11px;color:#777;text-transform:uppercase;margin-top:4px}
        .graph-section{padding:25px 30px;border-bottom:1px solid #eee}
        .graph-title{font-size:13px;font-weight:bold;margin-bottom:15px;color:#333}
        .graph-container{position:relative;height:150px;display:flex;align-items:flex-end;justify-content:space-around;border-bottom:2px solid #ccc;padding:0 10px}
        .bar-wrapper{flex:1;display:flex;flex-direction:column;align-items:center;max-width:80px}
        .bar{background:#dc2626;width:100%;position:relative;transition:all 0.3s}
        .bar-value{position:absolute;top:-20px;left:0;right:0;text-align:center;font-size:11px;font-weight:bold;color:#333}
        .bar-label{margin-top:8px;font-size:10px;color:#666;text-align:center}
        table{width:100%;border-collapse:collapse;font-size:13px}
        th{background:#dc2626;color:#fff;padding:10px;text-align:center;font-weight:bold}
        td{padding:10px;border-bottom:1px solid #eee;text-align:center}
        tr:nth-child(even) td{background:#fafafa}
        .footer{padding:14px 20px;font-size:11px;color:#aaa;text-align:center}
        </style></head><body><div class="wrap">';
        
        echo '<div class="hdr">';
        echo '<div class="logo logo-left">TESLAMATE<br>MAIL</div>';
        echo '<h1>'.htmlspecialchars($t['report_title']).' - '.htmlspecialchars($car_name_display).'</h1>';
        echo '<p>'.$t['period'].' : '.$display_start.' - '.$display_end.'</p>';
        echo '<div class="logo logo-right">TESLAMATE<br>MAIL</div>';
        echo '</div>';
        
        // KPIs (incluant le % d'ajustement)
        echo '<div class="summary">';
        if (!$v2l_mode) echo '<div class="kpi"><div class="val">'.$resultats['total_km'].' km</div><div class="lbl">'.$t['dist_label'].'</div></div>';
        echo '<div class="kpi"><div class="val">'.$resultats['nb'].'</div><div class="lbl">'.$t['charges_label'].'</div></div>';
        if (!$v2l_mode) echo '<div class="kpi"><div class="val">'.$resultats['total_kwh_added'].' kWh</div><div class="lbl">'.$t['energy_added_label'].'</div></div>';
        echo '<div class="kpi"><div class="val">'.$resultats['total_kwh_used'].' kWh</div><div class="lbl">'.$t['energy_used_label'].'</div></div>';
        if (!$v2l_mode) {
            echo '<div class="kpi"><div class="val">'.$resultats['total_cost'].' '.$monnaie.'</div><div class="lbl">'.$t['cost_label'].'</div></div>';
            echo '<div class="kpi"><div class="val">'.$adjust_percent.' %</div><div class="lbl">'.$t['res_adjust'].'</div></div>';
            if (($resultats['conso_100'] ?? 0) > 0) {
                echo '<div class="kpi"><div class="val">'.$resultats['conso_100'].'</div><div class="lbl">kWh/100km</div></div>';
            }
        }
        echo '</div>';
        
        // Graphique et tableau
        if (!$v2l_mode && !empty($kwh_par_jour)) {
            $graph_title = ($lang === 'fr') ? 'Consommation par jour (kWh)' : 'Daily consumption (kWh)';
            $dates_all = array_keys($kwh_par_jour);
            $chunks = array_chunk($dates_all, 7, true);
            $cols_pdf = $cols;
            foreach ($chunks as $chunk_index => $chunk_dates) {
                echo '<div class="graph-section">';
                if ($chunk_index === 0) echo '<div class="graph-title">'.$graph_title.'</div>';
                echo '<div class="graph-container">';
                foreach ($chunk_dates as $date) {
                    $kwh = $kwh_par_jour[$date];
                    $height_px = max(20, ($kwh / $max_kwh) * 120);
                    $label = date('d/m', strtotime($date));
                    echo '<div class="bar-wrapper">';
                    echo '<div class="bar" style="height:'.$height_px.'px;min-height:20px">';
                    echo '<div class="bar-value">'.round($kwh, 1).'</div>';
                    echo '</div>';
                    echo '<div class="bar-label">'.$label.'</div>';
                    echo '</div>';
                }
                echo '</div></div>';
                
                echo '<table><thead><tr>';
                foreach($cols_pdf as $c) echo '<th>'.$t['cols'][$c].'</th>';
                echo '</tr></thead><tbody>';
                foreach ($historique_fusionne as $l) {
                    if (!in_array($l['date'], $chunk_dates)) continue;
                    if ($l['kwh'] == 0 && $l['kwh_used'] == 0) continue;
                    echo '<tr>';
                    if(in_array('date', $cols_pdf)) echo '<td>'.date('d/m/Y', strtotime($l['date'])).'</td>';
                    if(in_array('kwh', $cols_pdf)) echo '<td>'.($l['kwh']>0?round($l['kwh'],2):'').'</td>';
                    if(in_array('kwh_used', $cols_pdf)) echo '<td>'.($l['kwh_used']>0?round($l['kwh_used'],2):'').'</td>';
                    if(in_array('cost', $cols_pdf)) echo '<td>'.($l['cost']>0?round($l['cost'],2):'').'</td>';
                    if(in_array('duree', $cols_pdf)) echo '<td>'.round($l['duree']).' min</td>';
                    if(in_array('km', $cols_pdf)) echo '<td>'.($l['km']>0?round($l['km'],1):'').'</td>';
                    if(in_array('ville', $cols_pdf)) echo '<td>'.htmlspecialchars($l['ville']).'</td>';
                    if(in_array('gps', $cols_pdf)) echo '<td>'.($l['gps'] != '0,0' && $l['gps'] != ',' ? $l['gps'] : '-').'</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
        } else {
            $cols_pdf = $v2l_mode ? ['date','kwh_used','duree','ville','gps'] : $cols;
            echo '<table><thead><tr>';
            foreach($cols_pdf as $c) echo '<th>'.$t['cols'][$c].'</th>';
            echo '</tr></thead><tbody>';
            foreach ($historique_fusionne as $l) {
                if ($v2l_mode && $l['kwh_used'] <= 0) continue;
                if (!$v2l_mode && $l['kwh'] == 0 && $l['kwh_used'] == 0) continue;
                echo '<tr>';
                if(in_array('date', $cols_pdf)) echo '<td>'.date('d/m/Y', strtotime($l['date'])).'</td>';
                if(in_array('kwh', $cols_pdf)) echo '<td>'.($l['kwh']>0?round($l['kwh'],2):'').'</td>';
                if(in_array('kwh_used', $cols_pdf)) echo '<td>'.($l['kwh_used']>0?round($l['kwh_used'],2):'').'</td>';
                if(in_array('cost', $cols_pdf)) echo '<td>'.($l['cost']>0?round($l['cost'],2):'').'</td>';
                if(in_array('duree', $cols_pdf)) echo '<td>'.round($l['duree']).' min</td>';
                if(in_array('km', $cols_pdf)) echo '<td>'.($l['km']>0?round($l['km'],1):'').'</td>';
                if(in_array('ville', $cols_pdf)) echo '<td>'.htmlspecialchars($l['ville']).'</td>';
                if(in_array('gps', $cols_pdf)) echo '<td>'.($l['gps'] != '0,0' && $l['gps'] != ',' ? $l['gps'] : '-').'</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        }
        
        echo '<div class="footer">TeslaMate - généré le '.date('d/m/Y H:i').'</div>';
        echo '</div></body></html>';
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TeslaCalcul</title>
    <style>
        body { font-family: -apple-system, sans-serif; background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); color: #fff; margin: 0; padding: 20px; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .container { background: rgba(255, 255, 255, 0.05); border-radius: 20px; padding: 40px; max-width: 500px; width: 100%; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3); border: 1px solid rgba(255, 255, 255, 0.1); position: relative; }
        .back-button { position: absolute; top: 20px; left: 20px; width: 40px; height: 40px; background: rgba(255, 255, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; }
        .back-button svg { width: 24px; height: 24px; stroke: #fff; stroke-width: 2; fill: none; }
        h1 { margin: 10px 0 30px 0; font-size: 28px; text-align: center; color: #dc2626; }
        label { display: block; font-size: 11px; color: #999; text-transform: uppercase; margin-bottom: 8px; margin-top: 15px; }
        input[type="date"], input[type="number"], select { width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.2); background: rgba(0,0,0,0.3); color: #fff; font-size: 16px; box-sizing: border-box; }
        .quick-periods { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 10px; }
        .btn-period { background: #8a2b2b; border: none; padding: 12px; border-radius: 10px; color: white; font-size: 14px; cursor: pointer; transition: background 0.2s; }
        .btn-period:hover { background: #dc2626; }
        .btn-period.active { background: #dc2626; font-weight: bold; border: 1px solid rgba(255,255,255,0.4); }
        .checkbox-group { background: rgba(0, 0, 0, 0.3); padding: 15px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1); margin-top: 10px; display: none; }
        .checkbox-item { display: flex; align-items: center; margin-bottom: 8px; font-size: 14px; cursor: pointer; }
        .checkbox-item input { margin-right: 12px; width: 18px; height: 18px; }
        .btn { width: 100%; padding: 14px; border: none; border-radius: 10px; color: white; font-weight: bold; cursor: pointer; margin-top: 20px; }
        .btn-calc { background: #16a34a; }
        .btn-mail { background: #2563eb; }
        .btn-pdf { background: #dc2626; }
        .btn-csv { background: #16a34a; }
        .btn-afficher { background: #f59e0b; }
        .result-box { background: rgba(0, 0, 0, 0.4); border-radius: 12px; padding: 20px; margin-top: 30px; border-left: 4px solid #16a34a; }
        .result-item { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 18px; }
        .result-value { font-weight: bold; color: #4ade80; }
        .alert { padding: 12px; border-radius: 8px; text-align: center; margin-bottom: 20px; background: rgba(34, 197, 94, 0.2); color: #4ade80; }
        #export_complet:checked ~ .checkbox-group { display: block; }
        .price-input-container { position: relative; }
        .currency-badge { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: #999; font-weight: bold; }
        .dates-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .switch-row { display: flex; align-items: center; justify-content: space-between; margin-top: 4px; }
        .switch { position: relative; display: inline-block; width: 52px; height: 28px; flex-shrink: 0; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; inset: 0; background: #4b5563; border-radius: 28px; transition: .3s; }
        .slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 4px; bottom: 4px; background: white; border-radius: 50%; transition: .3s; }
        input:checked + .slider { background: #16a34a; }
        input:checked + .slider:before { transform: translateX(24px); }
        .rapport-block { margin-top: 15px; background: rgba(0,0,0,0.3); padding: 12px 15px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1); }
        .adjust-block { margin-top: 15px; background: rgba(0,0,0,0.3); padding: 12px 15px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1); display: flex; align-items: center; gap: 15px; flex-wrap: wrap; }
        .adjust-block label { margin:0; }
        .adjust-block input { width: 100px; margin:0; }
        .adjust-block .btn-calc { width: auto; margin:0; padding: 8px 16px; }
    </style>
</head>
<body>
    <div class="container">
        <a href="tesla.php" class="back-button"><svg viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
        <h1><?php echo $t['title']; ?></h1>
        <?php if ($status_message): ?><div class="alert"><?php echo $status_message; ?></div><?php endif; ?>
        <form method="POST" id="mainForm">
            <label><?php echo $t['lbl_car']; ?></label>
            <select name="car_id"><?php foreach ($cars as $car): ?><option value="<?php echo $car['id']; ?>" <?php if($selected_car == $car['id']) echo 'selected'; ?>><?php echo htmlspecialchars($car['display_name']); ?></option><?php endforeach; ?></select>
            <label><?php echo $t['lbl_geo']; ?></label>
            <select name="geofence"><option value="TOUS"><?php echo $t['all_locations']; ?></option><?php foreach ($geofences as $geo): ?><option value="<?php echo $geo['id']; ?>" <?php if($selected_geo == $geo['id']) echo 'selected'; ?>><?php echo htmlspecialchars($geo['name']); ?></option><?php endforeach; ?></select>
            <label><?php echo $t['period']; ?></label>
            <div class="quick-periods">
                <button type="submit" name="quick_period" value="today" class="btn-period"><?php echo $t['period_today']; ?></button>
                <button type="submit" name="quick_period" value="week" class="btn-period"><?php echo $t['period_week']; ?></button>
                <button type="submit" name="quick_period" value="last_week" class="btn-period"><?php echo $t['period_last_week']; ?></button>
                <button type="submit" name="quick_period" value="month" class="btn-period"><?php echo $t['period_month']; ?></button>
                <button type="submit" name="quick_period" value="last_month" class="btn-period"><?php echo $t['period_last_month']; ?></button>
                <button type="submit" name="quick_period" value="year" class="btn-period"><?php echo $t['period_year']; ?></button>
                <button type="submit" name="quick_period" value="last_year" class="btn-period"><?php echo $t['period_last_year']; ?></button>
                <button type="button" class="btn-period active"><?php echo $t['period_custom']; ?></button>
            </div>
            <div class="dates-row">
                <div><label><?php echo $t['lbl_start']; ?></label><input type="date" name="date_debut" value="<?php echo $date_debut; ?>" required></div>
                <div><label><?php echo $t['lbl_end']; ?></label><input type="date" name="date_fin" value="<?php echo $date_fin; ?>" required></div>
            </div>
            <label id="lbl_price_field"><?php
                if ($selected_geo !== 'TOUS' && isset($prix_geo[(int)$selected_geo])) {
                    echo $t['lbl_price_geo'];
                    $kwh_price_display = $prix_geo[(int)$selected_geo];
                } else {
                    echo $t['lbl_price'];
                    $kwh_price_display = $kwh_price;
                }
            ?> (<?php echo $monnaie; ?>)</label>
            <div class="price-input-container">
                <input type="number" name="kwh_price" id="kwh_price_field" step="0.0001" value="<?php echo $kwh_price_display; ?>" placeholder="0.0000">
                <span class="currency-badge"><?php echo $monnaie; ?></span>
            </div>
            <?php
            $prix_geo_js = json_encode($prix_geo);
            $kwh_price_general = $kwh_price;
            ?>
            <!-- Bloc pourcentage d'ajustement sans facteur et bouton vert -->
            <div class="adjust-block">
                <label><?php echo $t['lbl_adjust']; ?></label>
                <input type="number" name="adjust_percent" id="adjust_percent" step="0.1" value="<?php echo $adjust_percent; ?>" style="width:100px;">
                <button type="submit" name="save_adjust" class="btn btn-calc"><?php echo $t['btn_valider']; ?></button>
            </div>
            <div style="margin-top:20px;">
                <input type="checkbox" id="export_complet" name="export_complet" <?php if($export_complet) echo 'checked'; ?>>
                <label for="export_complet" style="display:inline; text-transform:none; color:white; font-size:14px; margin-left:10px;"><?php echo $t['lbl_details']; ?></label>
                <div class="checkbox-group">
                    <label class="checkbox-item"><input type="checkbox" id="toggleAll" checked> <span><?php echo $t['lbl_select_all']; ?></span></label>
                    <?php foreach($t['cols'] as $key => $label): ?>
                    <label class="checkbox-item"><input type="checkbox" name="cols[]" value="<?php echo $key; ?>" class="col-check" <?php if(in_array($key, $cols)) echo 'checked'; ?>> <span><?php echo $label; ?></span></label>
                    <?php endforeach; ?>
                </div>
            </div>
            <div style="margin-top:15px; background: rgba(0,0,0,0.3); padding: 12px 15px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1);">
                <input type="checkbox" id="v2l_mode" name="v2l_mode" <?php if($v2l_mode) echo 'checked'; ?>>
                <label for="v2l_mode" style="display:inline; text-transform:none; color:white; font-size:14px; margin-left:10px;"><?php echo $t['lbl_v2l']; ?></label>
            </div>
            <?php if (!empty($config['NOTIFICATION_EMAIL'])): ?>
            <div class="rapport-block">
                <div class="switch-row">
                    <label style="display:inline; text-transform:none; color:white; font-size:14px; margin:0;">
                        <?php echo $t['lbl_rapport']; ?>
                        <span style="margin-left:8px; font-size:12px; color:<?php echo $config['RAPPORT_HEBDO']==='True' ? '#4ade80' : '#9ca3af'; ?>;">
                            (<?php echo $config['RAPPORT_HEBDO']==='True' ? $t['rapport_on'] : $t['rapport_off']; ?>)
                        </span>
                    </label>
                    <a href="?toggle_rapport=1" class="switch" style="text-decoration:none;">
                        <input type="checkbox" onclick="window.location='?toggle_rapport=1'; return false;" <?php echo $config['RAPPORT_HEBDO']==='True' ? 'checked' : ''; ?>>
                        <span class="slider"></span>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <button type="submit" name="calculer" class="btn btn-calc"><?php echo $t['btn_valider']; ?></button>
            <?php if (isset($_POST['calculer']) || isset($_POST['quick_period'])): ?>
                <?php if ($resultats['total_kwh_added'] > 0 || $resultats['total_kwh_used'] > 0 || $resultats['nb'] > 0): ?>
                    <div class="result-box">
                        <?php if (!$v2l_mode): ?>
                        <div class="result-item"><span><?php echo $t['res_dist']; ?></span><span class="result-value"><?php echo $resultats['total_km']; ?> km</span></div>
                        <?php endif; ?>
                        <div class="result-item"><span><?php echo $t['res_count']; ?></span><span class="result-value"><?php echo $resultats['nb']; ?></span></div>
                        <?php if (!$v2l_mode): ?>
                        <div class="result-item"><span><?php echo $t['res_energy_added']; ?></span><span class="result-value"><?php echo $resultats['total_kwh_added']; ?> kWh</span></div>
                        <?php endif; ?>
                        <div class="result-item"><span><?php echo $t['res_energy_used']; ?></span><span class="result-value"><?php echo $resultats['total_kwh_used']; ?> kWh</span></div>
                        <?php if (!$v2l_mode): ?>
                        <div class="result-item"><span><?php echo $t['res_cost']; ?></span><span class="result-value"><?php echo $resultats['total_cost']; ?> <?php echo $monnaie; ?></span></div>
                        <div class="result-item"><span><?php echo $t['res_adjust']; ?></span><span class="result-value"><?php echo $adjust_percent; ?> %</span></div>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($config['NOTIFICATION_EMAIL'])): ?><button type="submit" name="envoyer_email" class="btn btn-mail"><?php echo $t['btn_email']; ?></button><?php endif; ?>
                    <button type="submit" name="telecharger_pdf" class="btn btn-pdf" formtarget="_blank"><?php echo $t['btn_pdf']; ?></button>
                    <button type="submit" name="telecharger_csv" class="btn btn-csv"><?php echo $t['btn_csv']; ?></button>
                    <button type="submit" name="afficher" class="btn btn-afficher" formtarget="_blank"><?php echo $t['btn_afficher']; ?></button>
                <?php else: ?>
                    <div class="alert" style="background: rgba(220, 38, 38, 0.2); color: #fca5a5; margin-top: 20px;">
                        <?php echo $t['no_data']; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </form>
    </div>
    <script>
        const toggleAll = document.getElementById('toggleAll');
        const checkboxes = document.querySelectorAll('.col-check');
        if(toggleAll) { toggleAll.addEventListener('change', function() { checkboxes.forEach(cb => { cb.checked = toggleAll.checked; }); }); }

        const prixGeo     = <?= json_encode($prix_geo ?? []) ?>;
        const prixGeneral = <?= floatval($kwh_price_general ?? $kwh_price ?? 0) ?>;
        const lblPrice    = <?= json_encode($t['lbl_price'] . ' (' . $monnaie . ')') ?>;
        const lblPriceGeo = <?= json_encode($t['lbl_price_geo'] . ' (' . $monnaie . ')') ?>;

        const geoSelect   = document.querySelector('select[name="geofence"]');
        const priceInput  = document.getElementById('kwh_price_field');
        const priceLabel  = document.getElementById('lbl_price_field');

        if (geoSelect && priceInput) {
            geoSelect.addEventListener('change', function() {
                const geoId = parseInt(this.value);
                if (geoId && prixGeo[geoId] !== undefined) {
                    priceInput.value = prixGeo[geoId].toFixed(4);
                    if (priceLabel) priceLabel.textContent = lblPriceGeo;
                } else {
                    priceInput.value = prixGeneral > 0 ? prixGeneral.toFixed(4) : '';
                    if (priceLabel) priceLabel.textContent = lblPrice;
                }
            });
        }

        (function() {
            const testInput = document.createElement('input');
            testInput.setAttribute('type', 'date');
            testInput.setAttribute('value', 'not-a-date');
            const supportsDate = (testInput.value !== 'not-a-date');
            if (supportsDate) return;

            const style = document.createElement('style');
            style.textContent = `
                .date-numpad-wrap { display:inline-block; vertical-align:top; }
                .date-numpad-display { font-size:18px; letter-spacing:3px; color:#f59e0b; text-align:center; padding:4px 0 8px 0; }
                .date-numpad-grid { display:grid; grid-template-columns:repeat(3,42px); gap:4px; }
                .date-numpad-grid button { width:42px; height:42px; background:#1a1a1a; border:1px solid rgba(255,255,255,0.2); border-radius:8px; color:#fff; font-size:15px; cursor:pointer; }
                .date-numpad-grid button.ok { background:#dc2626; border:none; font-size:11px; font-weight:bold; }
                .date-numpad-grid button.cl { background:rgba(255,255,255,0.1); }
                .date-numpad-hint { font-size:10px; color:#666; text-align:center; margin-top:3px; }
                .tsl-list-wrap { border:1px solid rgba(255,255,255,0.2); border-radius:10px; overflow:hidden; margin-top:4px; }
                .tsl-list-item { padding:11px 14px; font-size:15px; color:#fff; border-bottom:1px solid rgba(255,255,255,0.08); cursor:pointer; }
                .tsl-list-item.selected { background:#dc2626; }
                .tsl-list-scroll { max-height:160px; overflow-y:scroll; }
            `;
            document.head.appendChild(style);

            function makeNumpad(input) {
                const name    = input.getAttribute('name');
                const initVal = input.value || '';
                const parts   = initVal.split('-');
                let digits = parts.length === 3
                    ? parts[2] + parts[1] + parts[0]
                    : '';

                const hidden = document.createElement('input');
                hidden.type = 'hidden'; hidden.name = name; hidden.value = initVal;

                const display = document.createElement('div');
                display.className = 'date-numpad-display';

                function updateDisplay() {
                    const s = digits.padEnd(8,'_');
                    display.textContent = s.slice(0,2)+'/'+s.slice(2,4)+'/'+s.slice(4,8);
                }
                updateDisplay();

                function pressDigit(n) {
                    if (digits.length < 8) { digits += n; updateDisplay(); }
                }
                function clearDigit() { digits = digits.slice(0,-1); updateDisplay(); }
                function confirm() {
                    if (digits.length !== 8) return;
                    const dd=digits.slice(0,2), mm=digits.slice(2,4), yyyy=digits.slice(4,8);
                    hidden.value = `${yyyy}-${mm}-${dd}`;
                }

                const grid = document.createElement('div');
                grid.className = 'date-numpad-grid';
                [1,2,3,4,5,6,7,8,9,'C',0,'OK'].forEach(v => {
                    const btn = document.createElement('button');
                    btn.type = 'button'; btn.textContent = v;
                    if (v==='OK') { btn.className='ok'; btn.addEventListener('click', confirm); }
                    else if (v==='C') { btn.className='cl'; btn.addEventListener('click', clearDigit); }
                    else btn.addEventListener('click', () => pressDigit(String(v)));
                    grid.appendChild(btn);
                });

                const hint = document.createElement('div');
                hint.className = 'date-numpad-hint'; hint.textContent = 'JJ MM AAAA';

                const wrap = document.createElement('div');
                wrap.className = 'date-numpad-wrap';
                wrap.appendChild(display); wrap.appendChild(grid);
                wrap.appendChild(hint); wrap.appendChild(hidden);

                input.parentNode.insertBefore(wrap, input);
                input.parentNode.removeChild(input);
            }
            document.querySelectorAll('input[type=date]').forEach(makeNumpad);

            function makeScrollList(sel) {
                const name    = sel.getAttribute('name');
                const options = Array.from(sel.options);
                let selectedVal = sel.value || options[0]?.value || '';

                const hidden = document.createElement('input');
                hidden.type = 'hidden'; hidden.name = name; hidden.value = selectedVal;

                const scrollDiv = document.createElement('div');
                scrollDiv.className = 'tsl-list-scroll';

                options.forEach(opt => {
                    const item = document.createElement('div');
                    item.className = 'tsl-list-item' + (opt.value === selectedVal ? ' selected' : '');
                    item.textContent = opt.text;
                    item.dataset.value = opt.value;
                    item.addEventListener('click', function() {
                        scrollDiv.querySelectorAll('.tsl-list-item').forEach(i => i.classList.remove('selected'));
                        item.classList.add('selected');
                        selectedVal = opt.value;
                        hidden.value = opt.value;
                        if (name === 'geofence') {
                            const geoId = parseInt(opt.value);
                            const priceInput = document.getElementById('kwh_price_field');
                            const priceLabel = document.getElementById('lbl_price_field');
                            if (priceInput) {
                                if (geoId && prixGeo[geoId] !== undefined) {
                                    priceInput.value = prixGeo[geoId].toFixed(4);
                                    if (priceLabel) priceLabel.textContent = lblPriceGeo;
                                } else {
                                    priceInput.value = prixGeneral > 0 ? prixGeneral.toFixed(4) : '';
                                    if (priceLabel) priceLabel.textContent = lblPrice;
                                }
                            }
                        }
                    });
                    scrollDiv.appendChild(item);
                });

                const wrap = document.createElement('div');
                wrap.className = 'tsl-list-wrap';
                wrap.appendChild(scrollDiv);

                sel.parentNode.insertBefore(wrap, sel);
                sel.parentNode.insertBefore(hidden, sel);
                sel.parentNode.removeChild(sel);
            }

            const selCar = document.querySelector('select[name="car_id"]');
            const selGeo = document.querySelector('select[name="geofence"]');
            if (selCar) makeScrollList(selCar);
            if (selGeo) makeScrollList(selGeo);
        })();
    </script>
</body>
</html>

