<?php
// --- 1. CONFIGURATION & LANGUE ---
$file = "/var/www/html/cgi-bin/setup";

function read_setup($file) {
    $cfg = [];
    if (file_exists($file)) {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos($line, '=') !== false) {
                list($key, $value) = explode('=', $line, 2);
                $cfg[strtoupper(trim($key))] = trim($value);
            }
        }
    }
    return $cfg;
}

$config = read_setup($file);
$lang = (isset($config['LANGUAGE']) && strtoupper($config['LANGUAGE']) === 'EN') ? 'en' : 'fr';

// --- 2. TRADUCTIONS ---
$texts = [
    'fr' => [
        'title' => 'Parrainage Tesla - TeslaMate Mail',
        'header' => 'Parrainage Tesla',
        'like_project' => 'Vous aimez ce projet ?',
        'msg_1' => "Si cette interface TeslaMate Mail vous plaît et qu'elle vous facilite la vie au quotidien, vous pouvez me soutenir d'une manière simple et avantageuse pour vous !",
        'msg_2' => "Si vous envisagez d'acheter un véhicule Tesla ou des produits Tesla (Powerwall, accessoires...), n'hésitez pas à utiliser mon lien de parrainage. Cela ne vous coûte rien et nous permet tous les deux de bénéficier d'avantages !",
        'adv_title' => 'Avantages du parrainage',
        'adv_you' => 'Pour vous :',
        'adv_you_desc' => 'Crédits ou avantages sur votre achat Tesla selon les offres en cours',
        'adv_me' => 'Pour moi :',
        'adv_me_desc' => "Une petite récompense qui m'encourage à continuer le développement",
        'adv_win' => 'Win-win :',
        'adv_win_desc' => 'Vous ne payez pas plus cher, et vous soutenez ce projet !',
        'link_title' => 'Mon lien de parrainage',
        'link_desc' => 'Cliquez sur le bouton ci-dessous pour accéder directement au site Tesla avec mon code de parrainage :',
        'btn_tesla' => 'Accéder au site Tesla',
        'thanks_title' => 'Merci !',
        'thanks_msg' => "Que vous utilisiez ou non le lien de parrainage, merci d'utiliser TeslaMate Mail ! Votre soutien, sous quelque forme que ce soit, est grandement apprécié et me motive à continuer d'améliorer cette interface.",
        'legal_note' => 'Note :',
        'legal_desc' => "Les avantages du programme de parrainage Tesla peuvent varier selon votre pays et les offres en cours. Consultez le site officiel Tesla pour connaître les conditions actuelles. Ce projet n'est pas affilié à Tesla, Inc.",
        'footer_credits' => 'Crédits'
    ],
    'en' => [
        'title' => 'Tesla Referral - TeslaMate Mail',
        'header' => 'Tesla Referral',
        'like_project' => 'Do you like this project?',
        'msg_1' => "If you enjoy this TeslaMate Mail interface and it makes your daily life easier, you can support me in a simple and mutually beneficial way!",
        'msg_2' => "If you are considering buying a Tesla vehicle or Tesla products (Powerwall, accessories...), feel free to use my referral link. It costs you nothing and allows both of us to earn rewards!",
        'adv_title' => 'Referral Benefits',
        'adv_you' => 'For you:',
        'adv_you_desc' => 'Credits or benefits on your Tesla purchase depending on current offers',
        'adv_me' => 'For me:',
        'adv_me_desc' => 'A small reward that encourages me to continue development',
        'adv_win' => 'Win-win:',
        'adv_win_desc' => "You don't pay more, and you support this project!",
        'link_title' => 'My Referral Link',
        'link_desc' => 'Click the button below to access the Tesla website directly with my referral code:',
        'btn_tesla' => 'Access Tesla Website',
        'thanks_title' => 'Thank you!',
        'thanks_msg' => "Whether or not you use the referral link, thank you for using TeslaMate Mail! Your support, in any form, is greatly appreciated and motivates me to keep improving this interface.",
        'legal_note' => 'Note:',
        'legal_desc' => "Tesla referral program benefits may vary by country and current offers. Check the official Tesla website for current terms. This project is not affiliated with Tesla, Inc.",
        'footer_credits' => 'Credits'
    ]
];

$t = $texts[$lang];
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#dc2626">
  <title><?= $t['title'] ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white min-h-screen">
  
  <div class="min-h-screen pb-20">
    <div class="bg-gray-800/90 backdrop-blur-sm border-b border-gray-700 p-4 sticky top-0 z-10">
      <div class="max-w-2xl mx-auto">
        <div class="flex items-center justify-between">
          <a href="tesla.php" class="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors">
            <svg class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
          </a>
          <h1 class="text-2xl font-bold text-white tracking-tight"><?= $t['header'] ?></h1>
          <div class="w-9"></div>
        </div>
      </div>
    </div>

    <div class="px-4 pt-6 space-y-6 max-w-2xl mx-auto">
      
      <div class="flex justify-center">
        <a href="https://ts.la/eric558841" target="_blank" class="block">
          <img src="logoparrain.png" alt="Tesla Referral" class="rounded-2xl shadow-2xl hover:scale-105 transition-transform duration-300 max-w-full h-auto">
        </a>
      </div>

      <div class="bg-gradient-to-br from-red-900/30 to-gray-900 rounded-2xl p-6 border border-red-700/30 shadow-xl">
        <div class="flex items-center gap-3 mb-4">
          <svg class="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
          </svg>
          <h2 class="text-2xl font-bold text-white"><?= $t['like_project'] ?></h2>
        </div>
        <p class="text-gray-300 text-base leading-relaxed mb-4">
          <?= $t['msg_1'] ?>
        </p>
        <p class="text-gray-300 text-base leading-relaxed">
          <?= $t['msg_2'] ?>
        </p>
      </div>

      <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-6 border border-gray-700 shadow-xl">
        <div class="flex items-center gap-3 mb-4">
          <svg class="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
          <h2 class="text-xl font-bold text-white"><?= $t['adv_title'] ?></h2>
        </div>
        <ul class="space-y-3 text-gray-300 text-sm">
          <li class="flex items-start gap-3">
            <svg class="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span><strong class="text-white"><?= $t['adv_you'] ?></strong> <?= $t['adv_you_desc'] ?></span>
          </li>
          <li class="flex items-start gap-3">
            <svg class="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span><strong class="text-white"><?= $t['adv_me'] ?></strong> <?= $t['adv_me_desc'] ?></span>
          </li>
          <li class="flex items-start gap-3">
            <svg class="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span><strong class="text-white"><?= $t['adv_win'] ?></strong> <?= $t['adv_win_desc'] ?></span>
          </li>
        </ul>
      </div>

      <div class="bg-gradient-to-br from-blue-900/30 to-gray-900 rounded-2xl p-6 border border-blue-700/30 shadow-xl">
        <div class="flex items-center gap-3 mb-4">
          <svg class="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path>
          </svg>
          <h2 class="text-xl font-bold text-white"><?= $t['link_title'] ?></h2>
        </div>
        <p class="text-gray-300 text-sm mb-4">
          <?= $t['link_desc'] ?>
        </p>
        <a href="https://ts.la/eric558841" target="_blank" class="block w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white font-bold text-center py-4 px-6 rounded-xl shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-2xl">
          <div class="flex items-center justify-center gap-3">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
            </svg>
            <span class="text-lg"><?= $t['btn_tesla'] ?></span>
          </div>
          <span class="block text-sm mt-2 opacity-90">https://ts.la/eric558841</span>
        </a>
      </div>

      <div class="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-6 border border-gray-700 shadow-xl">
        <div class="flex items-center gap-3 mb-4">
          <svg class="w-8 h-8 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
          </svg>
          <h2 class="text-xl font-bold text-white"><?= $t['thanks_title'] ?></h2>
        </div>
        <p class="text-gray-300 text-sm leading-relaxed">
          <?= $t['thanks_msg'] ?>
        </p>
        <p class="text-gray-400 text-xs mt-4 italic">
          — Eric B. / Monwifi.fr
        </p>
      </div>

      <div class="bg-gray-800/50 rounded-xl p-4 border border-gray-700">
        <p class="text-gray-500 text-xs leading-relaxed">
          <strong class="text-gray-400"><?= $t['legal_note'] ?></strong> <?= $t['legal_desc'] ?>
        </p>
      </div>

      <div class="border-t border-gray-700 mt-8 pt-6">
        <div class="flex justify-center items-center gap-6 text-xs text-gray-500">
          <a href="credits.php" class="hover:text-white transition-colors"><?= $t['footer_credits'] ?></a>
          <span class="text-gray-700">•</span>
          <a href="parrain.php" class="text-white"><?= $t['header'] ?></a>
          <span class="text-gray-700">•</span>
          <span>Version 1.2 / 20/01/2026</span>
        </div>
      </div>

    </div>
  </div>

</body>
</html>
