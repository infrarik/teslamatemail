#!/usr/bin/env php
<?php
// =============================================================
// tesla_rapport_hebdo.php — Rapport hebdomadaire TeslaMate
// Appelé par cron chaque lundi à 4h :
//   0 4 * * 1 php /var/www/html/tesla_rapport_hebdo.php >> /var/log/tesla_rapport.log 2>&1
// =============================================================

// Forcer le fuseau horaire France
date_default_timezone_set('Europe/Paris');

$script_dir = __DIR__;

// --- 1. LECTURE DU SETUP (même fichier que teslacalcul.php) ---
$setup_file = $script_dir . '/cgi-bin/setup';
$config = [
    'NOTIFICATION_EMAIL' => '',
    'DOCKER_PATH'        => '',
    'LANGUAGE'           => 'fr',
    'CURRENCY'           => 'EUR',
    'KWH_PRICE'          => '0',
    'RAPPORT_HEBDO'      => 'False',
];

if (file_exists($setup_file)) {
    foreach (file($setup_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        $parts = explode('=', $line, 2);
        if (count($parts) === 2)
            $config[strtoupper(trim($parts[0]))] = trim($parts[1]);
    }
}

// Vérification flag rapport_hebdo
if (strtolower($config['RAPPORT_HEBDO'] ?? 'false') !== 'true') {
    echo date('Y-m-d H:i:s') . " [SKIP] rapport_hebdo désactivé dans cgi-bin/setup\n";
    exit(0);
}

// Vérification email
if (empty($config['NOTIFICATION_EMAIL'])) {
    echo date('Y-m-d H:i:s') . " [SKIP] NOTIFICATION_EMAIL non configuré dans cgi-bin/setup\n";
    exit(0);
}

$lang    = (strtolower($config['LANGUAGE']) === 'en') ? 'en' : 'fr';
$monnaie = $config['CURRENCY'] ?? 'EUR';

// --- 2. DICTIONNAIRE (copie légère de teslacalcul.php) ---
$texts = [
    'fr' => [
        'report_title'        => "Rapport TeslaMate",
        'period'              => "Période",
        'dist_label'          => "Distance",
        'charges_label'       => "Charges",
        'energy_added_label'  => "Énergie ajoutée",
        'energy_used_label'   => "Énergie consommée",
        'cost_label'          => "Coût",
        'no_data'             => "Pas de données disponibles",
        'sent_to'             => "Envoyé à",
        'cols'                => ['date'=>'Date','kwh'=>'kWh ajoutés','kwh_used'=>'kWh consommés','cost'=>'Coût','duree'=>'Durée de charge','km'=>'km parcourus','ville'=>'Ville','gps'=>'GPS'],
    ],
    'en' => [
        'report_title'        => "TeslaMate Report",
        'period'              => "Period",
        'dist_label'          => "Distance",
        'charges_label'       => "Charges",
        'energy_added_label'  => "Energy added",
        'energy_used_label'   => "Energy used",
        'cost_label'          => "Cost",
        'no_data'             => "No data available",
        'sent_to'             => "Sent to",
        'cols'                => ['date'=>'Date','kwh'=>'kWh added','kwh_used'=>'kWh used','cost'=>'Cost','duree'=>'Duration','km'=>'km driven','ville'=>'City','gps'=>'GPS'],
    ],
];
$t = $texts[$lang];

// --- 3. IDENTIFIANTS DB ---
$db_user = $db_pass = $db_name = '';
if (!empty($config['DOCKER_PATH']) && file_exists($config['DOCKER_PATH'])) {
    $dc = file_get_contents($config['DOCKER_PATH']);
    if (preg_match('/POSTGRES_USER[:=]\s*(\S+)/',     $dc, $m)) $db_user = str_replace(['"',"'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_PASSWORD[:=]\s*(\S+)/', $dc, $m)) $db_pass = str_replace(['"',"'"], '', trim($m[1]));
    if (preg_match('/POSTGRES_DB[:=]\s*(\S+)/',       $dc, $m)) $db_name = str_replace(['"',"'"], '', trim($m[1]));
}

// --- 4. CONNEXION DB ---
try {
    $pdo = new PDO("pgsql:host=localhost;port=5432;dbname=$db_name", $db_user, $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    echo date('Y-m-d H:i:s') . " [ERROR] Connexion DB : " . $e->getMessage() . "\n";
    exit(1);
}

// --- 5. VÉHICULES ---
$cars = $pdo->query("SELECT id, COALESCE(name, model) as display_name FROM cars ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
if (empty($cars)) {
    echo date('Y-m-d H:i:s') . " [SKIP] Aucun véhicule trouvé\n";
    exit(0);
}

// --- 6. PÉRIODE : semaine précédente lundi→dimanche ---
$rap_debut = date('Y-m-d', strtotime('monday last week'));
$rap_fin   = date('Y-m-d', strtotime('sunday last week'));

echo date('Y-m-d H:i:s') . " [INFO] Rapport semaine $rap_debut → $rap_fin\n";

// --- 7. CALCUL (pour chaque véhicule) ---
foreach ($cars as $car) {
    $selected_car     = $car['id'];
    $car_name_display = $car['display_name'];
    $v2l_mode         = 0;
    $kwh_price        = floatval($config['KWH_PRICE'] ?? 0);
    $cols             = ['date', 'kwh', 'kwh_used', 'cost', 'duree', 'km', 'ville', 'gps'];
    $selected_geo     = 'TOUS';

    $resultats          = ['nb' => 0, 'total_kwh_added' => 0, 'total_kwh_used' => 0, 'total_km' => 0, 'total_cost' => 0];
    $historique_fusionne = [];

    try {
        $params = ['debut' => $rap_debut, 'fin' => $rap_fin, 'car_id' => $selected_car];
        $where_charge = " WHERE cp.car_id = :car_id AND cp.start_date >= :debut AND cp.start_date < (:fin::date + interval '1 day') AND cp.charge_energy_added > 0";

        $sql_rec = "SELECT cp.id, cp.start_date, cp.start_date::date as date_f,
                           cp.charge_energy_added as kwh, cp.charge_energy_used as kwh_used,
                           EXTRACT(EPOCH FROM (cp.end_date - cp.start_date))/60 as duree,
                           p.latitude as lat, p.longitude as lon, a.city as ville
                    FROM charging_processes cp
                    LEFT JOIN addresses a ON cp.address_id = a.id
                    LEFT JOIN positions p ON cp.position_id = p.id
                    $where_charge ORDER BY cp.start_date ASC";
        $stmt = $pdo->prepare($sql_rec);
        $stmt->execute($params);
        $charges = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $sql_tra = "SELECT start_date::date as date_f, SUM(distance) as km,
                           SUM(EXTRACT(EPOCH FROM (end_date - start_date))/60) as duree
                    FROM drives WHERE car_id = :car_id
                    AND start_date >= :debut AND start_date < (:fin::date + interval '1 day')
                    AND distance > 0.1 GROUP BY start_date::date";
        $stmt2 = $pdo->prepare($sql_tra);
        $stmt2->execute(['car_id' => $selected_car, 'debut' => $rap_debut, 'fin' => $rap_fin]);
        $trajets_par_jour = $stmt2->fetchAll(PDO::FETCH_ASSOC);

        $temp_hist = [];
        $total_kwh_added = $total_kwh_used = $total_km = $compteur = 0;

        foreach ($charges as $c) {
            $key = 'charge_' . $c['id'];
            $cost = $c['kwh_used'] * $kwh_price;
            $temp_hist[$key] = ['date' => $c['date_f'], 'start_date' => $c['start_date'],
                'kwh' => $c['kwh'], 'kwh_used' => $c['kwh_used'], 'cost' => $cost,
                'duree' => $c['duree'], 'km' => 0, 'ville' => $c['ville'],
                'gps' => round($c['lat'],5).','.round($c['lon'],5)];
            $total_kwh_added += $c['kwh'];
            $total_kwh_used  += $c['kwh_used'];
            if ($c['kwh'] > 0) $compteur++;
        }
        $km_par_date_attribue = [];
        foreach ($trajets_par_jour as $trajet) {
            $d = $trajet['date_f'];
            $total_km += $trajet['km'];
            if (!isset($km_par_date_attribue[$d])) {
                foreach ($temp_hist as $key => &$entry) {
                    if ($entry['date'] === $d) { $entry['km'] += $trajet['km']; $km_par_date_attribue[$d] = true; break; }
                }
                unset($entry);
                if (!isset($km_par_date_attribue[$d])) {
                    $temp_hist['drive_'.$d] = ['date' => $d, 'start_date' => $d, 'kwh' => 0, 'kwh_used' => 0,
                        'cost' => 0, 'duree' => $trajet['duree'], 'km' => $trajet['km'], 'ville' => '', 'gps' => ''];
                    $km_par_date_attribue[$d] = true;
                }
            }
        }
        uasort($temp_hist, fn($a,$b) => strcmp($a['start_date'], $b['start_date']));
        $historique_fusionne = $temp_hist;
        $resultats = [
            'nb'               => $compteur,
            'total_kwh_added'  => round($total_kwh_added, 2),
            'total_kwh_used'   => round($total_kwh_used, 2),
            'total_km'         => round($total_km, 1),
            'total_cost'       => round($total_kwh_used * $kwh_price, 2),
            'conso_100'        => ($total_km > 0) ? round($total_kwh_used / $total_km * 100, 1) : 0,
        ];

    } catch (Exception $e) {
        echo date('Y-m-d H:i:s') . " [ERROR] Calcul véhicule $selected_car : " . $e->getMessage() . "\n";
        continue;
    }

    // --- 8. ENVOI EMAIL HTML + PDF en pièce jointe ---
    require_once $script_dir . '/fn_mail_rapport.php';

    $to      = $config['NOTIFICATION_EMAIL'];
    $subject = $t['report_title'] . " — $car_name_display — $rap_debut / $rap_fin";

    if (fn_envoyer_rapport($to, $subject, $script_dir,
        $rap_debut, $rap_fin, $t, $monnaie, $car_name_display,
        $resultats, $historique_fusionne, $v2l_mode, $cols, $lang)) {
        echo date('Y-m-d H:i:s') . " [OK] Rapport '$car_name_display' envoyé à $to\n";
    } else {
        echo date('Y-m-d H:i:s') . " [ERROR] Échec envoi mail pour '$car_name_display'\n";
    }
}

echo date('Y-m-d H:i:s') . " [DONE]\n";
