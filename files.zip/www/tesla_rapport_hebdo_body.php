<?php
// --- tesla_rapport_hebdo_body.php ---
// Gabarit HTML du rapport. Attend les variables suivantes déjà définies :
//   $rap_debut, $rap_fin, $t, $monnaie, $car_name_display,
//   $resultats, $historique_fusionne, $v2l_mode, $cols, $lang
$display_start = ($lang === 'fr') ? date('d/m/Y', strtotime($rap_debut)) : $rap_debut;
$display_end   = ($lang === 'fr') ? date('d/m/Y', strtotime($rap_fin))   : $rap_fin;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  body    { font-family: Arial, sans-serif; background: #f5f5f5; color: #222; padding: 20px; }
  .wrap   { max-width: 700px; margin: auto; background: #fff; border-radius: 10px;
            box-shadow: 0 2px 12px rgba(0,0,0,.12); overflow: hidden; }
  .hdr    { background: #dc2626; color: #fff; padding: 24px 30px; text-align: center; }
  .hdr h1 { margin: 0 0 6px; font-size: 22px; }
  .hdr p  { margin: 0; font-size: 13px; opacity: .85; }
  .summary{ display: flex; flex-wrap: wrap; gap: 0; }
  .kpi    { flex: 1 1 140px; padding: 18px 20px; border-right: 1px solid #eee;
            border-bottom: 1px solid #eee; text-align: center; }
  .kpi .val { font-size: 24px; font-weight: 700; color: #dc2626; }
  .kpi .lbl { font-size: 11px; color: #777; text-transform: uppercase; margin-top: 4px; }
  table   { width: 100%; border-collapse: collapse; font-size: 13px; }
  th      { background: #dc2626; color: #fff; padding: 9px 10px; text-align: center; }
  td      { padding: 8px 10px; border-bottom: 1px solid #eee; text-align: center; }
  tr:nth-child(even) td { background: #fafafa; }
  .footer { padding: 14px 20px; font-size: 11px; color: #aaa; text-align: center; }
  .no-data{ padding: 30px; text-align: center; color: #999; font-style: italic; }
</style>
</head>
<body>
<div class="wrap">
  <div class="hdr">
    <h1><?= htmlspecialchars($t['report_title']) ?> — <?= htmlspecialchars($car_name_display) ?></h1>
    <p><?= $t['period'] ?> : <?= $display_start ?> → <?= $display_end ?></p>
  </div>

  <?php if ($resultats['nb'] > 0 || $resultats['total_km'] > 0): ?>
  <div class="summary">
    <?php if (!$v2l_mode): ?>
    <div class="kpi"><div class="val"><?= $resultats['total_km'] ?> km</div><div class="lbl"><?= $t['dist_label'] ?></div></div>
    <?php endif; ?>
    <div class="kpi"><div class="val"><?= $resultats['nb'] ?></div><div class="lbl"><?= $t['charges_label'] ?></div></div>
    <?php if (!$v2l_mode): ?>
    <div class="kpi"><div class="val"><?= $resultats['total_kwh_added'] ?> kWh</div><div class="lbl"><?= $t['energy_added_label'] ?></div></div>
    <?php endif; ?>
    <div class="kpi"><div class="val"><?= $resultats['total_kwh_used'] ?> kWh</div><div class="lbl"><?= $t['energy_used_label'] ?></div></div>
    <?php if (!$v2l_mode): ?>
    <div class="kpi"><div class="val"><?= $resultats['total_cost'] ?> <?= $monnaie ?></div><div class="lbl"><?= $t['cost_label'] ?></div></div>
    <?php endif; ?>
  </div>

  <table>
    <tr>
      <?php $cols_pdf = $v2l_mode ? ['date','kwh_used','duree','ville','gps'] : $cols; ?>
      <?php foreach ($cols_pdf as $c): ?><th><?= $t['cols'][$c] ?></th><?php endforeach; ?>
    </tr>
    <?php foreach ($historique_fusionne as $l): ?>
      <?php if ($v2l_mode && $l['kwh_used'] <= 0) continue; ?>
      <?php if (!$v2l_mode && $l['kwh'] == 0 && $l['kwh_used'] == 0) continue; ?>
      <tr>
        <?php if (in_array('date',     $cols_pdf)) echo '<td>'.date('d/m/Y', strtotime($l['date'])).'</td>'; ?>
        <?php if (in_array('kwh',      $cols_pdf)) echo '<td>'.($l['kwh']>0 ? round($l['kwh'],2) : '').'</td>'; ?>
        <?php if (in_array('kwh_used', $cols_pdf)) echo '<td>'.($l['kwh_used']>0 ? round($l['kwh_used'],2) : '').'</td>'; ?>
        <?php if (in_array('cost',     $cols_pdf)) echo '<td>'.($l['cost']>0 ? round($l['cost'],2) : '').'</td>'; ?>
        <?php if (in_array('duree',    $cols_pdf)) echo '<td>'.round($l['duree']).' min</td>'; ?>
        <?php if (in_array('km',       $cols_pdf)) echo '<td>'.($l['km']>0 ? round($l['km'],1) : '').'</td>'; ?>
        <?php if (in_array('ville',    $cols_pdf)) echo '<td>'.htmlspecialchars($l['ville']).'</td>'; ?>
        <?php if (in_array('gps',      $cols_pdf)) echo '<td>'.($l['gps'] != '0,0' ? $l['gps'] : '-').'</td>'; ?>
      </tr>
    <?php endforeach; ?>
  </table>
  <?php else: ?>
  <div class="no-data"><?= $t['no_data'] ?></div>
  <?php endif; ?>

  <div class="footer">TeslaMate — généré le <?= date('d/m/Y H:i') ?></div>
</div>
</body>
</html>
