<?php
session_start();

// --- CONFIGURATION ---
$setupFile = __DIR__ . '/cgi-bin/setup';
$accessCode = null;

if (file_exists($setupFile)) {
    $lines = file($setupFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, 'code=') === 0) {
            $parts = explode('=', $line, 2);
            if (isset($parts[1]) && trim($parts[1]) !== '') {
                $accessCode = trim($parts[1]);
            }
            break;
        }
    }
}

// Si pas de code configuré : accès libre direct
if (!$accessCode) {
    $_SESSION['authorized'] = true;
    header('Location: tesla.php');
    exit;
}

// Si déjà authentifié : redirection directe
if (!empty($_SESSION['authorized'])) {
    header('Location: tesla.php');
    exit;
}

// Vérification PIN soumis par POST
$error = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pin'])) {
    if ($_POST['pin'] === $accessCode) {
        $_SESSION['authorized'] = true;
        $_SESSION['auth_time'] = time();
        header('Location: tesla.php');
        exit;
    } else {
        $error = true;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>TESLAMATE-MAIL</title>

    <link rel="manifest" href="manifest.json">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link rel="apple-touch-icon" href="icon-192.png">
    <meta name="theme-color" content="#000000">

    <style>
        body {
            background-color: #000000; color: #ffffff;
            font-family: 'Segoe UI', sans-serif;
            display: flex; flex-direction: column; justify-content: center; align-items: center;
            min-height: 100dvh; margin: 0; padding: 10px; box-sizing: border-box; overflow: hidden;
        }

        .container { display: flex; flex-direction: column; align-items: center; width: 100%; max-width: 350px; gap: 5px; }
        .logo { max-width: 120px; mix-blend-mode: screen; }
        h1 { font-size: 1.4rem; letter-spacing: 2px; margin: 5px 0; font-weight: 900; text-transform: uppercase; }
        .copyright { font-size: 0.65rem; color: #666; margin-bottom: 10px; }

        /* Styles Numpad */
        #pincode-container { display: flex; flex-direction: column; align-items: center; }
        #pincode-container form { display: flex; flex-direction: column; align-items: center; }
        .dots { display: flex; gap: 12px; margin-bottom: 15px; justify-content: center; }
        .dot { width: 10px; height: 10px; border: 2px solid #2e7d32; border-radius: 50%; }
        .dot.active { background-color: #2e7d32; }
        .numpad { display: grid; grid-template-columns: repeat(3, 60px); gap: 10px; }
        .num-btn { width: 60px; height: 60px; border-radius: 50%; border: 1px solid #333; background: #111; color: white; font-size: 1.3rem; -webkit-tap-highlight-color: transparent; cursor: pointer; }
        .num-btn:active { background: #2e7d32; }
        
        /* BANDEAU INSTALLATION */
        #pwa-banner {
            display: none; position: fixed; bottom: 20px; left: 20px; right: 20px;
            background: #1e1e1e; border: 1px solid #2e7d32; padding: 15px;
            border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.5);
            z-index: 1000; text-align: center;
        }
        #pwa-banner p { margin: 0 0 10px 0; font-size: 0.9rem; }
        #install-button {
            background: #2e7d32; color: white; border: none; padding: 8px 20px;
            border-radius: 5px; font-weight: bold; cursor: pointer;
        }
    </style>
</head>
<body>

    <div class="container">
        <img src="logoteslamatemail.png" class="logo">
        <h1>TESLAMATE-MAIL</h1>
        <div class="copyright">© monwifi.fr 2026</div>

        <div id="pincode-container">
            <?php if ($error): ?>
            <div style="color:red; font-size:0.75rem; margin-bottom:8px;">Code incorrect</div>
            <?php endif; ?>
            <form method="POST" id="pinForm">
                <input type="hidden" name="pin" id="pinInput" value="">
                <div class="dots">
                    <div id="dot-1" class="dot"></div><div id="dot-2" class="dot"></div><div id="dot-3" class="dot"></div><div id="dot-4" class="dot"></div>
                </div>
                <div class="numpad">
                    <button type="button" class="num-btn" onclick="press('1')">1</button>
                    <button type="button" class="num-btn" onclick="press('2')">2</button>
                    <button type="button" class="num-btn" onclick="press('3')">3</button>
                    <button type="button" class="num-btn" onclick="press('4')">4</button>
                    <button type="button" class="num-btn" onclick="press('5')">5</button>
                    <button type="button" class="num-btn" onclick="press('6')">6</button>
                    <button type="button" class="num-btn" onclick="press('7')">7</button>
                    <button type="button" class="num-btn" onclick="press('8')">8</button>
                    <button type="button" class="num-btn" onclick="press('9')">9</button>
                    <button type="button" class="num-btn" onclick="clearPin()">C</button>
                    <button type="button" class="num-btn" onclick="press('0')">0</button>
                    <button type="submit" class="num-btn" style="font-size: 0.8rem;">OK</button>
                </div>
            </form>
        </div>
    </div>

    <div id="pwa-banner">
        <p>Installer <b>TM-Mail</b> sur votre écran ?</p>
        <button id="install-button">INSTALLER</button>
    </div>

    <script>
        // --- LOGIQUE PWA ---
        let deferredPrompt;
        const pwaBanner = document.getElementById('pwa-banner');
        const installBtn = document.getElementById('install-button');

        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            pwaBanner.style.display = 'block';
        });

        installBtn.addEventListener('click', async () => {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                const { outcome } = await deferredPrompt.userChoice;
                if (outcome === 'accepted') pwaBanner.style.display = 'none';
                deferredPrompt = null;
            }
        });

        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js');
        }

        // --- LOGIQUE PIN (sans le code dans le HTML) ---
        let currentInput = "";

        function press(num) {
            if (currentInput.length < 4) {
                currentInput += num;
                updateDots();
                if (currentInput.length === 4) {
                    setTimeout(() => {
                        document.getElementById('pinInput').value = currentInput;
                        document.getElementById('pinForm').submit();
                    }, 250);
                }
            }
        }

        function updateDots() {
            for (let i = 1; i <= 4; i++) {
                document.getElementById('dot-' + i).classList.toggle('active', i <= currentInput.length);
            }
        }

        function clearPin() {
            currentInput = "";
            document.getElementById('pinInput').value = "";
            updateDots();
        }
    </script>
</body>
</html>
