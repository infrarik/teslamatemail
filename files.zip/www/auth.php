<?php
session_start();
header('Content-Type: application/json');

$setupFile = "/var/www/html/cgi-bin/setup";
$correctCode = "";

if (file_exists($setupFile)) {
    $lines = file($setupFile, FILE_IGNORE_NEW_LINES);
    foreach ($lines as $line) {
        if (strpos($line, 'code=') === 0) {
            $correctCode = trim(explode('=', $line, 2)[1]);
            break;
        }
    }
}

// Pas de code configuré : accès libre
if ($correctCode === "") {
    $_SESSION['authorized'] = true;
    echo json_encode(['success' => true]);
    exit;
}

// Vérification via POST uniquement (le code ne passe plus dans l'URL)
$inputCode = $_POST['code'] ?? '';

if ($inputCode === $correctCode) {
    $_SESSION['authorized'] = true;
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
