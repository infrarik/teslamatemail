<?php
session_start();
header('Content-Type: application/json');

$setupFile  = "/var/www/html/cgi-bin/setup";
$lockFile   = sys_get_temp_dir() . '/teslamate_pin_lock_' . md5($_SERVER['REMOTE_ADDR'] ?? 'local');
$correctCode = "";

if (file_exists($setupFile)) {
    $lines = file($setupFile, FILE_IGNORE_NEW_LINES);
    foreach ($lines as $line) {
        if (strpos($line, 'code=') === 0) {
            $correctCode = trim(explode('=', $line, 2)[1]);
            break;
        }
    }
}

// Pas de code configuré : accès libre
if ($correctCode === "") {
    $_SESSION['authorized'] = true;
    echo json_encode(['success' => true]);
    exit;
}

// --- Gestion des tentatives ---
$max_attempts = 3;
$block_seconds = 300; // 5 minutes

$lock = ['attempts' => 0, 'first_fail' => 0, 'blocked_until' => 0];
if (file_exists($lockFile)) {
    $lock = json_decode(file_get_contents($lockFile), true) ?: $lock;
}

// Vérifier si bloqué
if ($lock['blocked_until'] > time()) {
    $reste = $lock['blocked_until'] - time();
    echo json_encode(['success' => false, 'blocked' => true, 'seconds' => $reste]);
    exit;
}

// Reset si le blocage est expiré
if ($lock['blocked_until'] > 0 && $lock['blocked_until'] <= time()) {
    $lock = ['attempts' => 0, 'first_fail' => 0, 'blocked_until' => 0];
}

// Vérification du code
$inputCode = $_POST['code'] ?? '';

if ($inputCode === $correctCode) {
    // Succès : reset du compteur
    @unlink($lockFile);
    $_SESSION['authorized'] = true;
    echo json_encode(['success' => true]);
} else {
    // Échec : incrémenter
    $lock['attempts']++;
    if ($lock['first_fail'] === 0) $lock['first_fail'] = time();

    if ($lock['attempts'] >= $max_attempts) {
        $lock['blocked_until'] = time() + $block_seconds;
        file_put_contents($lockFile, json_encode($lock));
        echo json_encode(['success' => false, 'blocked' => true, 'seconds' => $block_seconds]);
    } else {
        file_put_contents($lockFile, json_encode($lock));
        $restantes = $max_attempts - $lock['attempts'];
        echo json_encode(['success' => false, 'blocked' => false, 'remaining' => $restantes]);
    }
}
