<?php
/**
 * index.php - abrp avec openrouteservice (ors) et optimisation gemini
 */

require_once __DIR__ . '/auth_check.php';

// ============================================================
// langue (fr/en) - lecture du fichier setup partagé
// ============================================================

function brp_read_setup($file) {
    $cfg = [];
    if (file_exists($file)) {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos(trim($line), '#') === 0) continue;
            if (strpos($line, '=') !== false) {
                list($key, $value) = explode('=', $line, 2);
                $cfg[strtoupper(trim($key))] = trim($value);
            }
        }
    }
    return $cfg;
}

$brpconfig = brp_read_setup('cgi-bin/setup');
$lang = (isset($brpconfig['LANGUAGE']) && strtoupper($brpconfig['LANGUAGE']) === 'EN') ? 'en' : 'fr';

$texts = [
    'fr' => [
        'page_title'        => 'abrp - ors & gemini',
        'h1'                => 'itinéraire multi‑étapes avec optimisation péages',
        'key_saved'         => '✅ clés enregistrées.',
        'key_setup_title'   => '🔑 configuration des clés api',
        'key_setup_desc'    => 'clé ors : inscription gratuite sur <a href="https://openrouteservice.org/dev/#/signup" target="_blank">openrouteservice.org</a> → dashboard → tokens.<br>clé gemini : disponible sur <a href="https://aistudio.google.com/apikey" target="_blank">aistudio.google.com/apikey</a> (gratuit, pas de CB).',
        'label_ors_key'     => 'clé openrouteservice :',
        'placeholder_ors'   => 'coller la clé ors...',
        'label_gemini_key'  => 'clé google gemini :',
        'placeholder_gemini'=> 'coller la clé gemini...',
        'btn_save_keys'     => 'enregistrer les clés',
        'btn_add_step'      => '+ ajouter une étape',
        'label_sampling'    => 'densité de points de passage :',
        'sampling_less'     => '← plus de points (tracé précis)',
        'sampling_more'     => '(tracé simplifié) moins de points →',
        'sampling_info_pre' => '1 point toutes les',
        'sampling_info_mid' => 'km — sur 300 km : environ',
        'sampling_info_suf' => 'points.',
        'btn_submit'        => "calculer l'itinéraire",
        'error_prefix'      => 'erreur : ',
        'result_title'      => 'résultat du parcours',
        'th_segment'        => 'segment',
        'th_toll'           => 'péage',
        'th_distance'       => 'distance',
        'th_duration'       => 'durée',
        'th_points'         => 'points',
        'toll_with'         => 'avec',
        'toll_without'      => 'sans',
        'total_distance'    => 'distance totale :',
        'points_sent'       => 'points envoyés à abrp :',
        'btn_open_abrp'     => 'ouvrir dans abrp →',
        'advice_title'      => 'astuces et optimisation des péages — gemini ai',
        'js_depart'         => 'départ',
        'js_arrivee'        => 'arrivée',
        'js_etape'          => 'étape',
        'js_placeholder'    => 'ville ou lat,lon',
        'js_with_toll'      => 'avec péage (sinon sans)',
        'gemini_no_toll'    => 'aucun segment à péage sélectionné — aucune optimisation requise.',
        'label_gemini_toggle' => 'activer gemini (analyse et optimisation des péages)',
    ],
    'en' => [
        'page_title'        => 'abrp - ors & gemini',
        'h1'                => 'multi-stop route with toll optimization',
        'key_saved'         => '✅ keys saved.',
        'key_setup_title'   => '🔑 api key setup',
        'key_setup_desc'    => 'ORS key: free sign-up at <a href="https://openrouteservice.org/dev/#/signup" target="_blank">openrouteservice.org</a> → dashboard → tokens.<br>Gemini key: available at <a href="https://aistudio.google.com/apikey" target="_blank">aistudio.google.com/apikey</a> (free, no credit card).',
        'label_ors_key'     => 'OpenRouteService key:',
        'placeholder_ors'   => 'paste the ORS key...',
        'label_gemini_key'  => 'Google Gemini key:',
        'placeholder_gemini'=> 'paste the Gemini key...',
        'btn_save_keys'     => 'save keys',
        'btn_add_step'      => '+ add a stop',
        'label_sampling'    => 'waypoint density:',
        'sampling_less'     => '← more points (precise route)',
        'sampling_more'     => '(simplified route) fewer points →',
        'sampling_info_pre' => '1 point every',
        'sampling_info_mid' => 'km — over 300 km: about',
        'sampling_info_suf' => 'points.',
        'btn_submit'        => 'calculate the route',
        'error_prefix'      => 'error: ',
        'result_title'      => 'route result',
        'th_segment'        => 'segment',
        'th_toll'           => 'toll',
        'th_distance'       => 'distance',
        'th_duration'       => 'duration',
        'th_points'         => 'points',
        'toll_with'         => 'with',
        'toll_without'      => 'without',
        'total_distance'    => 'total distance:',
        'points_sent'       => 'points sent to abrp:',
        'btn_open_abrp'     => 'open in abrp →',
        'advice_title'      => 'toll tips and optimization — gemini ai',
        'js_depart'         => 'start',
        'js_arrivee'        => 'arrival',
        'js_etape'          => 'step',
        'js_placeholder'    => 'city or lat,lon',
        'js_with_toll'      => 'with toll (otherwise without)',
        'gemini_no_toll'    => 'no toll segment selected — no optimization needed.',
        'label_gemini_toggle' => 'enable gemini (toll analysis & optimization)',
    ],
];
$t = $texts[$lang];

// ============================================================
// configuration et gestion des cles
// ============================================================

$keydir = __DIR__ . '/';
$orskeyfile = $keydir . 'ors_key.txt';
$geminikeyfile = $keydir . 'gemini_key.txt';

$keysaved = false;
$keysaveerror = '';

if (isset($_POST['save_api_keys'])) {
    $neworskey = trim($_POST['ors_api_key_input'] ?? '');
    $newgeminikey = trim($_POST['gemini_api_key_input'] ?? '');

    if (!is_dir($keydir)) {
        @mkdir($keydir, 0750, true);
    }

    if (!is_dir($keydir)) {
        $keysaveerror = "impossible de créer le dossier de stockage des clés. vérifiez les droits (chmod 644).";
    } else {
        if ($neworskey !== '') {
            if (@file_put_contents($orskeyfile, $neworskey) !== false) {
                $keysaved = true;
            } else {
                $keysaveerror = "impossible d'écrire la clé ors. vérifiez les droits (chmod 644).";
            }
        }
        if ($newgeminikey !== '') {
            if (@file_put_contents($geminikeyfile, $newgeminikey) !== false) {
                $keysaved = true;
            } else {
                $keysaveerror = "impossible d'écrire la clé gemini. vérifiez les droits (chmod 644).";
            }
        }
    }
}

$orskey = file_exists($orskeyfile) ? trim(file_get_contents($orskeyfile)) : '';
$geminikey = file_exists($geminikeyfile) ? trim(file_get_contents($geminikeyfile)) : '';

define('ORS_API_KEY', $orskey);
define('GEMINI_API_KEY', $geminikey);
define('ORS_API_URL', 'https://api.openrouteservice.org/v2/directions/driving-car');
define('ORS_GEOCODE_URL', 'https://api.openrouteservice.org/geocode/search');

define('SAMPLING_DISTANCE_M_DEFAULT', 20000);
define('SAMPLING_DISTANCE_M_MIN',      5000);
define('SAMPLING_DISTANCE_M_MAX',    100000);
define('MAX_TOTAL_POINTS', 150);

// ============================================================
// fonctions calculs et itineraires
// ============================================================

function decodepolyline(string $encoded): array
{
    $points = [];
    $index = 0;
    $len = strlen($encoded);
    $lat = 0;
    $lng = 0;

    while ($index < $len) {
        $result = 1;
        $shift = 0;
        do {
            $b = ord($encoded[$index++]) - 63 - 1;
            $result += $b << $shift;
            $shift += 5;
        } while ($b >= 0x1f);
        $lat += ($result & 1) ? ~($result >> 1) : ($result >> 1);

        $result = 1;
        $shift = 0;
        do {
            $b = ord($encoded[$index++]) - 63 - 1;
            $result += $b << $shift;
            $shift += 5;
        } while ($b >= 0x1f);
        $lng += ($result & 1) ? ~($result >> 1) : ($result >> 1);

        $points[] = ['lat' => $lat * 1e-5, 'lon' => $lng * 1e-5];
    }
    return $points;
}

function orscomputeroute(array $origin, array $destination, bool $avoidtolls): array
{
    $url = ORS_API_URL . '/json';
    $ch = curl_init($url);

    $body = [
        'coordinates' => [
            [$origin['lon'], $origin['lat']],
            [$destination['lon'], $destination['lat']]
        ],
        'units' => 'm',
        'geometry' => true,
        'instructions' => false,
        'elevation' => false
    ];

    if ($avoidtolls) {
        $body['options'] = ['avoid_features' => ['tollways']];
    }

    $jsonbody = json_encode($body, JSON_UNESCAPED_UNICODE);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $jsonbody,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: ' . ORS_API_KEY
        ],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlerror = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        throw new Exception("erreur reseau : $curlerror");
    }

    $data = json_decode($response, true);

    if ($httpcode !== 200) {
        $msg = $data['error']['message'] ?? $data['message'] ?? 'erreur inconnue';
        $code = $data['error']['code'] ?? '';
        throw new Exception("erreur ors (http $httpcode) : $msg" . ($code ? " (code: $code)" : ""));
    }

    if (empty($data['routes']) || empty($data['routes'][0])) {
        $errormsg = $data['error'] ?? $data['message'] ?? 'aucune route trouvée';
        if (is_array($errormsg)) $errormsg = json_encode($errormsg);
        throw new Exception("aucun itinéraire. détail : " . $errormsg);
    }

    $route = $data['routes'][0];
    $summary = $route['summary'] ?? [];
    $geometry = $route['geometry'] ?? '';

    if (empty($geometry)) {
        throw new Exception("géométrie (polyline) manquante.");
    }

    $points = decodepolyline($geometry);
    if (empty($points)) {
        throw new Exception("impossible de décoder la polyline.");
    }

    return [
        'distancemeters' => (int) round($summary['distance'] ?? 0),
        'duration'       => round(($summary['duration'] ?? 0)) . 's',
        'coordinates'    => $points,
    ];
}

function orsgeocodewithsuggestions(string $address, int $limit = 10): array
{
    $cleanaddress = preg_replace('/\s*\([^)]*\)/', '', $address);
    $cleanaddress = trim($cleanaddress) ?: $address;

    $url = ORS_GEOCODE_URL . '?' . http_build_query([
        'text' => $cleanaddress,
        'size' => $limit,
        'boundary.country' => 'FR'
    ]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: ' . ORS_API_KEY],
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpcode !== 200) {
        throw new Exception("erreur geocodage (http $httpcode) pour : $address");
    }

    $data = json_decode($response, true);
    $results = [];
    $seen = [];

    if (!empty($data['features'])) {
        foreach ($data['features'] as $feature) {
            $geometry = $feature['geometry'];
            $properties = $feature['properties'] ?? [];
            $coords = $geometry['coordinates'];

            $lat = $coords[1];
            $lon = $coords[0];
            $key = round($lat, 5) . ',' . round($lon, 5);

            if (isset($seen[$key])) continue;
            $seen[$key] = true;

            $name = $properties['name'] ?? '';
            $locality = $properties['locality'] ?? '';
            $county = $properties['county'] ?? '';
            $country = $properties['country'] ?? '';
            $type = $properties['type'] ?? '';

            $label = $locality ?: $name;
            if (empty($label)) $label = $address;

            $detail = $county && $county !== $label ? $county : '';
            if ($country && strtolower($country) !== 'france') {
                $detail = $detail ? $detail . ', ' . $country : $country;
            }

            $results[] = [
                'lat'        => $lat,
                'lon'        => $lon,
                'address'    => $label,
                'full_name'  => $properties['label'] ?? $label,
                'detail'     => $detail,
                'type'       => $type,
                'confidence' => $properties['confidence'] ?? 0,
            ];
        }
    }
    return $results;
}

function orsgeocode(string $address): array
{
    $results = orsgeocodewithsuggestions($address, 10);
    if (empty($results)) {
        throw new Exception("aucun résultat pour : $address");
    }
    usort($results, function($a, $b) {
        $scorea = ($a['type'] === 'locality' || $a['type'] === 'city') ? 10 : 0;
        $scoreb = ($b['type'] === 'locality' || $b['type'] === 'city') ? 10 : 0;
        $scorea += $a['confidence'] / 10;
        $scoreb += $b['confidence'] / 10;
        return $scoreb <=> $scorea;
    });
    return $results[0];
}

function resolvepoint(string $input, bool $returnsuggestions = false): array
{
    $input = trim($input);
    if (preg_match('/^(-?\d+(\.\d+)?)\s*,\s*(-?\d+(\.\d+)?)$/', $input, $m)) {
        return ['lat' => (float)$m[1], 'lon' => (float)$m[3], 'address' => $input, 'is_coord' => true];
    }
    if ($returnsuggestions) {
        return orsgeocodewithsuggestions($input, 10);
    }
    $result = orsgeocode($input);
    $result['original_query'] = $input;
    return $result;
}

function haversinedistance(array $p1, array $p2): float
{
    $earthradius = 6371000;
    $lat1 = deg2rad($p1['lat']);
    $lat2 = deg2rad($p2['lat']);
    $dlat = deg2rad($p2['lat'] - $p1['lat']);
    $dlon = deg2rad($p2['lon'] - $p1['lon']);
    $a = sin($dlat/2)**2 + cos($lat1)*cos($lat2)*sin($dlon/2)**2;
    return $earthradius * 2 * atan2(sqrt($a), sqrt(1-$a));
}

function samplepoints(array $points, float $targetdistancem): array
{
    if (count($points) <= 2) return $points;
    $sampled = [$points[0]];
    $accumulated = 0.0;
    for ($i = 1; $i < count($points); $i++) {
        $accumulated += haversinedistance($points[$i-1], $points[$i]);
        if ($accumulated >= $targetdistancem) {
            $sampled[] = $points[$i];
            $accumulated = 0.0;
        }
    }
    $last = end($points);
    if (end($sampled) !== $last) $sampled[] = $last;
    return $sampled;
}

function buildabrpdeeplink(array $destinations): string
{
    $json = json_encode($destinations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return 'https://abetterrouteplanner.com/?destinations=' . rawurlencode($json);
}

function formatduration(string $isoduration): string
{
    $seconds = (int) str_replace('s', '', $isoduration);
    $h = intdiv($seconds, 3600);
    $m = intdiv($seconds % 3600, 60);
    return ($h > 0 ? "{$h}h " : '') . "{$m}m";
}

function demanderoptimisationpeages(array $segmentsatoll, string $lang = 'fr'): string
{
    $msgs = [
        'fr' => [
            'missing' => "configuration gemini manquante pour analyser les tarifs.",
            'error'   => "impossible de charger l'optimisation des tarifs : ",
        ],
        'en' => [
            'missing' => "gemini configuration missing to analyze fares.",
            'error'   => "unable to load fare optimization: ",
        ],
    ];
    $m = $msgs[$lang] ?? $msgs['fr'];

    if (empty(GEMINI_API_KEY)) {
        return $m['missing'];
    }

    $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" . GEMINI_API_KEY;

    $listenquetes = "";
    foreach ($segmentsatoll as $idx => $seg) {
        $listenquetes .= "- itinéraire " . ($idx + 1) . " : entre " . $seg['from'] . " et " . $seg['to'] . "
        ";
    }

    $langinstruction = ($lang === 'en') ? "réponds uniquement en anglais." : "réponds uniquement en français.";

    $prompt = "en utilisant autoroute-eco.fr et les différentes sociétés d'autoroute disponible, viamichelin, mappy, donne-moi le tarif
    direct sur autoroute et les meilleures combinaisons de fractionnement de péage pour un véhicule de
    classe 1 sur les trajets suivants :
    $listenquetes
    utilise uniquement du texte en minuscules, sois concis, sépare clairement les trajets, liste les sorties conseillées et l'économie
    estimée pour chaque portion à péage. $langinstruction";

    $body = [
        "contents" => [
            ["parts" => [["text" => $prompt]]]
        ],
        "tools" => [
            ["google_search" => (object)[]]
        ],
        "generationConfig" => [
            "thinkingConfig" => ["thinkingBudget" => 8000]
        ]
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($body),
                      CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
                      CURLOPT_TIMEOUT        => 20,
                      CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $response = curl_exec($ch);
    $httpcode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpcode !== 200) {
        $data = json_decode($response, true);
        $msg = $data['error']['message'] ?? "erreur http $httpcode";
        return $m['error'] . $msg;
    }

    $data = json_decode($response, true);
    return $data['candidates'][0]['content']['parts'][0]['text'] ?? "aucune optimisation trouvée.";
}

// ============================================================
// traitement du formulaire et requetes
// ============================================================

$result = null;
$error = null;
$geminiadvice = null;

$formpoints = $_POST['point'] ?? ['', ''];
$formtolls = $_POST['tolls'] ?? [];
$selectedsuggestion = $_POST['selected_suggestion'] ?? [];

// switch "activer gemini" : coché par défaut au premier chargement,
// sinon reflète l'état réel de la case au dernier calcul soumis
$enablegemini = ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['save_api_keys']))
    ? isset($_POST['enable_gemini'])
    : true;

if (isset($_GET['suggest']) && !empty($_GET['suggest'])) {
    header('Content-Type: application/json');
    try {
        if (ORS_API_KEY === '') throw new Exception("clé api manquante.");
        $suggestions = resolvepoint($_GET['suggest'], true);
        echo json_encode(['success' => true, 'results' => $suggestions]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['save_api_keys'])) {
    try {
        if (ORS_API_KEY === '') throw new Exception("clé api ors manquante.");

        $samplingkm = max(5, min(100, (int)($_POST['sampling_km'] ?? 20)));
        $samplingdistm = $samplingkm * 1000;

        $rawpoints = array_map('trim', $formpoints);
        $rawpoints = array_values(array_filter($rawpoints, fn($p) => $p !== ''));
        if (count($rawpoints) < 2) throw new Exception("renseignez au moins un départ et une arrivée.");

        $nbsegments = count($rawpoints) - 1;
        $resolvedpoints = [];

        foreach ($rawpoints as $i => $p) {
            if (isset($selectedsuggestion[$i]) && !empty($selectedsuggestion[$i])) {
                $sugdata = json_decode($selectedsuggestion[$i], true);
                if ($sugdata) {
                    $resolvedpoints[$i] = $sugdata;
                    continue;
                }
            }
            $resolved = resolvepoint($p, false);
            $resolvedpoints[$i] = $resolved;
        }

        $segments = [];
        $allsampledpoints = [];
        $tollssegmentsforgemini = [];

        for ($i = 0; $i < $nbsegments; $i++) {
            $withtolls = in_array((string)$i, $formtolls, true);
            $avoidtolls = !$withtolls;
            $origin = $resolvedpoints[$i];
            $destination = $resolvedpoints[$i + 1];

            $route = orscomputeroute($origin, $destination, $avoidtolls);
            $points = samplepoints($route['coordinates'], $samplingdistm);

            $fromname = $origin['address'] ?? $rawpoints[$i];
            $toname = $destination['address'] ?? $rawpoints[$i + 1];

            $segments[] = [
                'from'      => $origin,
                'to'        => $destination,
                'withtolls' => $withtolls,
                'distancem' => $route['distancemeters'],
                'duration'  => $route['duration'],
                'nbpoints'  => count($points),
            ];

            if ($withtolls) {
                $tollssegmentsforgemini[] = ['from' => $fromname, 'to' => $toname];
            }

            if ($i > 0) array_shift($points);
            $allsampledpoints = array_merge($allsampledpoints, $points);
        }

        if (count($allsampledpoints) > MAX_TOTAL_POINTS) {
            $factor = (int) ceil(count($allsampledpoints) / MAX_TOTAL_POINTS);
            $reduced = [];
            foreach ($allsampledpoints as $j => $p) {
                if ($j % $factor === 0) $reduced[] = $p;
            }
            $reduced[] = end($allsampledpoints);
            $allsampledpoints = $reduced;
        }

        $destinations = [];
        foreach ($allsampledpoints as $p) {
            $destinations[] = ['lat' => round($p['lat'], 5), 'lon' => round($p['lon'], 5)];
        }
        $destinations[0]['address'] = $resolvedpoints[0]['address'] ?? $rawpoints[0];
        $destinations[count($destinations)-1]['address'] = $resolvedpoints[count($resolvedpoints)-1]['address'] ?? end($rawpoints);

        $deeplink = buildabrpdeeplink($destinations);
        $totaldistancem = array_sum(array_column($segments, 'distancem'));

        $result = [
            'points'           => $resolvedpoints,
            'segments'         => $segments,
            'nbpointstotal'    => count($destinations),
            'totaldistancekm'  => round($totaldistancem / 1000, 1),
            'deeplink'         => $deeplink,
            'destinationsjson' => json_encode($destinations, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            'samplingkm'       => $samplingkm,
        ];

        if ($enablegemini && !empty(GEMINI_API_KEY)) {
            if (!empty($tollssegmentsforgemini)) {
                $geminiadvice = demanderoptimisationpeages($tollssegmentsforgemini, $lang);
            } else {
                $geminiadvice = $t['gemini_no_toll'];
            }
        }

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<title><?= htmlspecialchars($t['page_title']) ?></title>
<style>
* { box-sizing: border-box; }
body {
    background-color: #000000; color: #ffffff;
    font-family: 'Segoe UI', sans-serif;
    display: flex; flex-direction: column; justify-content: flex-start; align-items: center;
    min-height: 100dvh; margin: 0; padding: 20px 10px; box-sizing: border-box;
}

.container { display: flex; flex-direction: column; align-items: center; width: 100%; max-width: 800px; gap: 15px; }
.logo {
    max-width: 250px;
    height: auto;
    display: block;
    margin-bottom: 5px;
    border-radius: 50%;
}
h1 { font-size: 1.4rem; letter-spacing: 2px; margin: 5px 0; font-weight: 900; text-transform: uppercase; text-align: center; }
h2, h3 { font-size: 1.2rem; letter-spacing: 1px; font-weight: 700; text-transform: uppercase; margin-top: 15px; color: #ffffff; border-bottom: 1px solid #333; padding-bottom: 5px; }
.copyright { font-size: 0.65rem; color: #666; margin-bottom: 10px; text-align: center; }

.key-setup { background: #111; border: 1px solid #2e7d32; border-radius: 12px; padding: 20px; width: 100%; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
.key-setup h2 { margin: 0 0 10px; font-size: 1.1em; color: #2e7d32; border: none; }
.key-setup p { font-size: 0.85rem; color: #aaa; line-height: 1.4; }
.key-setup a { color: #2e7d32; text-decoration: none; font-weight: bold; }
.key-setup label { display: block; font-size: 0.85rem; margin-top: 10px; color: #ccc; }
.key-setup input[type=text] { width: 100%; padding: 10px; background: #1e1e1e; border: 1px solid #333; color: white; border-radius: 6px; margin-top: 5px; font-family: monospace; }

form { background: #111; padding: 20px; border-radius: 12px; width: 100%; border: 1px solid #222; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }

.error { background: #3a1111; color: #ff8888; padding: 12px; border-radius: 8px; border: 1px solid #731a1a; margin-bottom: 15px; width: 100%; font-size: 0.9rem; }
.key-save-ok { background: #133318; color: #88ff9c; padding: 12px; border-radius: 8px; border: 1px solid #1e5e29; margin-bottom: 15px; width: 100%; font-size: 0.9rem; }
.key-save-err { background: #3a1111; color: #ff8888; padding: 12px; border-radius: 8px; border: 1px solid #731a1a; margin-bottom: 15px; width: 100%; font-size: 0.9rem; }

.result { background: #111; padding: 20px; border-radius: 12px; margin-top: 20px; width: 100%; border: 1px solid #222; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
.advice-box { background: #161616; padding: 15px; border-left: 4px solid #2e7d32; border-radius: 6px; margin-top: 15px; white-space: pre-line; color: #ddd; font-size: 0.9rem; line-height: 1.5; border-top: 1px solid #222; border-right: 1px solid #222; border-bottom: 1px solid #222; }

.btn-link { display: inline-block; margin-top: 15px; padding: 12px 24px; background: #2e7d32; color: #fff; text-decoration: none; border-radius: 6px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; font-size: 0.9rem; text-align: center; }
.btn-link:active { background: #1b5e20; }

button { padding: 10px 18px; background: #2e7d32; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; -webkit-tap-highlight-color: transparent; }
button:active { background: #1b5e20; }
button.secondary { background: #222; border: 1px solid #444; color: #ccc; }
button.secondary:active { background: #333; }

.submit-btn { width: 100%; margin-top: 20px; padding: 14px; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px; }

table { border-collapse: collapse; width: 100%; margin-top: 15px; background: #161616; border-radius: 6px; overflow: hidden; }
td, th { padding: 10px 12px; text-align: left; font-size: 0.9rem; border-bottom: 1px solid #222; }
th { background: #1e1e1e; color: #2e7d32; font-weight: bold; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 0.5px; }
tr:last-child td { border-bottom: none; }

.point-row { display: flex; align-items: center; gap: 10px; padding: 10px 0; position: relative; border-bottom: 1px solid #1a1a1a; }
.point-row .drag-handle { width: 24px; text-align: center; color: #444; font-size: 1.2em; cursor: grab; }
.point-row .point-label { width: 90px; font-weight: bold; font-size: 0.85rem; text-transform: uppercase; color: #aaa; }
.point-row .input-wrapper { flex: 1; position: relative; }
.point-row .input-wrapper input { width: 100%; padding: 10px; background: #1e1e1e; border: 1px solid #333; color: white; border-radius: 6px; font-family: inherit; }
.point-row .input-wrapper input:focus { border-color: #2e7d32; outline: none; }
.point-row .remove-btn { background: #5a1818; border: 1px solid #802424; color: #ff8888; border-radius: 6px; width: 36px; height: 38px; cursor: pointer; display: flex; align-items: center; justify-content: center; font-weight: bold; }
.point-row .remove-btn:disabled { opacity: 0.3; cursor: not-allowed; }

.segment-row { padding: 8px 0 8px 124px; font-size: 0.85rem; color: #ccc; display: flex; align-items: center; gap: 8px; }
.segment-row input[type="checkbox"] { width: 16px; height: 16px; accent-color: #2e7d32; cursor: pointer; }

.suggestions-box { position: absolute; top: 100%; left: 0; right: 0; background: #1e1e1e; border: 1px solid #333; border-radius: 6px; max-height: 250px; overflow-y: auto; z-index: 1000; display: none; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
.suggestions-box.active { display: block; }
.suggestion-item { padding: 10px 12px; cursor: pointer; border-bottom: 1px solid #262626; font-size: 0.85rem; color: #ddd; }
.suggestion-item:hover { background: #2e7d32; color: #fff; }
.suggestion-item:last-child { border-bottom: none; }

.insert-indicator { height: 3px; background: #2e7d32; margin: 0; visibility: hidden; }
p { color: #aaa; font-size: 0.9rem; line-height: 1.4; }
p strong { color: #fff; }
</style>
</head>
<body>

<div class="container">
<img src="erouterlogo.png" alt="eRouter" class="logo">
<h1><?= htmlspecialchars($t['h1']) ?></h1>
<div class="copyright">© monwifi.fr 2026</div>

<?php if ($keysaved): ?>
<div class="key-save-ok"><?= htmlspecialchars($t['key_saved']) ?></div>
<?php endif; ?>

<?php if (!empty($keysaveerror)): ?>
<div class="key-save-err">⚠ <?= htmlspecialchars($keysaveerror) ?></div>
<?php endif; ?>

<?php if (empty($orskey) || empty($geminikey)): ?>
<div class="key-setup">
<h2><?= htmlspecialchars($t['key_setup_title']) ?></h2>
<p>
<?= $t['key_setup_desc'] ?>
</p>
<form method="post">
<label><?= htmlspecialchars($t['label_ors_key']) ?></label>
<input type="text" name="ors_api_key_input" value="<?= htmlspecialchars($orskey) ?>" placeholder="<?= htmlspecialchars($t['placeholder_ors']) ?>">
<label><?= htmlspecialchars($t['label_gemini_key']) ?></label>
<input type="text" name="gemini_api_key_input" value="<?= htmlspecialchars($geminikey) ?>" placeholder="<?= htmlspecialchars($t['placeholder_gemini']) ?>">
<button type="submit" name="save_api_keys" value="1" style="margin-top: 12px;"><?= htmlspecialchars($t['btn_save_keys']) ?></button>
</form>
</div>
<?php endif; ?>

<?php if (!empty($orskey)): ?>
<form method="post" id="route-form">
<div id="points-list">
<div class="insert-indicator" id="insert-indicator"></div>
</div>
<button type="button" id="add-step-btn" class="secondary" style="margin-top: 10px;"><?= htmlspecialchars($t['btn_add_step']) ?></button>

<div style="margin-top:20px; padding:15px; background:#161616; border-radius:8px; border: 1px solid #222;">
<label for="sampling_km" style="font-weight:bold; font-size: 0.9rem;">
<?= htmlspecialchars($t['label_sampling']) ?>
<span id="sampling_label" style="color:#2e7d32; margin-left:6px;"></span>
</label>
<input type="range" id="sampling_km" name="sampling_km"
min="5" max="100" step="5"
value="<?= (int)($_POST['sampling_km'] ?? $result['samplingkm'] ?? 20) ?>"
style="width:100%; margin:12px 0; cursor:pointer; accent-color: #2e7d32;"
oninput="updatesamplinglabel(this.value)">
<div style="display:flex; justify-content:space-between; font-size:0.75em; color:#666;">
<span><?= htmlspecialchars($t['sampling_less']) ?></span>
<span><?= htmlspecialchars($t['sampling_more']) ?></span>
</div>
<div style="font-size:0.8rem; color:#aaa; margin-top:8px; border-top: 1px solid #222; padding-top: 8px;">
<?= htmlspecialchars($t['sampling_info_pre']) ?> <strong id="sampling_km_val" style="color: #fff;"></strong> <?= htmlspecialchars($t['sampling_info_mid']) ?> <strong id="sampling_count_est" style="color: #fff;"></strong> <?= htmlspecialchars($t['sampling_info_suf']) ?>
</div>
</div>

<div style="margin-top:15px; padding:15px; background:#161616; border-radius:8px; border: 1px solid #222; display:flex; align-items:center; gap:12px;">
<input type="checkbox" id="enable_gemini" name="enable_gemini" value="1" <?= $enablegemini ? 'checked' : '' ?> style="width:20px; height:20px; accent-color:#2e7d32; cursor:pointer; flex-shrink:0;">
<label for="enable_gemini" style="font-weight:bold; font-size:0.9rem; cursor:pointer; text-transform:uppercase; letter-spacing:0.5px;"><?= htmlspecialchars($t['label_gemini_toggle']) ?></label>
</div>

<button type="submit" class="submit-btn"><?= htmlspecialchars($t['btn_submit']) ?></button>
</form>
<?php endif; ?>

<?php if ($error): ?>
<div class="error"><?= htmlspecialchars($t['error_prefix']) ?><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($result): ?>
<div class="result">
<h2><?= htmlspecialchars($t['result_title']) ?></h2>
<table>
<thead>
<tr><th><?= htmlspecialchars($t['th_segment']) ?></th><th><?= htmlspecialchars($t['th_toll']) ?></th><th><?= htmlspecialchars($t['th_distance']) ?></th><th><?= htmlspecialchars($t['th_duration']) ?></th><th><?= htmlspecialchars($t['th_points']) ?></th></tr>
</thead>
<tbody>
<?php foreach ($result['segments'] as $seg): ?>
<tr>
<td><?= htmlspecialchars($seg['from']['address'] ?? '') ?> → <?= htmlspecialchars($seg['to']['address'] ?? '') ?></td>
<td><?= $seg['withtolls'] ? htmlspecialchars($t['toll_with']) : htmlspecialchars($t['toll_without']) ?></td>
<td><?= round($seg['distancem'] / 1000, 1) ?> km</td>
<td><?= formatduration($seg['duration']) ?></td>
<td><?= $seg['nbpoints'] ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<p style="margin-top: 15px;">
<?= htmlspecialchars($t['total_distance']) ?> <strong><?= $result['totaldistancekm'] ?> km</strong> —
<?= htmlspecialchars($t['points_sent']) ?> <strong><?= $result['nbpointstotal'] ?></strong>
(1 pt / <?= $result['samplingkm'] ?> km)
</p>
<a class="btn-link" href="<?= htmlspecialchars($result['deeplink']) ?>" target="_blank"><?= htmlspecialchars($t['btn_open_abrp']) ?></a>

<?php if ($geminiadvice): ?>
<h3><?= htmlspecialchars($t['advice_title']) ?></h3>
<div class="advice-box"><?= htmlspecialchars($geminiadvice) ?></div>
<?php endif; ?>
</div>
<?php endif; ?>
</div>

<script>
function updatesamplinglabel(val) {
    val = parseInt(val, 10);
    const count = Math.round(300 / val) + 1;
    document.getElementById('sampling_label').textContent  = '1 pt / ' + val + ' km';
    document.getElementById('sampling_km_val').textContent = val;
    document.getElementById('sampling_count_est').textContent = count;
}

const initialpoints = <?= json_encode($formpoints, JSON_UNESCAPED_UNICODE) ?>;
const initialtolls  = <?= json_encode(array_map('strval', $formtolls), JSON_UNESCAPED_UNICODE) ?>;
const pointslist    = document.getElementById('points-list');
const addstepbtn    = document.getElementById('add-step-btn');

const i18nbrp = {
    depart:      <?= json_encode($t['js_depart'], JSON_UNESCAPED_UNICODE) ?>,
    arrivee:     <?= json_encode($t['js_arrivee'], JSON_UNESCAPED_UNICODE) ?>,
    etape:       <?= json_encode($t['js_etape'], JSON_UNESCAPED_UNICODE) ?>,
    placeholder: <?= json_encode($t['js_placeholder'], JSON_UNESCAPED_UNICODE) ?>,
    withtoll:    <?= json_encode($t['js_with_toll'], JSON_UNESCAPED_UNICODE) ?>,
};

let currentpoints = initialpoints.length >= 2 ? [...initialpoints] : ['', ''];
let currenttolls  = new Set(initialtolls);
let suggesttimeout = null;

function syncinputs() {
    const inputs = document.querySelectorAll('#points-list .point-row input[type="text"]');
    if (inputs.length === currentpoints.length) {
        currentpoints = Array.from(inputs).map(i => i.value);
    }
}

function render() {
    document.querySelectorAll('#points-list .point-row, #points-list .segment-row').forEach(r => r.remove());
    const total = currentpoints.length;

    currentpoints.forEach((val, i) => {
        const row = document.createElement('div');
        row.className = 'point-row';

    const handle = document.createElement('div');
    handle.className = 'drag-handle';
    handle.textContent = '⠿';
    row.appendChild(handle);

    const label = document.createElement('div');
    label.className = 'point-label';
    label.textContent = i === 0 ? i18nbrp.depart : (i === total - 1 ? i18nbrp.arrivee : i18nbrp.etape + ' ' + i);
    row.appendChild(label);

    const wrapper = document.createElement('div');
    wrapper.className = 'input-wrapper';
    const input = document.createElement('input');
    input.type = 'text';
    input.name = 'point[]';
    input.value = val;
    input.required = true;
    input.placeholder = i18nbrp.placeholder;
    wrapper.appendChild(input);
    row.appendChild(wrapper);
    attachsuggestions(input);

    const removebtn = document.createElement('button');
    removebtn.type = 'button';
    removebtn.className = 'remove-btn';
    removebtn.textContent = '✕';
    removebtn.disabled = total <= 2;
    removebtn.addEventListener('click', () => {
        syncinputs();
        currentpoints.splice(i, 1);
        render();
    });
    row.appendChild(removebtn);
    pointslist.appendChild(row);

    if (i < total - 1) {
        const segrow = document.createElement('div');
        segrow.className = 'segment-row';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.name = 'tolls[]';
    cb.value = String(i);
    cb.checked = currenttolls.has(String(i));
    cb.addEventListener('change', () => {
        if (cb.checked) currenttolls.add(String(i));
        else currenttolls.delete(String(i));
    });
        segrow.appendChild(cb);
        segrow.appendChild(document.createTextNode(' ' + i18nbrp.withtoll));
        pointslist.appendChild(segrow);
    }
    });
}

function attachsuggestions(input) {
    const wrapper = input.closest('.input-wrapper');
    const box = document.createElement('div');
    box.className = 'suggestions-box';
    wrapper.appendChild(box);

    input.addEventListener('input', () => {
        const q = input.value.trim();
        if (q.length < 2) { box.classList.remove('active'); return; }
        clearTimeout(suggesttimeout);
        suggesttimeout = setTimeout(async () => {
            try {
                const resp = await fetch('?suggest=' + encodeURIComponent(q));
                const data = await resp.json();
                box.innerHTML = '';
        if (!data.success || !data.results.length) { box.classList.remove('active'); return; }
        data.results.forEach(sug => {
            const item = document.createElement('div');
            item.className = 'suggestion-item';
        item.textContent = sug.full_name || sug.address;
        item.addEventListener('mousedown', e => {
            e.preventDefault();
            input.value = sug.address || sug.full_name;
            box.classList.remove('active');
        });
        box.appendChild(item);
        });
        box.classList.add('active');
            } catch(e) { box.classList.remove('active'); }
        }, 300);
    });
    input.addEventListener('blur', () => setTimeout(() => box.classList.remove('active'), 300));
}

if (addstepbtn) {
    addstepbtn.addEventListener('click', () => {
        syncinputs();
        currentpoints.splice(currentpoints.length - 1, 0, '');
        render();
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const sl = document.getElementById('sampling_km');
    if (sl) updatesamplinglabel(sl.value);
    render();
});
</script>
</body>
</html>

